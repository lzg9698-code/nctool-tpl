import {
  createContext,
  useCallback,
  useContext,
  useSyncExternalStore,
} from "react";
import { action } from "./api";
import { encode, parseData, type Data, type Run } from "./data";

interface DependencyState {
  stale: boolean;
  message: string;
}
export interface DependencyRequest {
  key: string;
  action: string;
  input: string;
}
const CURRENT: DependencyState = { stale: false, message: "" };
const CHECKING: DependencyState = { stale: true, message: "正在核对参数依赖…" };
const CHANGED: DependencyState = {
  stale: true,
  message: "参数、刀具或模板依赖已变化，请重新生成。",
};
const FAILED: DependencyState = {
  stale: true,
  message: "无法核对当前参数依赖，请检查资产后重新生成。",
};

export function managedDependencyRequest(
  run: Run | undefined,
  workspace: string,
  enabled = true,
): DependencyRequest | undefined {
  if (!enabled || run?.status !== "succeeded") return;
  const replay = run.result?.data?.replay_input;
  const checkAction = replay?.job_snapshot
    ? run.action.replace(/\.generate$/, ".check")
    : replay?.managed_snapshot
      ? "nc.managed.check"
      : replay?.process_snapshot
        ? "process.managed.check"
        : replay?.parameter_snapshot
          ? "parameter.dependencies.check"
          : undefined;
  if (!checkAction) return;
  const input = encode(
    checkAction === "parameter.dependencies.check"
      ? {
          snapshot: replay.parameter_snapshot,
          template_snapshot: replay.snapshot,
        }
      : replay,
  );
  return {
    key: encode([workspace, run.id, checkAction, input]),
    action: checkAction,
    input,
  };
}

// One entry per workspace/run/check input. Entries exist only while subscribed;
// identity guards also reject responses from an earlier mount of the same key.
export function createManagedDependencyChecks(
  check: (id: string, input: Data) => Promise<Data>,
  interval = 3000,
) {
  interface Entry {
    state: DependencyState;
    listeners: Set<() => void>;
    timer?: ReturnType<typeof setTimeout>;
  }
  const entries = new Map<string, Entry>();
  return {
    getSnapshot(key: string): DependencyState {
      return entries.get(key)?.state || CHECKING;
    },
    subscribe(request: DependencyRequest, listener: () => void): () => void {
      let entry = entries.get(request.key);
      const first = !entry;
      if (!entry) {
        entry = { state: CHECKING, listeners: new Set() };
        entries.set(request.key, entry);
      }
      // Each subscription owns its cleanup, even if callbacks are identical.
      const notify = () => listener();
      entry.listeners.add(notify);
      const shared = entry;
      const active = () => entries.get(request.key) === shared;
      function publish(state: DependencyState) {
        if (!active()) return;
        shared.state = state;
        for (const subscriber of shared.listeners) subscriber();
      }
      async function poll() {
        publish(CHECKING);
        try {
          const response = await check(
            request.action,
            parseData(request.input),
          );
          publish(response?.data?.current === true ? CURRENT : CHANGED);
        } catch {
          publish(FAILED);
        } finally {
          // Schedule after settlement: slow checks never overlap a later poll.
          if (active()) shared.timer = setTimeout(() => void poll(), interval);
        }
      }
      if (first) void poll();
      return () => {
        shared.listeners.delete(notify);
        if (shared.listeners.size || !active()) return;
        clearTimeout(shared.timer);
        entries.delete(request.key);
      };
    },
  };
}

const checks = createManagedDependencyChecks(action);
export const ManagedDependencyWorkspace = createContext("");

export function useManagedDependencies(
  run?: Run,
  enabled = true,
  workspaceId?: string,
): DependencyState {
  const inheritedWorkspace = useContext(ManagedDependencyWorkspace);
  const request = managedDependencyRequest(
    run,
    workspaceId ?? inheritedWorkspace,
    enabled,
  );
  // Serialized input, rather than Run object identity, controls subscriptions.
  const subscribe = useCallback(
    (listener: () => void) =>
      request ? checks.subscribe(request, listener) : () => {},
    [request?.key],
  );
  const getSnapshot = useCallback(
    () => (request ? checks.getSnapshot(request.key) : CURRENT),
    [request?.key],
  );
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
}
