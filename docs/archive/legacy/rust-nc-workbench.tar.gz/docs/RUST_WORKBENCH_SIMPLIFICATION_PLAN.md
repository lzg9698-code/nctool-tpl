# Rust 工作台去加工领域精简方案

日期：2026-10-14。依据当前工作树（HEAD `e8fafd5`及已有未提交改动）。这是实施方案，尚未执行以下源码移除、配置迁移或发布。

## 1. 推荐结论

把 `rustjinja` 的Rust工作台收束为通用Jinja模板产品：**编辑模板、提供JSON数据、校验并生成文本或文件，保留运行历史与资产管理**。

“定制化工艺全部去掉”建议按完整边界处理：移除同步粗车、越程槽、键槽等业务算法，以及它们依赖的内置NC生成、机床资产、加工参数推荐、工序编排和NC后处理。仅隐藏专用页面或默认禁用插件仍会维护全部算法、页面、构建分支和验收，不达成这次精简目标。

独立 `shaft_programmer/` 的加工能力保持其独立产品定位，本方案不修改它及用户加工数据。当前已退役的旧Python工作台归档保持原字节。

## 2. 保留与移除

| 部分 | 处理 | 理由 |
| --- | --- | --- |
| 根 `nctool-tpl` 引擎 | 保留 | 通用解析、变量分析、Jinja渲染是产品核心，继续仅依赖MiniJinja |
| `assets` / `sdk` / `runtime` | 保留 | 资产冲突/原子写入、版本化服务、取消/超时、外部插件是通用可靠性边界 |
| `plugins/template` | 保留 | 模板/预置/源码快照及渲染 |
| `plugins/parameters` | 保留并清理加工耦合 | 共享定义、JSON Schema、绑定、预置、来源与 `template.render.managed` 不属于加工专用功能 |
| `plugins/math` | 保留为独立、显式启用扩展 | 数学过滤器可用于通用数据模板；与 `nc-bundle` 解耦，不默认注入根引擎 |
| `plugins/nc` | 移出当前构建与源码树 | 移除基础NC生成、机床、参数派生、刀具/材料/标准、受管工艺、几何/轨迹、NC格式化/lint |
| `plugins/process` | 移出 | 顺序加工、多通道输出组合及process-parameters本轮整体退出；不改造为新通用流水线 |
| `plugins/sync-turning` / `plugins/undercut` | 移出 | 定制同步粗车、ES/FS槽、轨迹预设及专用批量表单全部退出 |
| 通用文档编辑、历史、插件、工作区导入 | 保留 | 保留用户使用通用模板的完整闭环 |
| NC/机床/工序/刀具/材料/标准/专用车削页面 | 删除活动入口与实现 | 从导航、懒加载、状态、CSS和业务依赖中完整去除 |
| 用户模板、参数、机床、历史与本地NC资料 | 不删除、不覆盖 | 能力退出不等于授权删除用户资产 |
| 加工示例、验收脚本、当前指南 | 从活动维护中退出并归档 | 历史证据可追溯，当前文档与CI只描述仍支持的Rust能力 |

### 后端与构建具体范围

- Cargo workspace删除 `plugins/nc`、`plugins/process`、`plugins/sync-turning`、`plugins/undercut`四个成员；CLI删除对应path依赖和 `nc-bundle`，数学改为独立编译feature及显式运行启用。`nc-parameters`、`nc-managed`、`process-parameters`是上述crate内的插件ID，不是另三个crate，服务/描述/配置也须一并退出。
- `runtime/Cargo.toml`还有process的测试依赖，runtime两个组合/服务冲突回归须改用通用虚拟消费者，保留服务解析覆盖；不能只删CLI optional依赖。
- `cli/src/composition.rs`、`cli/src/main.rs`、`runtime/src/config.rs`的内置插件名单、profile、inventory及enable/install保留ID政策同步收束。旧加工ID可保留为退役保留名，拒绝同名外部插件自动接管旧enabled配置；活动capabilities不造假NC动作。
- `template.render.managed`目前不接收/转发 `extensions`。建议给它补齐通用显式扩展字段并冻结到replay_input，让共享参数与数学扩展能共用；不默认启用math、不修改根引擎。普通 `template.render`已有该能力。
- `examples/v3-managed`、`examples/v2`里的NC/process示例退出通用分发；V3混合包包含加工动作、派生轨迹和专用filter，不能只拿template集合便宣称可运行。
- 退出加工脚本：`migrate_v3_parameters.py`、`v3_calculation_map.py`、`verify_managed_parameters.py`、`verify_specialized_turning.py`及专用managed/turning/trajectory浏览器脚本；混合 `browser_v2.cjs`、`browser_review_fixes.cjs`只保留通用场景。
- `scripts/check_v2.py`现有NC构建/process包断言改为通用依赖与独立math边界；CI/release中强制 `nc-bundle`构建改为通用构建。推荐发行CLI包含可选math实现，运行仍默认不加载math，显式启用后才可请求扩展。独立轴类/研究测试从Rust通用验证入口分组隔离，保留它们自己的门槛，不借本次精简删除独立产品测试。
- 删除NC可退出其生产YAML依赖，但通用assets仍有YAML数值测试依赖，不能承诺整个锁文件不再出现serde_yaml。

静态规模：四个加工crate共20个Rust源码/测试文件、11,626行（包含文件内测试）；独立专用车削测试再计569行，确定退出约 **12,195行Rust代码及测试**。未计混合platform/managed参数测试、composition分支、脚本或示例；不把包含通用覆盖的文件整删。

### 前端具体范围

可退出整个业务模块的文件：`ui/src/plugins/NcViews.tsx`、`TurningWorkbench.tsx`、`SyncTurningView.tsx`、`UndercutView.tsx`；`ui/src/components/SpecializedTemplateEditor.tsx`、`TrajectoryPresetEditor.tsx`；`ui/src/lib/turningModel.ts`、`syncAp2.ts`、`managedParameters.ts`及其专属测试。删除前须把 `NcViews` 中通用 `ViewProps` 类型移到通用位置。

只清理加工分支的文件：`ParameterViews.tsx`、`App.tsx`、`WorkbenchUi.tsx`、`documentExecution.ts`、`managedDependencies.ts`、`PluginSettings.tsx`、`syntaxGuide.ts`及 `styles.css`。保留 `parameter.library` 注册，移除七种内置加工视图；未知外部插件仍使用通用Schema页面。不能只删registry，因为capabilities贡献的panel还可能进入通用插件页面。

`managedDependencies.ts`保留 `parameter.dependencies.check` 和共享订阅/迟到响应隔离；只移除job_snapshot、nc.managed、process.managed的加工映射。`ParameterViews`保留definitions/presets的CRUD与预置选择，删除刀具、材料、推荐、确认和ManagedProcess。历史恢复增加通用受管模板的正确快照路径，旧加工历史不导向被删除页面。

静态行数估计：可整删业务TS/TSX约3,261行（含少量需迁出的公共类型），专用CSS约480～500行；约 **3,740行前端产品代码**，连专属测试约3,880～3,900行。未计混合文件中的加工分支，不作为承诺删除额度或性能收益。

## 3. 精简后的页面

主导航建议保持四项：**模板、共享参数、历史、设置**。模板库与文档编辑仍支持使用/编辑模式、多文档、源码/参数表单、预置和结果。设置收纳插件管理与工作区导入/导出；不增加新的面板框架。

模板编辑保留Jinja语法/变量检查、嵌套JSON/null、数值输入边界、引用/宏、Schema/defaults、保存冲突、草稿恢复、结果失效。模板执行保留普通与共享参数受管渲染；输出下载和多文件产物保留通用宿主语义，但不再计算NC行号、同步号或工序。

受管参数依赖检查继续用于通用模板。不因为文件名含 `managed` 就删除整个核对模块。泛化可复用的Schema表单、任务详情、历史比较与能力路由继续保留。

## 4. 旧配置与资产的兼容处理

这是一次显式功能收缩，不能把旧请求或资产悄悄解释为另一种行为。

- 旧 `--profile nc`、`nc-bundle` 及NC/process动作退出当前支持范围；CLI给出具体原因和迁移说明，不把旧NC参数当成 `template.render` context。
- 根目录 `启动UI.bat` 改为固定启动通用template工作台，继续使用原停止脚本、端口8788和独立target目录，去掉 `--features nc-bundle` / `--profile nc`。
- 启动读取旧保存配置时，区分已退役内置项与未知外部插件。提供只读检查及新配置预览；只有显式应用才备份并以指纹写入配置。移除的enabled/disabled/provider/plugin项逐项报告，不静默丢弃或删除已安装外部插件。当前config load先校验保存profile，之后才有CLI override，因此兼容入口须先识别旧配置；不能仅删除nc枚举后指望 `--profile template`自行救场。
- 保存为nc profile的配置须明确迁到template；启动器可用显式profile覆盖选择，但不能绕过剩余无效依赖。迁移未完成时显示可操作诊断。
- 带 `metadata.nc`、加工执行动作或专用工艺标记的旧模板保留查看/编辑。能力缺失时禁止执行/试跑，显示退役说明；不能因为新capabilities中没有NC而自动退回普通渲染。用户另行制作普通文本模板时需显式清除执行意图并核对其含义。
- 旧NC任务历史保留查看、结果比较和历史已存文件的读取；缺少动作提供方时禁用重执行/恢复为可执行文档，并显示原因。保持历史原内容，不能补造新绑定或验收。
- 导入混合资产包前列出已退役集合并阻断整体导入，不静默忽略机床/NC资产。需要通用资产时，显式制作新的通用子集包，保留来源及完整性记录。
- 原数据目录继续保留。卸载能力不清空 `.nctool/runs`、`templates`、`parameters/nc`、`machines` 或独立工具库。

对外协议/服务版本不为删除功能随意改号；若保留接口行为确有变化再单独升级。CLI/WebUI与核心组件版本分别维护，正式发行需明确兼容性说明，不在本轮文档阶段发布。

## 5. 建议实施顺序

1. **捕获当前基线并列出退出范围。** 本仓库仍有大量未提交/未跟踪改动，不能用HEAD快照代替。源码归档、SHA-256清单、原Git状态和补丁覆盖本次被移出文件；用户运行数据另外保留。归档按原路径可恢复，当前锁文件、构建脚本与相关测试一并留证。
2. **先保护旧数据的消费边界。** 实现旧配置预检查、退役动作/模板标记诊断、历史不可重执行状态和混合资产包拒绝；先有明确错误，再移除提供方，避免中间状态错误执行。
3. **移除后端领域能力。** Cargo workspace/CLI依赖、composition、profile选择、描述清单、插件服务与NC/process包同步退出。数学扩展从加工bundle解耦；不合并通用crate或修改根引擎领域边界。
4. **删除前端加工链。** 关闭路由/懒加载入口，删除专用页面、加工状态/动作构造、业务资源加载及无消费者CSS。混合文件只删除加工分支，保留通用运行与参数能力。避免把App原样拆文件当成此次收益。
5. **同步启动、构建和维护资料。** 更新根启动UI、CI/release构建、MSRV、架构检查、浏览器套件、示例及当前中文指南。保留通用与独立轴类各自测试门槛；生成资源仅经正式脚本重建，先保存原 `cli/ui/source.sha256` 再核对差异。
6. **隔离验收并交付。** 临时home/workspace、随机loopback端口、固定二进制验证；仅关闭本轮进程。报告源码版本、实际通过/失败和未执行平台。提交/推送/发布另行授权。

建议以一次完整功能收缩交付，按上述顺序实现和验证，不维护新的“旧工艺可选构建”长期分支。

## 6. 验收标准

| 范围 | 必须证明 |
| --- | --- |
| 通用模板 | 创建/编辑/复制/保存冲突、嵌套JSON/null、Schema/defaults、宏/引用、共享参数及预置、正常输出 |
| 失败边界 | 语法/输入/数值非法、取消/超时、陈旧资产指纹、失败无当前产物、错误草稿不回退旧有效值 |
| 旧加工输入 | 旧配置诊断、NC标记模板禁止降级、旧history可查看不可重执行、混合资产包无部分导入 |
| 构建边界 | 工作区及发行CLI无内置NC/process/专用工艺依赖，前端无专用页面chunk，启动UI加载template |
| 历史与用户数据 | 原历史不改写、退出能力不删除用户资产、恢复归档逐字节可核对 |
| 页面 | 主导航清晰；窄屏/短窗口/折叠导航/对话框焦点、编辑/使用模式与任务状态正常 |

实际执行命令以[贡献指南](CONTRIBUTING.md)为准：Rust workspace tests/doc tests、fmt、Clippy、MSRV；前端测试与正式构建/一致性；架构/Python工具/隔离CLI与浏览器回归。Cargo依赖移除会改变锁文件，按项目规则执行依赖审计并保留报告；网络失败记未完成。发布仍需要拟发布提交的三平台实际CI证据，历史成功不替代本轮。

## 7. 交付物与预期收益

- 当前Rust工作台仅保留通用模板闭环；内置加工页面、资产模型和算法从活动源码及发布二进制退出。
- 一份可恢复的加工模块归档、精确文件清单、旧配置/资产兼容说明以及新的通用工作台指南。
- 通用功能/失败边界回归与旧数据兼容验收报告。
- 一套启动/构建流程，减少template/nc两套组合的日常验证和NC专用CSS/状态维护。

静态估计：约12,195行Rust代码及测试、约3,740行前端产品代码，另有专属测试/脚本/示例和混合文件加工分支。这些是移出活动维护的规模，不是包体、速度或质量提升的实测数字。

本次方案阶段只读取源码和编写方案/导航，没有执行源码删除、构建重生成、产品测试、运行资产迁移、提交或发布。文档事实核对按[文档同步Skill](../.agents/skills/nctool-docs-release/SKILL.md)，方案中的文件清单与依赖来自当前源码调查，后续实施需重新检查实际工作树。
