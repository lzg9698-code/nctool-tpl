# 轴类编程工作台首版交付核对

> 历史记录：2026-10-14旧固定方案工作台已归档退役。下文测试数量、路径和入口描述原交付时点，已移除文件保存在[退役归档](archive/legacy/WORKBENCH_RETIREMENT.md)；当前轴类开发使用[独立工具](../shaft_programmer/README.md)。

日期：2026-10-12。工作区：D:/Dev/Projects/nctool/rustjinja。版本0.1；未提交的本地实现，Git基准a7a507d7529ad8a2f722ca00836bc100b59c0517。

本次交付目标是可运行、可编辑、可保存并能生成完整程序的首个软件版本。以既有提案的14594226试点正常路径完成软件闭环；跨结构覆盖、任意恢复、商用CAM通用能力和实际机床验收仍按原提案分阶段推进。下列证据不授予生产验收，也不宣称原提案B1～B5/P2的现场条件全部通过。

| 用户需求/首期要求 | 当前交付和可检查证据 | 边界 |
| --- | --- | --- |
| 找到1459程序和已有设计，学习其它零件 | nc原始资料、prototypes/part_planning/family_states/study-data.json及11项参考库；原资料逐文件指纹核对 | 其它10套是已学习参考，尚非可编辑生成方案 |
| 可直接使用的独立工具 | 根目录启动/停止.cmd、scripts/start_workbench.py、127.0.0.1:8789；临时home的启动/复用/停止/外来端口拒绝验收 | Windows本地使用，Python3.10+，不需要运行时npm |
| 可重设计技术和UI | Python标准库服务、Decimal工艺计算、React/TypeScript/SVG工作台；预构建workbench/static | 采用独立入口，保留旧引擎/插件语义 |
| 新建/复制/打开与结构化输入 | 尺寸、公差实际上下限、轴向长度、毛坯、余量、切深、进给、测量、刀具；参数导入、草稿恢复、指纹冲突保存 | 同型拓扑，1～3闭口键槽；不内置ISO公差表或自动图纸识别 |
| 毛坯至中间件再到磨后目标 | 11阶段工序形状、夹持说明、磨前外圆目标和不移动的键槽底；原图可打开 | 名义形状示意；刀尖圆弧补偿、PLC完成反馈和完整实体碰撞未仿真 |
| 正确应用用户确认规则 | 外圆实际上限＋直径0.5；FS关联端面单面轴向0.1；ES/FS局部轨迹零附加量；键槽底成品位置 | 默认两槽固定底半径39.9/55.4；修改规格需核定公差和工艺 |
| 正确刀具链 | 当前刀→L172换刀→下一刀预选；默认链与冻结样例逐项比对；增删槽/关闭倒角/改刀重建 | 刀号有效不代表刀具几何或机床安装已验收 |
| 实际程序和对应轨迹 | 12个核心NC文件、参数/测量/JOB及键槽子程序；实际输出行解析得到G18/G17轨迹及SVG点击定位 | RND未展开刀尖补偿；环槽只显示真实R13循环定位，不伪造DB_CYCLE93内部轮廓 |
| 命令行完整生成 | python -m workbench sample；python -m workbench generate；完整候选目录及输入/计划/哈希清单 | 不覆盖既有目录；参数非法时不交付部分输出 |
| 变体与失败验证 | 21项非下载后端测试；19组非下载浏览器工作流；等待点配对/死锁、JOB/标签/调用、键槽帧复位及输入/材料/槽深检查 | 仅覆盖本实现生成子集；不声称完整Sinumerik解释器 |
| 明示未知假设 | 检查页和workbench/README.md标出分界映射、刀具宽度分组、三槽扩展、OEM循环、名义预览及机床核定 | WAITM是节点协调；不提供连续位置跟随保证 |
| 保留原生成器和本地资料 | 336文件基线除合法构建更新cli/ui/source.sha256及新增文档导航外保持不变；214个原始NC/图纸字节一致 | 未修改原业务/模板/NC，未提交/推送/发布 |
| 下载 | 用户已确认触发可行，明确要求停止下载测试；本轮所有执行带skip-downloads，不触发或检查下载 | 保留此前自动化204空响应记录；原因及下载内容未进一步验证，不改记为软件内容验证通过 |

原方案B5需要对应机床/刀具/循环配置、外部仿真和现场测量；当前没有这些来源及结果，状态始终not_performed。没有伪造循环实现或现场签收。软件候选的输出检查与这些条件分开显示。

运行记录：target/workbench-v1/delivery-verification.json；浏览器截图与19组结果：target/workbench-v1/browser/report.json；源码恢复快照：target/workbench-v1/source-baseline。上述target资料是本地证据，不随仓库分发。

本轮复核命令：

~~~powershell
python -m workbench.test_workbench --skip-downloads
node scripts/browser_workbench.cjs --skip-downloads
python scripts/verify_workbench_delivery.py
node scripts/build_ui.mjs --check
~~~

之前32项旧UI测试、65项旧Python测试、架构检查和独立target宿主编译已通过；本轮原源码指纹复核确认其对应源码未变。没有新增依赖或运行发布门槛，没有将历史全量验证数量作为本版本机床验收。
