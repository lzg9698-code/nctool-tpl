# -*- coding: utf-8 -*-
"""Migrate explicit legacy inputs to an editable, blocked shaft draft.

No legacy generator/import is required. The CLI validates the entire batch before
publishing a new output directory; existing directories are never overwritten.
Each *-draft.json has exactly job/machine. Its separate *-report.json preserves
source inputs and lists what must be reconstructed and confirmed, not acceptance.
"""
from __future__ import annotations

from copy import deepcopy
from decimal import Decimal as D
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile

REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from shaft_programmer.common import load_json
from shaft_programmer.core.document import validate_document
from shaft_programmer.core.model import InvalidJob
from shaft_programmer.core.targets import resolve

ORDER = ("left", "shoulder", "bearing", "middle", "right", "tail")
OLD_DIAMETERS = ("left", "cap", "middle", "bearing", "right", "tail")
LEGACY_REGIONS = ("left", "middle", "right", "tail")
# Distinct installations remain distinct roles, including both A and B tools.
LEGACY_TO_ROLES = {role: role for role in (
    "rough1", "rough2", "finish1", "finish2", "relief1", "relief3", "rings",
    "key_rough_a", "key_finish_a", "key_rough_b", "key_finish_b", "chamfer",
)}
LEGACY_DATUM = {"high-end": "high", "average": "average", "low-end": "low"}
PART_FIELDS = ("format", "code", "title", "machine_profile", "lengths", "diameters",
               "stock", "cutting", "keys", "tools", "measurement", "notes")
CUTTING_FIELDS = ("diameter_allowance", "fs_face_allowance", "rough_remaining",
                  "ap1", "ap2", "feed", "black_drop")
KEY_FIELDS = ("id", "title", "region", "offset", "length", "width", "radius",
              "depth_lower", "depth_upper", "depth_target", "datum", "chamfer")
MAX_SOURCE_BYTES = 2 * 1024 * 1024


class MigrationError(ValueError):
    def __init__(self, path, message):
        self.path = path
        super().__init__(message)


def _object(value, required, path, optional=()):
    if not isinstance(value, dict) or not set(required) <= value.keys() or value.keys() - set(required) - set(optional):
        raise MigrationError(path, "对象字段不完整或包含未支持字段")
    return value


def _text(value, path, maximum=4000, empty=False):
    if not isinstance(value, str) or len(value) > maximum or (not empty and not value):
        raise MigrationError(path, "文本字段类型、长度或空值无效")
    return value


def _num(value, path, low=None, high=None):
    if not isinstance(value, str) or len(value) > 24 or not re.fullmatch(r"-?[0-9]+(?:\.[0-9]{1,3})?", value):
        raise MigrationError(path, "旧数值须为最多三位小数的有限十进制字符串")
    number = D(value)
    if (low is not None and number < D(str(low))) or (high is not None and number > D(str(high))):
        raise MigrationError(path, "旧数值超出支持范围")
    return value


def _fingerprint(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _verify_fingerprint(value, expected, path):
    if not isinstance(expected, str) or not re.fullmatch(r"[a-f0-9]{64}", expected) or _fingerprint(value) != expected:
        raise MigrationError(path, "来源指纹不匹配")


def part_origins(part):
    """Individual band starts; legacy middle keyways use origins['shoulder']."""
    _object(part, PART_FIELDS, "/part")
    lengths = _object(part["lengths"], ORDER, "/lengths")
    cursor = D(0)
    origins = {}
    for key in ORDER:
        origins[key] = cursor
        cursor += D(_num(lengths[key], "/lengths/" + key, 5, 1200))
    if cursor > 2000 or D(lengths["left"]) < 25:
        raise MigrationError("/lengths", "旧轴段总长或端部范围无效")
    return origins


def _validate_part(part):
    """Validate the archived domain.py input shape, without loading that product."""
    origins = part_origins(part)
    if part["format"] != "nctool-shaft/1":
        raise MigrationError("/format", "未支持的旧零件格式")
    for field, limit in (("code", 48), ("title", 120), ("machine_profile", 120), ("notes", 4000)):
        _text(part[field], "/" + field, limit, empty=field == "notes")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,48}", part["code"]):
        raise MigrationError("/code", "零件号格式无效")
    if part["machine_profile"] != "index-g420-14594226":
        raise MigrationError("/machine_profile", "未支持的旧机床方案")
    if type(part["measurement"]) is not bool:
        raise MigrationError("/measurement", "测量开关须为布尔值")
    dimensions = _object(part["diameters"], OLD_DIAMETERS, "/diameters")
    for role, item in dimensions.items():
        path = "/diameters/" + role
        _object(item, ("nominal", "lower", "upper", "fit"), path)
        for key, low, high in (("nominal", 20, 400), ("lower", 10, 450), ("upper", 10, 450)):
            _num(item[key], path + "/" + key, low, high)
        nominal, low, high = (D(item[k]) for k in ("nominal", "lower", "upper"))
        if low > high or abs(low - nominal) > 2 or abs(high - nominal) > 2:
            raise MigrationError(path, "尺寸上下限无效")
        _text(item["fit"], path + "/fit", 24, empty=True)
    nominal = {role: D(item["nominal"]) for role, item in dimensions.items()}
    if nominal["cap"] != nominal["left"] or not nominal["left"] < nominal["middle"] <= nominal["right"] or nominal["tail"] >= nominal["right"] or nominal["bearing"] > nominal["middle"]:
        raise MigrationError("/diameters", "尺寸关系不符合旧格式支持范围")
    stock = _object(part["stock"], ("diameter", "center_depth", "spindle_limit"), "/stock")
    for key, low, high in (("diameter", 30, 500), ("center_depth", 1, 60), ("spindle_limit", 50, 3000)):
        _num(stock[key], "/stock/" + key, low, high)
    if D(stock["spindle_limit"]) != D(stock["spindle_limit"]).to_integral_value():
        raise MigrationError("/stock/spindle_limit", "主轴上限须为整数")
    cutting = _object(part["cutting"], CUTTING_FIELDS, "/cutting")
    for key, low, high in (("diameter_allowance", 0, 2), ("fs_face_allowance", 0, .5),
                           ("rough_remaining", .2, 6), ("ap1", .5, 8), ("ap2", .5, 10),
                           ("feed", .01, 1), ("black_drop", .5, 10)):
        _num(cutting[key], "/cutting/" + key, low, high)
    if D(cutting["feed"]) != D(cutting["feed"]).quantize(D(".01")):
        raise MigrationError("/cutting/feed", "旧同步进给须为0.01的整数倍")
    targets = [D(item["upper"]) + D(cutting["diameter_allowance"]) for item in dimensions.values()]
    if D(stock["diameter"]) - D(cutting["black_drop"]) <= max(targets) + D(cutting["rough_remaining"]):
        raise MigrationError("/stock/diameter", "旧去黑皮及粗车余量超出材料范围")
    _object(part["tools"], LEGACY_TO_ROLES, "/tools")
    for role, name in part["tools"].items():
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,40}", name):
            raise MigrationError("/tools/" + role, "刀具标识无效")
    if not isinstance(part["keys"], list) or not 1 <= len(part["keys"]) <= 3:
        raise MigrationError("/keys", "旧键槽须为1～3项列表")
    seen = set()
    for index, item in enumerate(part["keys"]):
        path = "/keys/" + str(index)
        _object(item, KEY_FIELDS, path)
        if not isinstance(item["id"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,47}", item["id"]) or item["id"] in seen:
            raise MigrationError(path + "/id", "键槽ID无效、重复或新契约无法表示")
        seen.add(item["id"])
        _text(item["title"], path + "/title", 80)
        if not isinstance(item["region"], str) or item["region"] not in LEGACY_REGIONS:
            raise MigrationError(path + "/region", "旧键槽区域无效")
        if not isinstance(item["datum"], str) or item["datum"] not in LEGACY_DATUM:
            raise MigrationError(path + "/datum", "旧定位基准无效")
        if type(item["chamfer"]) is not bool:
            raise MigrationError(path + "/chamfer", "倒角开关须为布尔值")
        for key, low, high in (("offset", 1, 1500), ("length", 20, 1200), ("width", 28, 80),
                               ("radius", 8, 40), ("depth_lower", 1, 30), ("depth_upper", 1, 30), ("depth_target", 1, 30)):
            _num(item[key], path + "/" + key, low, high)
        if not D(item["depth_lower"]) <= D(item["depth_target"]) <= D(item["depth_upper"]):
            raise MigrationError(path + "/depth_target", "槽深目标不在图纸区间内")
    return origins


def _extract(data):
    """Known bare parts, raw run/project records, or fingerprinted stored records."""
    if not isinstance(data, dict):
        raise MigrationError("/", "来源须为JSON对象")
    verified = []
    if "payload" in data or "sha256" in data:
        _object(data, ("payload", "sha256"), "/")
        _verify_fingerprint(data["payload"], data["sha256"], "/sha256")
        verified.append("payload.sha256")
        data = data["payload"]
        if not isinstance(data, dict):
            raise MigrationError("/payload", "来源记录须为对象")
    if "format" in data:
        if data["format"] != "nctool-shaft/1":
            raise MigrationError("/format", "未支持的旧来源格式")
        part, created = data, ""
    elif "result" in data:
        _object(data, ("id", "created", "result"), "/record")
        _text(data["id"], "/record/id", 48)
        created = _text(data["created"], "/record/created", 120)
        result = data["result"]
        if not isinstance(result, dict) or result.get("format") != "nctool-shaft-result/1" or "part" not in result:
            raise MigrationError("/record/result", "旧结果格式或零件字段无效")
        part = result["part"]
        if "input_fingerprint" in result:
            _verify_fingerprint(part, result["input_fingerprint"], "/record/result/input_fingerprint")
            verified.append("result.input_fingerprint")
    elif "part" in data:
        _object(data, ("id", "updated", "part"), "/record")
        _text(data["id"], "/record/id", 48)
        created = _text(data["updated"], "/record/updated", 120)
        part = data["part"]
    else:
        raise MigrationError("/", "来源不是支持的旧零件、运行或项目记录")
    _validate_part(part)
    return part, created, verified


def read_legacy_jobs(runs_dir: Path):
    jobs = []
    if not runs_dir.is_dir():
        raise MigrationError(str(runs_dir), "旧来源目录不存在")
    for path in sorted(runs_dir.glob("*.json")):
        try:
            raw = path.read_bytes()
            if len(raw) > MAX_SOURCE_BYTES:
                raise MigrationError(str(path), "来源超过2MB")
            data = load_json(raw.decode("utf-8"))
            part, created, verified = _extract(data)
            jobs.append({"source": path.name, "created": created, "part": part,
                         "source_sha256": hashlib.sha256(raw).hexdigest(), "verified_fingerprints": verified})
        except MigrationError as error:
            raise MigrationError(str(path) + ":" + error.path, str(error)) from error
        except (OSError, ValueError, TypeError, UnicodeError, RecursionError, OverflowError) as error:
            raise MigrationError(str(path), "无法读取旧JSON: " + str(error)) from error
    if not jobs:
        raise MigrationError(str(runs_dir), "来源目录没有JSON记录")
    return jobs


def _note(field, why, action):
    return {"field": field, "why": why, "action": action}


def migrate_part(part):
    origins = _validate_part(part)
    diameters = {key: {name: part["diameters"][key][name] for name in ("nominal", "lower", "upper")}
                 for key in OLD_DIAMETERS}
    # Legacy shoulder geometry explicitly uses middle (domain.py surface_intervals).
    diameters["shoulder"] = deepcopy(diameters["middle"])
    notes = [_note("part.diameters.shoulder", "旧生成器肩部使用middle尺寸，按该几何复制", "按本次图纸核定肩部尺寸")]
    keys = []
    expected = {}
    for index, item in enumerate(part["keys"]):
        path = "/keys/" + str(index)
        region = item["region"]
        origin = origins["shoulder"] if region == "middle" else origins[region]
        start = origin + D(item["offset"])
        end = start + D(item["length"])
        surface = region
        if region == "middle":
            candidates = [key for key in ("shoulder", "bearing", "middle")
                          if origins[key] <= start and end <= origins[key] + D(part["lengths"][key]) - 1]
            if len(candidates) != 1:
                raise MigrationError(path, "旧middle键槽跨越新轴段或端部余距不足，无法完整保持槽几何")
            surface = candidates[0]
        offset = start if region == "left" else start - origins[surface]
        floor = D(part["diameters"][region]["nominal"]) / 2 - D(item["depth_target"])
        depth = D(diameters[surface]["nominal"]) / 2 - floor
        keys.append({"id": item["id"], "title": item["title"], "surface": surface,
                     "offset": item["offset"] if region == "left" else format(offset, "f"),
                     "depth": item["depth_target"] if surface == region else format(depth, "f"),
                     **{key: item[key] for key in ("length", "width", "radius", "depth_lower", "depth_upper")},
                     "datum": LEGACY_DATUM[item["datum"]]})
        expected[item["id"]] = (start, end, floor)
    migrated = {"lengths": deepcopy(part["lengths"]), "diameters": diameters, "keys": keys, "reliefs": [], "rings": []}
    # Feasibility check uses temporary confirmed flags only; exported draft stays blocked.
    geometry_job = _job(part, migrated)
    geometry_job["drawing"] = {"reference": "geometry-check-only", "status": "confirmed"}
    geometry_job["material"] = "geometry-check-only"
    geometry_job["stock"]["incoming_prepared"] = True
    try:
        resolved = resolve(geometry_job)
    except InvalidJob as error:
        raise MigrationError(error.path, "新工具不能完整表示旧输入: " + str(error)) from error
    for key, (start, end, floor) in expected.items():
        feature = resolved["features"][key]
        if (feature["s0"], feature["s1"], feature["floor"]) != (start, end, floor):
            raise MigrationError("/keys/" + key, "新工具的输出精度会改变旧槽位置或槽底，拒绝迁移")
    for field, why, action in (
        ("part.reliefs", "旧ES/FS几何来自固定生成器，非显式输入", "重新声明槽尺寸、来源并核定"),
        ("part.rings", "旧环槽来自固定循环，非显式输入", "重新声明环槽与刀具尺寸"),
        ("part.transitions", "旧肩部加工未记录逐侧过渡输入", "重新声明并核定各侧肩部"),
    ):
        notes.append(_note(field, why, action))
    return migrated, notes


def _job(legacy, part):
    return {
        "format": 1, "code": legacy["code"], "title": legacy["title"], "material": "",
        "drawing": {"reference": "", "status": "pending"}, "part": part,
        "stock": {**deepcopy(legacy["stock"]), "incoming_prepared": False},
        "recipe": {"id": "migrated-pending", "version": 1, "title": "部分迁移草稿（待重建工序）",
                   "allowance": legacy["cutting"]["diameter_allowance"],
                   "face_allowance": legacy["cutting"]["fs_face_allowance"],
                   "basis": "仅迁移显式输入；不得继承旧生成结果或机床验收", "steps": []},
    }


def build_job(record, machine_id="index-g420-pilot"):
    part, notes = migrate_part(record["part"])
    return _job(record["part"], part), notes


def build_machine(record):
    legacy = record["part"]
    _validate_part(legacy)
    return {
        "id": "index-g420-pilot", "version": 1, "title": legacy["machine_profile"] + " · 待核定",
        # precision is the implementation's required output grid, not a site fact.
        "precision": "0.001", "max_rpm": "", "safe_gap": "", "origin_z": "",
        "tool_geometry_status": "待核定：仅保留旧角色与刀号，未记录的刀径和现场能力为空",
        "tools": {role: {"name": name, "kind": "mill" if role.startswith("key_") else "chamfer" if role == "chamfer" else "turn", "diameter": ""}
                  for role, name in legacy["tools"].items()},
        "external_dependencies": [],
        "qualification": {key: "" for key in ("machine_identity", "controller_model", "controller_version",
                                               "axis_mapping", "tooling_record", "workholding_record", "cycle_record")},
        "acceptance": "not_performed",
    }


def to_draft(record, machine_id="index-g420-pilot"):
    if machine_id != "index-g420-pilot":
        raise MigrationError("/machine/id", "新工具仅支持INDEX试点实现；此ID不代表旧现场验收")
    job, _ = build_job(record, machine_id)
    draft = {"job": job, "machine": build_machine(record)}
    try:
        validate_document(draft["job"], draft["machine"])
    except InvalidJob as error:
        raise MigrationError(error.path, "新文档结构无效: " + str(error)) from error
    return draft


def migration_report(record, draft):
    legacy = record["part"]
    _, notes = migrate_part(legacy)
    unmapped = {"cutting": {key: value for key, value in legacy["cutting"].items()
                            if key not in ("diameter_allowance", "fs_face_allowance")},
                "measurement": legacy["measurement"], "notes": legacy["notes"],
                "fit": {role: dim["fit"] for role, dim in legacy["diameters"].items()},
                "key_chamfer": {item["id"]: item["chamfer"] for item in legacy["keys"]},
                "machine_profile": legacy["machine_profile"]}
    for field in unmapped:
        notes.append(_note(field, "原始值保存在unmapped及source_part中，未应用到新草稿", "按本次图纸/工序/现场资料显式重建并核定"))
    notes.extend([
        _note("machine", "现场原点、间隙、机床上限、刀径和资格资料未记录，留空", "填写真实现场资料；precision仅为新实现要求的0.001输出网格"),
        _note("job", "材料、图纸确认、来料确认及工序链尚未迁移", "补齐并确认；当前pending/空机床数值/空工序链阻断生成"),
    ])
    return {"format": "nctool-shaft-migration-report/1", "status": "partial_pending_confirmation",
            "source": record["source"], "created": record.get("created", ""),
            "source_sha256": record.get("source_sha256"), "verified_fingerprints": record.get("verified_fingerprints", []),
            "draft_sha256": _fingerprint(draft), "source_part": deepcopy(legacy), "unmapped": unmapped,
            "notes": notes, "legacy_results_reused": False, "machine_acceptance": "not_performed"}


def _publish(out_dir, files):
    """Stage complete bytes, then exclusively create the destination; roll back on IO failure."""
    if out_dir.exists() or out_dir.is_symlink():
        raise MigrationError(str(out_dir), "输出目录已存在，拒绝覆盖；请选择新目录")
    if not out_dir.parent.is_dir():
        raise MigrationError(str(out_dir.parent), "输出父目录须已存在")
    stage = Path(tempfile.mkdtemp(prefix=".migration-", dir=out_dir.parent))
    published = []
    created = False
    try:
        for name, raw in files.items():
            with (stage / name).open("xb") as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
        out_dir.mkdir()  # Exclusive, including directories created by concurrent writers.
        created = True
        for name in files:
            target = out_dir / name
            os.link(stage / name, target)  # Never replace a concurrently created file.
            published.append(target)
    except OSError as error:
        for target in published:
            target.unlink()
        if created:
            out_dir.rmdir()
        raise MigrationError(str(out_dir), "发布失败，未保留本批次输出: " + str(error)) from error
    finally:
        shutil.rmtree(stage)


def cmd_draft(argv):
    if not 1 <= len(argv) <= 2:
        raise MigrationError("/arguments", "用法: workbench_migrate.py draft <legacy-json-dir> [new-out-dir]")
    rows, files = [], {}
    for record in read_legacy_jobs(Path(argv[0])):
        draft = to_draft(record)
        report = migration_report(record, draft)
        row = {"source": record["source"], "ok": True, "draft": draft, "report": report}
        rows.append(row)
        stem = Path(record["source"]).stem
        for suffix, value in (("draft", draft), ("report", report)):
            name = stem + "-" + suffix + ".json"
            if name in files:
                raise MigrationError(name, "输出文件名冲突")
            files[name] = (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")
    if len(argv) == 2:
        _publish(Path(argv[1]), files)
    return rows


def main(argv):
    if argv == ["help"]:
        print("usage: workbench_migrate.py draft <legacy-json-dir> [new-out-dir]")
        return 0
    try:
        if not argv or argv[0] != "draft":
            raise MigrationError("/arguments", "需要draft命令；使用help查看用法")
        rows = cmd_draft(argv[1:])
        print(json.dumps({"ok": True, "status": "partial_pending_confirmation", "records": rows}, ensure_ascii=True, allow_nan=False))
        return 0
    except (MigrationError, OSError, ValueError, TypeError, RecursionError, OverflowError) as error:
        print(json.dumps({"ok": False, "error": {"path": getattr(error, "path", "/"), "message": str(error)}}, ensure_ascii=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
