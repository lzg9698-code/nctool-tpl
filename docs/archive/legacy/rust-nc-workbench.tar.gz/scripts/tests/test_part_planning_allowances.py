import copy
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'prototypes/part_planning'))
from allowances import calculate


class AllowanceTests(unittest.TestCase):
    def setUp(self):
        self.draft=json.loads((ROOT/'prototypes/part_planning/14594226.layout-draft.json').read_text(encoding='utf-8'))
        self.rules=json.loads((ROOT/'prototypes/part_planning/14594226.allowance-rules.json').read_text(encoding='utf-8'))

    def result(self):return calculate(self.draft,self.rules,ROOT)

    def test_upper_plus_diameter_allowance(self):
        targets={t['dimension_id']:t for t in self.result()['outer_targets']}
        self.assertEqual(targets['left_diameter']['candidate_target_diameter'],'100.535')
        self.assertEqual(targets['right_diameter']['candidate_target_diameter'],'135.588')
        self.assertEqual(targets['bearing_diameter']['candidate_target_diameter'],'120.300')
        self.assertEqual(targets['left_diameter']['equivalent_radial_allowance'],'0.250')

    def test_historical_difference_and_input_preserved(self):
        before=copy.deepcopy(self.draft)
        r=self.result()
        self.assertEqual(self.draft,before)
        self.assertEqual(r['historical_comparisons'][0]['candidate_minus_historical'],'0.135')
        self.assertEqual(r['readiness'],'blocked')
        self.assertFalse(r['nc_generation_supported'])

    def test_missing_upper_never_uses_nominal(self):
        self.draft['dimensions'][5]['upper']=None
        self.draft['dimensions'][5]['lower']=None
        with self.assertRaises(ValueError):self.result()

    def test_radius_increment_cannot_masquerade_as_diameter(self):
        self.rules['outer_diameter']['quantity']='radial_increment'
        with self.assertRaises(ValueError):self.result()

    def test_negative_nan_and_duplicate_selection_rejected(self):
        for value in ('-0.5','NaN'):
            with self.subTest(value=value):
                self.rules['outer_diameter']['amount']=value
                with self.assertRaises(ValueError):self.result()
        self.rules['outer_diameter']['amount']='0.500'
        self.rules['outer_dimension_ids'].append('left_diameter')
        with self.assertRaises(ValueError):self.result()

    def test_es_scope_is_only_end_face(self):
        self.assertEqual(self.result()['es_end_face']['amount'],'0')
        self.rules['es_end_face']['scope']='all_surfaces'
        with self.assertRaises(ValueError):self.result()

    def test_fs_pending_does_not_create_coordinate(self):
        self.rules['fs_face'].update(status='amount_confirmed_axis_pending',quantity=None,scope=None)
        self.assertIsNone(self.result()['fs_face']['coordinate_offset'])
        self.rules['fs_face']['quantity']='axial_face_offset'
        with self.assertRaises(ValueError):self.result()

    def test_fs_single_face_still_needs_material_direction(self):
        self.rules['fs_face'].update(status='confirmed',quantity='axial_face_offset',scope='single_face')
        r=self.result()['fs_face']
        self.assertEqual(r['status'],'axial-single-face-rule-confirmed')
        self.assertIsNone(r['coordinate_offset'])

    def test_bad_evidence_stops_targets(self):
        self.draft['sources'][0]['sha256']='0'*64
        with self.assertRaises(ValueError):self.result()

    def test_candidate_arithmetic_never_silently_rounds_source(self):
        next(d for d in self.draft['dimensions'] if d['id']=='left_diameter')['upper']='100.035001'
        r=self.result()
        self.assertEqual(r['outer_targets'][0]['candidate_target_diameter'],'100.535001')
        self.assertEqual(r['historical_comparisons'][0]['candidate_minus_historical'],'0.135001')

    def test_user_confirmed_fs_rule_is_preserved_in_current_output(self):
        self.assertEqual(self.rules['fs_face']['status'],'confirmed')
        fs=self.result()['fs_face']
        self.assertEqual(fs['amount'],'0.100')
        self.assertEqual(fs['quantity'],'axial_face_offset')
        self.assertEqual(fs['scope'],'single_face')
        self.assertIsNone(fs['coordinate_offset'])

    def test_groove_contour_allowance_is_independent_of_face_and_diameter(self):
        r=self.result()
        self.assertEqual(r['fs_face']['amount'],'0.100')
        self.assertEqual(r['outer_targets'][0]['allowance_diameter'],'0.500')
        for kind in ('ES','FS'):
            g=r['groove_trajectories'][kind]
            self.assertEqual((g['local_x_allowance'],g['local_z_allowance']),('0','0'))
            self.assertEqual(g['placement_reference'],'from-process-face-geometry')

    def test_groove_contour_cannot_inherit_other_allowances(self):
        for amount in ('0.100','0.500'):
            with self.subTest(amount=amount):
                self.rules['groove_trajectory']['amount']=amount
                with self.assertRaises(ValueError):self.result()

    def test_missing_or_partial_groove_policy_fails_closed(self):
        for change in ('missing','only-fs','wrong-quantity'):
            with self.subTest(change=change):
                rules=copy.deepcopy(self.rules)
                if change=='missing':del rules['groove_trajectory']
                elif change=='only-fs':rules['groove_trajectory']['kinds']=['FS']
                else:rules['groove_trajectory']['quantity']='axial_face_offset'
                with self.assertRaises((ValueError,KeyError)):calculate(self.draft,rules,ROOT)

    def test_fixed_keyway_floors_and_postgrind_depth_ranges(self):
        floors={f['feature_id']:f for f in self.result()['keyway_floors']}
        a,b=floors['keyway-a'],floors['keyway-b']
        self.assertEqual((a['bottom_radius'],b['bottom_radius']),('39.900','55.400'))
        self.assertEqual((a['pregrind_depth_from_current_outer_surface'],b['pregrind_depth_from_current_outer_surface']),('10.3675','12.394'))
        self.assertEqual((a['postgrind_depth_min'],a['postgrind_depth_max']),('10.1065','10.1175'))
        self.assertEqual((b['postgrind_depth_min'],b['postgrind_depth_max']),('12.1315','12.144'))

    def test_outer_allowance_change_does_not_move_keyway_bottom(self):
        first=self.result()['keyway_floors']
        self.rules['outer_diameter']['amount']='0.700'
        second=self.result()['keyway_floors']
        self.assertEqual([f['bottom_radius'] for f in first],[f['bottom_radius'] for f in second])
        self.assertEqual([f['postgrind_depth_min'] for f in first],[f['postgrind_depth_min'] for f in second])
        self.assertNotEqual(first[0]['pregrind_depth_from_current_outer_surface'],second[0]['pregrind_depth_from_current_outer_surface'])

    def test_following_outer_allowance_or_invalid_floor_rejected(self):
        self.rules['keyway_bottom']['follow_pregrind_outer_allowance']=True
        with self.assertRaises(ValueError):self.result()
        self.rules['keyway_bottom']['follow_pregrind_outer_allowance']=False
        next(c for c in self.draft['process_candidates'] if c['id']=='keyway-a-z')['value']='-12.100'
        with self.assertRaises(ValueError):self.result()


if __name__=='__main__':unittest.main()
