import copy
import importlib.util
import json
from pathlib import Path
import sys
import unittest
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'prototypes/part_planning'))
from preflight import check,markdown
from layout import inspect,svg


class AxialLayoutTests(unittest.TestCase):
    def setUp(self):
        self.data=json.loads((ROOT/'prototypes/part_planning/14594226.layout-draft.json').read_text(encoding='utf-8'))

    def test_drawing_landmarks_and_nominal_keyway_positions(self):
        r=check(self.data,ROOT)
        self.assertTrue(r['structurally_valid'],r['errors'])
        self.assertEqual(r['readiness'],'blocked')
        self.assertEqual(len(r['checks']),30)
        values=r['axial_layout']['landmarks']
        self.assertEqual({k:values[k] for k in ('z0','z210','z232','z261','z308','z494','z527')},
                         {'z0':'0','z210':'210','z232':'232','z261':'261','z308':'308','z494':'494','z527':'527'})
        self.assertEqual((values['a_start'],values['a_end']),('6','203'))
        self.assertEqual((values['b_start'],values['b_end']),('315','486'))

    def test_nominal_change_propagates_and_reference_mismatch_rejected(self):
        node=next(n for n in self.data['axial_layout']['landmarks'] if n['id']=='b_start')
        next(d for d in self.data['dimensions'] if d['id']=='b_start_offset')['nominal']='8'
        r=inspect(self.data)
        self.assertFalse(r['errors'])
        self.assertEqual((r['landmarks']['b_start'],r['landmarks']['b_end']),('316','487'))
        next(d for d in self.data['dimensions'] if d['id']=='middle_zone_length')['nominal']='48'
        self.assertIn('invalid_landmark',[e['code'] for e in inspect(self.data)['errors']])

    def test_cycle_unknown_ref_and_duplicate_landmark(self):
        for kind in ('cycle','unknown','duplicate'):
            with self.subTest(kind=kind):
                data=copy.deepcopy(self.data)
                if kind=='cycle':data['axial_layout']['landmarks'][1]['terms']=[{'kind':'landmark','id':'z232','coefficient':1}]
                elif kind=='unknown':data['axial_layout']['landmarks'][1]['terms'][0]['id']='missing'
                else:data['axial_layout']['landmarks'].append(copy.deepcopy(data['axial_layout']['landmarks'][0]))
                self.assertTrue(inspect(data)['errors'])

    def test_gap_overlap_reverse_and_missing_band(self):
        for kind in ('gap','overlap','reverse','missing'):
            with self.subTest(kind=kind):
                data=copy.deepcopy(self.data)
                if kind=='gap':data['axial_layout']['bands'][1]['start']='z232'
                elif kind=='overlap':data['axial_layout']['bands'][1]['start']='z0'
                elif kind=='reverse':data['axial_layout']['bands'][1]['end']='z0'
                else:data['axial_layout']['bands'].pop()
                self.assertTrue(inspect(data)['errors'])

    def test_feature_length_owner_range_and_unknown_feature(self):
        for kind in ('range','length','feature'):
            with self.subTest(kind=kind):
                data=copy.deepcopy(self.data)
                pos=data['axial_layout']['feature_positions'][1]
                if kind=='range':pos['owner_end']='z308'
                elif kind=='length':pos['end']='z494'
                else:pos['feature_id']='missing'
                self.assertIn('invalid_feature_position',[e['code'] for e in inspect(data)['errors']])

    def test_false_profile_completion_and_invalid_evidence(self):
        self.data['axial_layout']['bands'][0]['detail_status']='confirmed'
        self.data['axial_layout']['feature_positions'][1]['evidence'][0]['source_id']='turning'
        r=inspect(self.data)
        self.assertIn('invalid_band',[e['code'] for e in r['errors']])
        self.assertIn('invalid_feature_position',[e['code'] for e in r['errors']])

    def test_malformed_layout_contract_returns_errors(self):
        for replacement in (None,[],{},dict(self.data['axial_layout'],bands=None)):
            with self.subTest(kind=type(replacement)):
                data=copy.deepcopy(self.data);data['axial_layout']=replacement
                self.assertFalse(check(data,ROOT)['structurally_valid'])

    def test_svg_is_layout_only_escapes_text_and_rejects_errors(self):
        r=inspect(self.data)
        text=svg(r);ET.fromstring(text)
        self.assertIn('没有描画成品轮廓',text)
        r['feature_positions'][0]['feature_id']='<script>'
        escaped=svg(r);ET.fromstring(escaped)
        self.assertIn('&lt;script&gt;',escaped)
        r['errors'].append({'code':'bad'})
        with self.assertRaises(ValueError):svg(r)

    def test_report_exposes_nominal_positions_and_geometry_limit(self):
        text=markdown(check(self.data,ROOT))
        self.assertIn('| keyway-b | 315 | 486 |',text)
        self.assertIn('不是机床坐标或完整成品轮廓',text)
        self.assertIn('axial-layout.svg',text)


if __name__=='__main__':unittest.main()
