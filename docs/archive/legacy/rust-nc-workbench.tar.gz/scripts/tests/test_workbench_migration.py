# -*- coding: utf-8 -*-
"""Synthetic migration fixtures; never inspect legacy runtime/user directories."""
from copy import deepcopy
from decimal import Decimal as D
import hashlib
import http.client
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from scripts.dev import workbench_migrate as migration
from scripts.dev.workbench_migrate import (
    MigrationError, build_machine, cmd_draft, migrate_part, migration_report,
    part_origins, read_legacy_jobs, to_draft,
)
from shaft_programmer.common import load_json
from shaft_programmer.core.document import validate_document
from shaft_programmer.core.generate import generate
from shaft_programmer.core.model import encoded, fingerprint, InvalidJob
from shaft_programmer.core.targets import resolve
from shaft_programmer.machines.index_g420 import validate_machine


def legacy_tools():
    return {"rough1": "T91", "rough2": "T51", "finish1": "T71", "finish2": "T81", "relief1": "T121",
            "relief3": "T31", "rings": "T141", "key_rough_a": "CUT_A", "key_finish_a": "FIN_A",
            "key_rough_b": "CUT_B", "key_finish_b": "FIN_B", "chamfer": "CHAMFER_TEST"}


def legacy_part(**overrides):
    part = {
        "format": "nctool-shaft/1", "code": "SYNTHETIC", "title": "合成迁移输入",
        "machine_profile": "index-g420-14594226",
        "lengths": {"left": "210", "shoulder": "22", "bearing": "29", "middle": "47", "right": "186", "tail": "33"},
        "diameters": {"left": {"nominal": "100", "lower": "100.013", "upper": "100.035", "fit": "m6"},
                      "cap": {"nominal": "100", "lower": "99.913", "upper": "100", "fit": "h9"},
                      "middle": {"nominal": "120", "lower": "120.013", "upper": "120.035", "fit": "m6"},
                      "bearing": {"nominal": "119.8", "lower": "119.746", "upper": "119.8", "fit": "h8"},
                      "right": {"nominal": "135", "lower": "135.063", "upper": "135.088", "fit": "r6"},
                      "tail": {"nominal": "100", "lower": "99.913", "upper": "100", "fit": "h9"}},
        "stock": {"diameter": "150", "center_depth": "29.61", "spindle_limit": "600"},
        "cutting": {"diameter_allowance": "0.7", "fs_face_allowance": "0.2", "rough_remaining": "3",
                    "ap1": "4", "ap2": "4.5", "feed": "0.4", "black_drop": "6"},
        "keys": [{"id": "key-a", "title": "合成槽 A", "region": "left", "offset": "6", "length": "197.25",
                  "width": "28", "radius": "8", "depth_lower": "10", "depth_upper": "10.2",
                  "depth_target": "10.1", "datum": "high-end", "chamfer": True}],
        "tools": legacy_tools(), "measurement": True, "notes": "合成来源备注，不得静默丢弃",
    }
    part.update(overrides)
    return part


def middle_key(offset="56", length="35"):
    return {**legacy_part()["keys"][0], "id": "key-middle", "region": "middle", "offset": offset,
            "length": length, "depth_lower": "6.9", "depth_upper": "7.2", "depth_target": "7.1"}


def record(part=None):
    return {"source": "synthetic.json", "created": "2026-10-14T00:00:00Z", "part": part or legacy_part()}


def run_payload(part=None):
    part = part or legacy_part()
    return {"id": "a" * 32, "created": "2026-10-14T00:00:00Z",
            "result": {"format": "nctool-shaft-result/1", "part": part, "input_fingerprint": fingerprint(part),
                       "programs": {"1_0.MPF": "; OLD SYNTHETIC NC MUST NOT MIGRATE"}, "machine_acceptance": "not_performed"}}


class MigrationTest(unittest.TestCase):
    def resolved(self, part):
        draft = to_draft(record(part))
        job = deepcopy(draft["job"])
        job["drawing"] = {"reference": "geometry-check-only", "status": "confirmed"}
        job["material"] = "geometry-check-only"
        job["stock"]["incoming_prepared"] = True
        return resolve(job)

    def test_left_offset_preserves_drawing_origin_before_at_and_after_cap(self):
        for offset, length in (("6", "197.25"), ("17", "100"), ("30", "100")):
            with self.subTest(offset=offset):
                legacy = legacy_part(keys=[{**legacy_part()["keys"][0], "offset": offset, "length": length}])
                part, _ = migrate_part(legacy)
                self.assertEqual(part["keys"][0]["surface"], "left")
                self.assertEqual(part["keys"][0]["offset"], offset)
                feature = self.resolved(legacy)["features"]["key-a"]
                self.assertEqual(feature["s0"], D(offset))
                self.assertEqual(feature["s1"], D(offset) + D(length))
                self.assertEqual(feature["floor"], D("39.9"))
                self.assertEqual(feature["z_anchor"], D("527") - D(offset) - D("8"))

    def test_middle_positions_and_fixed_floor_map_to_each_new_band(self):
        for offset, length, surface, local, depth in (("1", "20", "shoulder", "1", "7.1"),
                                                      ("23", "20", "bearing", "1", "7.0"),
                                                      ("56", "35", "middle", "5", "7.1")):
            with self.subTest(surface=surface):
                legacy = legacy_part(keys=[middle_key(offset, length)])
                part, _ = migrate_part(legacy)
                key = part["keys"][0]
                self.assertEqual((key["surface"], key["offset"], key["depth"]), (surface, local, depth))
                feature = self.resolved(legacy)["features"]["key-middle"]
                self.assertEqual(feature["s0"], D("210") + D(offset))
                self.assertEqual(feature["s1"], D("210") + D(offset) + D(length))
                self.assertEqual(feature["floor"], D("52.9"))

    def test_right_and_tail_keep_their_origins(self):
        for region, start in (("right", "308"), ("tail", "494")):
            legacy = legacy_part(keys=[{**legacy_part()["keys"][0], "region": region, "offset": "1", "length": "20"}])
            feature = self.resolved(legacy)["features"]["key-a"]
            self.assertEqual(feature["s0"], D(start) + 1)

    def test_middle_crossing_or_less_than_one_mm_end_margin_is_refused(self):
        for key in (middle_key("25", "35"), middle_key("2", "20"), middle_key("51", "47")):
            with self.subTest(key=key), self.assertRaises(MigrationError):
                migrate_part(legacy_part(keys=[key]))

    def test_floor_rounding_cannot_be_accepted_as_a_geometry_change(self):
        legacy = legacy_part(keys=[middle_key()])
        legacy["diameters"]["middle"]["nominal"] = "120.001"
        with self.assertRaisesRegex(MigrationError, "精度"):
            migrate_part(legacy)

    def test_invalid_cross_surface_depth_is_refused(self):
        legacy = legacy_part()
        legacy["diameters"]["cap"]["lower"] = "99"
        with self.assertRaises(MigrationError):
            migrate_part(legacy)

    def test_depth_that_cannot_be_preserved_on_bearing_is_refused(self):
        key = middle_key("23", "20")
        key["depth_lower"] = "7"
        with self.assertRaises(MigrationError):
            migrate_part(legacy_part(keys=[key]))

    def test_frozen_geometry_is_reported_and_explicit_fields_are_preserved(self):
        source = record()
        before = deepcopy(source)
        draft = to_draft(source)
        report = migration_report(source, draft)
        self.assertEqual(source, before)
        self.assertEqual(set(draft), {"job", "machine"})
        self.assertEqual(report["source_part"], source["part"])
        self.assertEqual(report["status"], "partial_pending_confirmation")
        self.assertEqual(report["unmapped"]["notes"], source["part"]["notes"])
        self.assertIs(report["unmapped"]["measurement"], True)
        self.assertEqual(report["unmapped"]["fit"]["bearing"], "h8")
        self.assertEqual(report["unmapped"]["cutting"]["ap2"], "4.5")
        self.assertEqual(report["unmapped"]["key_chamfer"], {"key-a": True})
        self.assertEqual(draft["job"]["recipe"]["allowance"], "0.7")
        self.assertEqual(draft["job"]["recipe"]["face_allowance"], "0.2")
        self.assertEqual(draft["job"]["recipe"]["steps"], [])
        self.assertEqual(draft["job"]["part"]["reliefs"], [])
        self.assertEqual(draft["job"]["part"]["rings"], [])
        self.assertEqual(draft["job"]["part"]["diameters"]["shoulder"], draft["job"]["part"]["diameters"]["middle"])
        self.assertTrue(all(n["action"] for n in report["notes"]))
        self.assertLessEqual({"part.reliefs", "part.rings", "part.transitions"}, {n["field"] for n in report["notes"]})
        self.assertNotIn("OLD SYNTHETIC", json.dumps(draft))
        self.assertEqual(report["draft_sha256"], fingerprint(draft))

    def test_all_tools_preserve_ab_roles_and_unknown_site_values_are_blank(self):
        machine = build_machine(record())
        self.assertEqual(set(machine["tools"]), set(legacy_tools()))
        for role, name in legacy_tools().items():
            self.assertEqual(machine["tools"][role]["name"], name)
            self.assertEqual(machine["tools"][role]["diameter"], "")
        self.assertEqual([machine[k] for k in ("origin_z", "safe_gap", "max_rpm")], ["", "", ""])
        self.assertTrue(all(value == "" for value in machine["qualification"].values()))
        self.assertEqual(machine["acceptance"], "not_performed")
        self.assertEqual(machine["precision"], "0.001")
        with self.assertRaises(InvalidJob) as caught:
            validate_machine(machine)
        self.assertEqual(caught.exception.path, "/machine/origin_z")

    def test_structurally_valid_draft_is_blocked_and_has_no_partial_nc(self):
        draft = to_draft(record())
        validate_document(**draft)
        result = generate(**draft)
        self.assertFalse(result["ok"])
        self.assertEqual(result["diagnostics"][0]["path"], "/machine/origin_z")
        self.assertEqual(result["programs"], {})
        self.assertEqual(draft["job"]["drawing"]["status"], "pending")
        self.assertIs(draft["job"]["stock"]["incoming_prepared"], False)
        self.assertEqual(draft["job"]["material"], "")

    def test_empty_recipe_remains_blocked_after_fixture_confirms_other_fields(self):
        draft = to_draft(record())
        # Synthetic test facts only; these values never enter migrated output.
        machine = draft["machine"]
        machine.update(origin_z="0", max_rpm="600", safe_gap="4")
        for tool in machine["tools"].values():
            tool["diameter"] = "0" if tool["kind"] == "turn" else "10"
        job = draft["job"]
        job["material"] = "TEST ONLY"
        job["drawing"] = {"reference": "TEST ONLY", "status": "confirmed"}
        job["stock"]["incoming_prepared"] = True
        result = generate(**draft)
        self.assertFalse(result["ok"])
        self.assertEqual(result["diagnostics"][0]["path"], "/recipe/steps")
        self.assertEqual(result["programs"], {})

    def test_unknown_machine_override_is_refused(self):
        with self.assertRaises(MigrationError):
            to_draft(record(), "unknown")

    def test_migration_contract_does_not_import_sample_or_archived_workbench(self):
        script = ("import sys;sys.path.insert(0,sys.argv[1]);"
                  "sys.modules['shaft_programmer.sample']=None;sys.modules['workbench']=None;"
                  "from scripts.dev.workbench_migrate import to_draft")
        process = subprocess.run([sys.executable, "-I", "-c", script, str(REPO)], capture_output=True, timeout=10)
        self.assertEqual(process.returncode, 0, process.stderr)

    def test_malformed_explicit_inputs_are_structural_errors(self):
        cases = [("lengths", []), ("diameters", []), ("stock", None), ("cutting", []), ("tools", []),
                 ("keys", {}), ("measurement", "true"), ("notes", {}), ("format", "unknown")]
        for field, value in cases:
            with self.subTest(field=field), self.assertRaises(MigrationError):
                migrate_part(legacy_part(**{field: value}))
        for field, value in (("offset", "six"), ("offset", 6), ("region", []), ("datum", "unknown"),
                             ("chamfer", "yes"), ("depth_target", "NaN"), ("offset", "1e2"), ("id", [])):
            legacy = legacy_part()
            legacy["keys"][0][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(MigrationError):
                migrate_part(legacy)
        legacy = legacy_part()
        del legacy["lengths"]["tail"]
        with self.assertRaises(MigrationError):
            part_origins(legacy)
        legacy = legacy_part()
        del legacy["cutting"]["diameter_allowance"]
        with self.assertRaises(MigrationError):
            migrate_part(legacy)


class MigrationCliTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.sources = self.root / "sources"
        self.sources.mkdir()
        self.output = self.root / "new-drafts"

    def write(self, name="part.json", data=None, raw=None):
        path = self.sources / name
        path.write_text(raw if raw is not None else json.dumps(data if data is not None else legacy_part(), ensure_ascii=False), encoding="utf-8")
        return path

    def run_cli(self):
        process = subprocess.run([sys.executable, "-I", str(REPO / "scripts/dev/workbench_migrate.py"),
                                  "draft", str(self.sources), str(self.output)],
                                 capture_output=True, text=True, encoding="utf-8", timeout=30)
        return process, json.loads(process.stdout)

    def test_bare_and_fingerprinted_run_and_project_are_read(self):
        self.write()
        payload = run_payload()
        self.write("run.json", {"payload": payload, "sha256": fingerprint(payload)})
        project = {"id": "b" * 32, "updated": "2026-10-14", "part": legacy_part()}
        self.write("project.json", {"payload": project, "sha256": fingerprint(project)})
        records = read_legacy_jobs(self.sources)
        self.assertEqual(len(records), 3)
        self.assertEqual(records[2]["verified_fingerprints"], ["payload.sha256", "result.input_fingerprint"])
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 0, process.stderr + process.stdout)
        self.assertTrue(info["ok"])
        self.assertEqual(len(list(self.output.glob("*.json"))), 6)
        for file in self.output.glob("*-draft.json"):
            self.assertEqual(set(load_json(file.read_text(encoding="utf-8"))), {"job", "machine"})
        report = load_json((self.output / "run-report.json").read_text(encoding="utf-8"))
        self.assertEqual(report["source_sha256"], hashlib.sha256((self.sources / "run.json").read_bytes()).hexdigest())
        self.assertFalse(report["legacy_results_reused"])
        self.assertNotIn("OLD SYNTHETIC", (self.output / "run-draft.json").read_text(encoding="utf-8"))
        self.assertFalse(any(path.name.startswith(".migration-") for path in self.root.iterdir()))

    def test_bad_batch_writes_no_partial_files_and_exits_nonzero(self):
        self.write("a-valid.json")
        for bad in ("[]", "null", "{}", '{"format":"unknown"}', '{"payload":[]}',
                    '{"payload":null,"sha256":"bad"}', '{"id":"x","created":"today","result":[]}',
                    '{"format":"nctool-shaft/1","format":"unknown"}', '{"value":NaN}', '{"value":1e999}', "{", "﻿{}"):
            with self.subTest(raw=bad):
                self.write("z-bad.json", raw=bad)
                process, info = self.run_cli()
                self.assertEqual(process.returncode, 2, process.stderr)
                self.assertFalse(info["ok"])
                self.assertIn("path", info["error"])
                self.assertFalse(self.output.exists())

    def test_nested_duplicate_keys_are_rejected(self):
        raw = json.dumps(legacy_part()).replace('"left": "210"', '"left": "210", "left": "211"')
        self.write(raw=raw)
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 2)
        self.assertIn("重复", info["error"]["message"])
        self.assertFalse(self.output.exists())

    def test_fingerprints_are_verified_at_both_source_layers(self):
        for outer, inner in ((False, False), (True, False), (True, True)):
            payload = run_payload()
            payload["result"]["input_fingerprint"] = "0" * 64 if not inner else fingerprint(payload["result"]["part"])
            data = {"payload": payload, "sha256": fingerprint(payload) if outer else "0" * 64}
            if outer and inner:
                data["payload"]["result"]["part"]["notes"] += "tampered"
            self.write(data=data)
            with self.subTest(outer=outer, inner=inner), self.assertRaisesRegex(MigrationError, "指纹"):
                read_legacy_jobs(self.sources)
        payload = run_payload()
        payload["result"]["part"]["notes"] += "tampered"
        self.write(data={"payload": payload, "sha256": fingerprint(payload)})
        with self.assertRaisesRegex(MigrationError, "指纹"):
            read_legacy_jobs(self.sources)

    def test_geometric_failure_in_later_record_publishes_nothing(self):
        self.write("a-valid.json")
        self.write("z-crossing.json", legacy_part(keys=[middle_key("25", "35")]))
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 2)
        self.assertIn("几何", info["error"]["message"])
        self.assertFalse(self.output.exists())

    def test_existing_output_is_preserved_even_if_empty(self):
        self.write()
        self.output.mkdir()
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 2)
        self.assertEqual(list(self.output.iterdir()), [])
        sentinel = self.output / "part-draft.json"
        sentinel.write_bytes(b"existing user draft")
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 2)
        self.assertEqual(sentinel.read_bytes(), b"existing user draft")
        self.assertEqual(list(self.output.iterdir()), [sentinel])

    def test_io_failure_rolls_back_whole_batch_and_staging(self):
        self.write()
        original = migration.os.link
        calls = []
        def failing_link(source, target):
            calls.append(target)
            if len(calls) == 2:
                raise OSError("synthetic publication failure")
            original(source, target)
        with patch.object(migration.os, "link", side_effect=failing_link), self.assertRaises(MigrationError):
            cmd_draft([str(self.sources), str(self.output)])
        self.assertFalse(self.output.exists())
        self.assertEqual(set(self.root.iterdir()), {self.sources})

    def test_truncated_oversize_and_wrong_typed_source_never_publish(self):
        invalid = legacy_part()
        invalid["measurement"] = "true"
        self.write(data=invalid)
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 2)
        self.assertIn("measurement", info["error"]["path"])
        self.assertFalse(self.output.exists())
        self.write(raw=" " * (migration.MAX_SOURCE_BYTES + 1))
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 2)
        self.assertIn("2MB", info["error"]["message"])
        self.assertFalse(self.output.exists())
        self.write().write_bytes(b"\xff\xfe")
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 2)
        self.assertFalse(self.output.exists())

    def test_existing_source_bytes_are_never_changed(self):
        path = self.write()
        before = path.read_bytes()
        process, _ = self.run_cli()
        self.assertEqual(process.returncode, 0)
        self.assertEqual(path.read_bytes(), before)

    def test_empty_directory_and_wrong_arguments_are_errors(self):
        process, info = self.run_cli()
        self.assertEqual(process.returncode, 2)
        self.assertFalse(self.output.exists())
        for args in ([], ["unknown"], ["draft"], ["draft", "a", "b", "c"]):
            with self.subTest(args=args):
                with patch("sys.stdout"):
                    self.assertEqual(migration.main(args), 2)

    def test_new_tool_cli_reads_draft_json_and_blocks_without_nc(self):
        self.write()
        process, _ = self.run_cli()
        self.assertEqual(process.returncode, 0)
        nc_output = self.root / "nc-output"
        # -I avoids imports from fixture directories; only the trusted repo is inserted.
        script = "import sys;sys.path.insert(0,sys.argv.pop(1));from shaft_programmer.__main__ import main;main()"
        result = subprocess.run([sys.executable, "-I", "-X", "utf8", "-c", script, str(REPO), "generate", "--input",
                                 str(self.output / "part-draft.json"), "--out-dir", str(nc_output)],
                                capture_output=True, text=True, encoding="utf-8", timeout=30)
        self.assertEqual(result.returncode, 2, result.stderr)
        diagnostics = json.loads(result.stdout)
        self.assertEqual(diagnostics[0]["path"], "/machine/origin_z")
        self.assertFalse(nc_output.exists())

    def test_draft_is_saved_and_reloaded_through_real_http_entry(self):
        from shaft_programmer.app.server import Application, handler_factory
        draft = to_draft(record())
        app = Application(self.root / "synthetic-home")
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler_factory(app))
        server.daemon_threads = True
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        def request(path, body=None):
            connection = http.client.HTTPConnection("127.0.0.1", server.server_port, timeout=10)
            try:
                connection.request("POST" if body is not None else "GET", path,
                                   body=encoded(body) if body is not None else None,
                                   headers={"Content-Type": "application/json", "X-Shaft-Token": app.token, "Connection": "close"})
                response = connection.getresponse()
                return response.status, json.loads(response.read())
            finally:
                connection.close()
        try:
            status, saved = request("/api/save", draft)
            self.assertEqual(status, 200)
            self.assertFalse(saved["validation"]["ok"])
            status, loaded = request("/api/jobs/" + saved["id"])
            self.assertEqual(status, 200)
            self.assertEqual(loaded["body"], draft)
            self.assertEqual(request("/api/generate", draft)[0], 422)
            self.assertEqual(request("/api/save-recipe", draft)[0], 422)
            self.assertEqual(app.store.runs(), [])
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)


if __name__ == "__main__":
    unittest.main()
