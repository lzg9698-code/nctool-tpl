"""Sample and failure evidence for the standalone prototype."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('dual_turret', ROOT / 'prototypes/dual_turret/trajectory.py')
proto = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(proto)

NC_SAMPLES = ROOT / 'nc'
# nc/ 为仓库外的本地样本资料（真实程序与图纸），不随本仓库分发；
# 缺少样本时跳过样本核对，其余原型逻辑仍可在干净检出上验证。
requires_samples = unittest.skipUnless(
    NC_SAMPLES.is_dir(), '本地 nc/ 样例未提供，跳过样本核对')


class DualTurretTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((ROOT / 'prototypes/dual_turret/example-14594226.json').read_text(encoding='utf-8'))
        self.ops = proto.expand_recipe(self.data['recipe'])

    def test_manual_diameter_ladder_and_incremental_retract(self):
        self.assertEqual([p['x'] for p in self.ops[0]['passes']],
                         ['140.020', '129.390', '118.760', '108.130'])
        self.assertEqual([p['x'] for p in self.ops[1]['passes']],
                         ['134.390', '123.760', '113.130', '102.500'])
        events = proto.plan(self.ops[0])
        retract = [e for e in events if e.get('phase') == 'radial_retract'][0]
        self.assertEqual(retract['end'], {'X': '154.650', 'Z': '317.250'})
        diagonal = [e for e in events if e.get('phase') == 'diagonal_retract'][0]
        self.assertEqual(diagonal['end'], {'X': '156.650', 'Z': '318.250'})
        # DIAMON G91 X14.630 means a physical radial increment of 7.315.
        self.assertEqual((proto.dec(retract['end']['X']) - proto.dec(retract['start']['X'])) / 2,
                         proto.D('7.315'))

    @requires_samples
    def test_manual_recipe_matches_both_source_channels(self):
        for channel in (1, 2):
            path = ROOT / f'nc/14594226_12_2FS.WPD/{channel}_0.MPF'
            text, _ = proto.read_source(path)
            block = next(b for b in proto.blocks(text, str(path)) if b['side'] == 'right')
            _, original = proto.extract(block)
            self.assertEqual(proto.semantic(proto.plan(self.ops[channel-1])), original)

    @requires_samples
    def test_all_11_sample_packages_and_comment_discrepancy(self):
        outputs, report = proto.scan(NC_SAMPLES)
        self.assertEqual((report['sample_count'], report['right_group_count'], report['paired_pass_count']), (11, 33, 81))
        exception = next(e for e in report['evidence'] if e['sample'].startswith('14595362') and e['group'] == 3)
        self.assertEqual(exception['end_z_offsets'], ['0.000'])
        # Source comment says D303.0, but both actual G1 end at Z300.000.
        fragment = outputs['14595362_12_2FS.WPD/right-03/CH2.MPF.preview.txt']
        self.assertIn('G1 Z300.000', fragment)
        self.assertEqual(len(report['unsupported_left_blocks']), 20)
        self.assertTrue(any(any(e['excluded_oem']) for e in report['evidence']))
        for filename, content in outputs.items():
            if filename.endswith('.svg'):
                ET.fromstring(content)

    def test_dimension_change_propagates_to_code_and_plan(self):
        recipe = self.data['recipe']
        recipe['ch2_final_x'] = '104.500'
        ops = proto.expand_recipe(recipe)
        outputs, plans = proto.package(ops, 'modified')
        self.assertEqual(ops[1]['passes'][-1]['x'], '104.500')
        self.assertIn('X104.500', outputs['CH2.MPF.preview.txt'])
        self.assertEqual([e for e in plans[1] if e.get('phase') == 'axial_cut'][-1]['end']['X'], '104.500')

    def test_mismatched_or_reordered_waits_rejected(self):
        for alteration in ('missing', 'reordered', 'duplicate', 'range'):
            ops = copy.deepcopy(self.ops)
            if alteration == 'missing':
                ops[1]['passes'].pop()
            elif alteration == 'reordered':
                ops[1]['passes'][0]['wait'], ops[1]['passes'][1]['wait'] = 14, 13
            elif alteration == 'duplicate':
                ops[0]['passes'][0]['wait'] = 12
            else:
                ops[0]['prepare_wait'] = 256
            with self.subTest(alteration=alteration), self.assertRaises(ValueError):
                proto.package(ops, 'invalid')

    def test_invalid_numbers_and_precision(self):
        for value in ('NaN', 'Infinity', '1e999', True, None, '1.0001'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                proto.dec(value)

    def test_invalid_geometry_or_feed_rejected(self):
        for field, value in (('x', '0'), ('x', '155.020'), ('end_z', '600'), ('cut_feed', '0'), ('retract_x', '-1')):
            ops = copy.deepcopy(self.ops)
            ops[0]['passes'][0][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                proto.package(ops, 'invalid')
        self.ops[1]['passes'][0]['cut_feed'] = '.400'
        with self.assertRaises(ValueError):
            proto.package(self.ops, 'different feed')

    def test_unknown_instruction_or_incremental_start_fails_closed(self):
        for line in ('G1 Z10 ANG=225 F.2', 'G2 X10 Z20', 'G0 X=I_R9[50]', 'M1=68', 'WAITM(12,1,3)'):
            with self.subTest(line=line), self.assertRaises(ValueError):
                proto.commands({'lines': [line], 'start_line': 0, 'source': 'bad'})
        cmds, _ = proto.commands({'lines': ['G91', 'G1 X2 F.3'], 'start_line': 0, 'source': 'bad'})
        with self.assertRaises(ValueError):
            proto.interpret(cmds)

    def test_output_tampering_detectable(self):
        events = proto.plan(self.ops[0])
        code, _ = proto.render(events, 1)
        changed = code.replace('X140.020', 'X141.020', 1)
        cmds, _ = proto.commands({'lines': changed.splitlines()[3:], 'start_line': 3, 'source': 'changed'})
        self.assertNotEqual(proto.interpret(cmds), proto.semantic(events))

    def test_atomic_pair_and_no_overwrite(self):
        temporary_root = ROOT / 'target' / 'dual-turret-tests'
        temporary_root.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=temporary_root) as directory:
            out = Path(directory) / 'result'
            outputs, _ = proto.package(self.ops, 'valid')
            proto.publish(out, outputs)
            self.assertTrue((out / 'CH1.MPF.preview.txt').exists())
            self.assertTrue((out / 'CH2.MPF.preview.txt').exists())
            with self.assertRaises(ValueError):
                proto.publish(out, {'CH1.MPF.preview.txt': 'changed'})
            self.assertEqual((out / 'CH1.MPF.preview.txt').read_text(), outputs['CH1.MPF.preview.txt'])


if __name__ == '__main__':
    unittest.main()
