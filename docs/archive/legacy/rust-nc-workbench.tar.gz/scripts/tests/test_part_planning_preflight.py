import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('part_preflight', ROOT/'prototypes/part_planning/preflight.py')
proto = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(proto)
DRAFT = ROOT/'prototypes/part_planning/14594226.draft.json'


class PartPlanningTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads(DRAFT.read_text(encoding='utf-8'))

    def report(self):
        return proto.check(self.data, ROOT)

    def test_real_draft_partial_valid_and_always_blocked(self):
        r = self.report()
        self.assertTrue(r['structurally_valid'])
        self.assertFalse(r['nc_generation_supported'])
        self.assertEqual(r['readiness'], 'blocked')
        self.assertEqual(len(r['checks']), 10)
        self.assertEqual(len(r['errors']), 0)
        self.assertIn('p0_only', [x['code'] for x in r['blockers']])

    def test_user_grinding_decision_keeps_allowance_pending(self):
        decisions = {d['id']:d for d in self.data['required_decisions']}
        self.assertEqual(decisions['subsequent-process']['value'], 'grinding')
        self.assertEqual(decisions['subsequent-process']['status'], 'confirmed')
        self.assertEqual(decisions['grinding-allowance']['status'], 'pending')
        self.assertEqual(self.data['process_candidates'][2]['status'], 'reference_only')

    def test_positive_fit_limits_need_not_contain_nominal(self):
        d = next(x for x in self.data['dimensions'] if x['id']=='left_diameter')
        self.assertGreater(proto.number(d['lower']), proto.number(d['nominal']))
        self.assertFalse(self.report()['errors'])

    def test_decimal_rejection(self):
        for value in (100, True, None, 'NaN', 'Infinity', '1e3', '1.0000001', '1000001'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                proto.number(value)

    def test_invalid_bounds(self):
        d = self.data['dimensions'][0]
        for low,high in (('528','526'),('0','528'),('526',None)):
            with self.subTest(low=low,high=high):
                d['lower'],d['upper']=low,high
                self.assertIn('invalid_dimension_value', [e['code'] for e in self.report()['errors']])

    def test_dimension_relation_contradiction(self):
        self.data['dimensions'][0]['nominal']='528'
        self.assertIn('invalid_relation', [e['code'] for e in self.report()['errors']])

    def test_unknown_duplicate_and_unsafe_relation(self):
        for change in ('unknown','duplicate','coefficient'):
            with self.subTest(change=change):
                data=copy.deepcopy(self.data)
                if change=='unknown':data['relations'][0]['terms'][0]['dimension_id']='missing'
                elif change=='duplicate':data['relations'].append(copy.deepcopy(data['relations'][0]))
                else:data['relations'][0]['terms'][0]['coefficient']=True
                self.assertIn('invalid_relation',[x['code'] for x in proto.check(data,ROOT)['errors']])

    def test_wrong_source_layer_and_spoofed_file_type(self):
        self.data['dimensions'][0]['evidence'][0]['source_id']='turning'
        self.assertIn('wrong_evidence_layer',[x['code'] for x in self.report()['errors']])
        self.data['sources'][2]['kind']='drawing'
        self.assertIn('source_kind_mismatch',[x['code'] for x in self.report()['errors']])

    def test_source_hash_and_snippet_changes(self):
        self.data['sources'][0]['sha256']='0'*64
        self.data['sources'][1]['snippets'][0]['text']='changed'
        codes=[x['code'] for x in self.report()['errors']]
        self.assertIn('source_changed',codes)
        self.assertIn('snippet_mismatch',codes)

    def test_source_path_boundary(self):
        self.data['sources'][0]['file']='../outside.tif'
        self.assertIn('source_outside_nc',[x['code'] for x in self.report()['errors']])

    def test_keyway_geometry_and_position(self):
        for change in ('radius','endshape','position'):
            with self.subTest(change=change):
                data=copy.deepcopy(self.data)
                if change=='radius':next(d for d in data['dimensions'] if d['id']=='a_end_radius')['nominal']='15'
                elif change=='endshape':data['features'][0]['end_shape']='semicircle'
                else:next(d for d in data['dimensions'] if d['id']=='a_start_offset')['nominal']='20'
                self.assertIn('invalid_keyway',[x['code'] for x in proto.check(data,ROOT)['errors']])

    def test_false_confirmation_rejected(self):
        self.data['dimensions'][0]['status']='confirmed'
        self.assertIn('missing_approval',[x['code'] for x in self.report()['errors']])
        self.data['process_candidates'][2]['status']='confirmed'
        self.assertIn('candidate_status',[x['code'] for x in self.report()['errors']])

    def test_claimed_coverage_cannot_enable_generation(self):
        self.data['coverage']={k:True for k in self.data['coverage']}
        r=self.report()
        self.assertEqual(r['readiness'],'blocked')
        self.assertFalse(r['nc_generation_supported'])

    def test_malformed_contract(self):
        for data in ([],{},dict(self.data, units='inch'),dict(self.data, dimensions=None)):
            with self.subTest(data_type=type(data)):
                self.assertFalse(proto.check(data,ROOT)['structurally_valid'])

    def test_cli_default_structural_exit_and_explicit_readiness_gate(self):
        import sys
        temp=ROOT/'target/part-planning/tests';temp.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=temp) as directory:
            out=Path(directory)/'structural'
            command=[sys.executable,str(ROOT/'prototypes/part_planning/preflight.py'),'--input',str(DRAFT),'--out',str(out)]
            result=subprocess.run(command,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)
            r=json.loads((out/'report.json').read_text(encoding='utf-8'))
            self.assertEqual(r['readiness'],'blocked')
            self.assertEqual(subprocess.run(command,capture_output=True).returncode,1)
            command[-1]=str(Path(directory)/'readiness')
            self.assertEqual(subprocess.run(command+['--require-ready'],capture_output=True).returncode,2)


if __name__=='__main__':
    unittest.main()
