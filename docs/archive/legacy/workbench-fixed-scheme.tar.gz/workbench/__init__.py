"""NCtool Shaft Workbench: state-driven local programming."""
