"""INDEX sample composition: frozen machine blocks + typed operation recipes."""
from __future__ import annotations
from decimal import Decimal as D, ROUND_CEILING
from pathlib import Path
import hashlib
import json
import math
import re
from .domain import PlanError, validate, make_states, text, fingerprint

RESOURCE=Path(__file__).resolve().parent/'resources'
NUM=r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)'
def current_engine_fingerprint():
    return hashlib.sha256(Path(__file__).read_bytes()+Path(__file__).with_name('domain.py').read_bytes()).hexdigest()
ENGINE_FINGERPRINT=current_engine_fingerprint()


def frozen():
    manifest=json.loads((RESOURCE/'manifest.json').read_text(encoding='utf-8'))
    files={}
    for name,sha in manifest['programs'].items():
        raw=(RESOURCE/'programs'/name).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=sha: raise PlanError('/machine_profile','冻结机床样例指纹已变化，请重新核定')
        files[name]=raw.decode('utf-8-sig')
    return files,manifest


def nearest_z(value,v):
    """Preserve the seed's offset to its explicitly declared drawing landmark."""
    old=[D(0),D(33),D(219),D(266),D(295),D(317),D(527)]
    l=v['lengths'];L=v['total'];o=v['origins']
    new=[D(0),l['tail'],L-o['right'],L-o['middle'],L-o['bearing'],L-l['left'],L]
    i=min(range(len(old)),key=lambda i:abs(D(value)-old[i]))
    return new[i]+D(value)-old[i]


def group_bounds(lines,name):
    start=next(i for i,l in enumerate(lines) if 'GROUP_BEGIN' in l and '"'+name+'"' in l)
    end=next(i for i in range(start+1,len(lines)) if lines[i].startswith('GROUP_END'))
    return start,end


def tagged(line,stage,id):
    return line+' ; @wb:'+stage+':'+id


def rough_body(v,channel):
    cut=v['cutting'];L=v['total'];o=v['origins'];targets=v['targets'];stock=v['stock'];feed=cut['feed']
    settings=[('left',L+4,L-v['lengths']['left']+D('.25')),
              ('middle',L-v['lengths']['left']+4,L-o['right']+D('.2')),
              ('right',L-o['right']+4,v['lengths']['tail']+7)]
    lines=[];number=12;passes=[]
    for role,safe_z,end_z in settings:
        end_x=targets[role]+cut['rough_remaining'];start_x=stock-cut['black_drop']
        count=int(((start_x-end_x)/(cut['ap1']+cut['ap2'])).to_integral_value(rounding=ROUND_CEILING))
        if not 1<=count<=100: raise PlanError('/cutting','粗车刀次无效')
        actual=end_x+count*(cut['ap1']+cut['ap2'])
        safe_x=max(stock+5,actual+10)
        lines += ['; '+role+' paired roughing',tagged('G0 Z'+text(safe_z),'rough',role),tagged('G0 X'+text(safe_x),'rough',role),f'WAITM({number},1,2)']
        for index in range(count):
            x=actual-cut['ap1']-index*(cut['ap1']+cut['ap2']) if channel==1 else actual-(index+1)*(cut['ap1']+cut['ap2'])
            z=safe_z-2 if channel==1 else safe_z
            lines += [tagged('G0 Z'+text(z),'rough',role),tagged('G1 X'+text(x)+' F400','rough',role),
                      f'WAITM({number+index+1},1,2)',tagged('G1 Z'+text(end_z)+' F'+text(feed,2),'rough',role),
                      'G91',tagged('G1 X'+text(cut['ap1']+cut['ap2']+4)+' F0.3','rough',role),
                      tagged('G1 X2 Z1','rough',role),'G90']
            passes.append({'region':role,'channel':channel,'pass':index+1,'diameter':text(x),
                           'start_z':text(z),'end_z':text(end_z),'wait':number+index+1})
        lines += [tagged('G0 X'+text(safe_x),'rough',role),tagged('G0 Z'+text(end_z+4),'rough',role)]
        number+=count+1
    if number>=52: raise PlanError('/cutting','刀次超过本机方案12～51的等待号容量，请调整切深')
    return lines,passes


def transform_group(lines,name,v,stage,channel,tools,next_tool=None):
    start,end=group_bounds(lines,name);part=lines[start:end+1]
    # Tool ownership follows operation roles, not the physical display above/below.
    l171=[i for i,l in enumerate(part) if re.match(r'^L171\("',l)]
    if l171:
        part[l171[0]]='L171("'+tools+'")'
        if len(l171)>1 and next_tool is not None:part[l171[-1]]='L171("'+next_tool+'")'
    else:
        for i,l in enumerate(part):
            if re.fullmatch(r'T[\w.]+(?: D\d+)?',l):part[i]=tools+(' D1' if ' D1' in l else '')
    p=v['targets'];n=v['dims'];stock=v['stock'];fs=v['cutting']['fs_face_allowance']
    if stage=='finish' and channel==1:
        x_map={'94':p['cap']-D('6.4'),'100.4':p['cap'],'118.848':p['middle']-D('1.552'),
               '120.4':p['middle'],'133':p['right']-D('2.5'),'133.9':p['right']-D('1.6'),'135.5':p['right']}
    elif stage=='finish':
        x_map={'96.536':p['tail']-D('3.864'),'100.4':p['tail'],'119':n['middle']['nominal']-1,
               '120':n['middle']['nominal'],'132.691':p['right']-D('2.809'),'135.5':p['right']}
    else:
        # Frozen ES/FS strategy is expressed around finished nominal diameters, with zero local allowance.
        if channel==1:
            x_map={'104.000':n['tail']['nominal']+4,'99.200':n['tail']['nominal']-D('.8')}
        else:
            x_map={'104.000':n['left']['nominal']+4,'99.200':n['left']['nominal']-D('.8'),
                   '118.3':n['middle']['nominal']-D('1.7'),'120.000':n['middle']['nominal'],
                   '124.000':n['middle']['nominal']+4,'119.200':n['middle']['nominal']-D('.8')}
    new=[]
    for l in part:
        is_motion=bool(re.match(r'^G[01](?:\s|$)',l))
        if is_motion:
            def xword(m):
                literal=m[1];value=D(literal)
                if literal in x_map:result=x_map[literal]
                elif value>=D(150):result=stock+(value-150)
                else:result=value
                return 'X'+text(result)
            def zword(m):
                value=D(m[1]);result=nearest_z(value,v)
                if stage=='finish' and channel==1 and value==D('219.1'):result=v['total']-v['origins']['right']+fs
                if stage=='finish' and channel==2 and value==D('32.9'):result=v['lengths']['tail']-fs
                return 'Z'+text(result)
            l=re.sub(r'\bX=?('+NUM+r')\b',xword,l)
            l=re.sub(r'\bZ=?('+NUM+r')\b',zword,l)
            l=tagged(l,stage,'ch'+str(channel))
        new.append(l)
        if stage=='finish' and channel==1 and re.match(r'^G1 X'+re.escape(text(p['cap']))+r' ANG=135',l):
            new += [tagged('G1 Z'+text(v['total']-17)+' F0.45','finish','cap'),
                    tagged('G1 X'+text(p['left'])+' F0.175','finish','left')]
        if stage=='finish' and channel==1 and re.match(r'^G1 X'+re.escape(text(p['middle']))+r' ANG=165',l):
            # Bearing land is an explicit target, not a constant allowance applied to every diameter.
            new += [tagged('G1 Z'+text(v['total']-v['origins']['bearing'])+' F0.45','finish','middle'),
                    tagged('G1 X'+text(p['bearing'])+' F0.175','finish','bearing'),
                    tagged('G1 Z'+text(v['total']-v['origins']['middle'])+' F0.45','finish','bearing'),
                    tagged('G1 X'+text(p['middle'])+' F0.175','finish','middle')]
    return lines[:start]+new+lines[end+1:]


def key_program(template,key,kind,part,next_tool):
    lines=template.splitlines();k=key;R=k['radius'];W=k['width'];L=k['length'];depth=k['depth']
    straight=L-2*R;end=L-R
    datum={'high-end':41,'average':43,'low-end':42}[k['datum']]
    key_type='a' if W<=D(28) else 'b'
    roles={'rkm':'key_rough_'+key_type,'fkm':'key_finish_'+key_type,'dj':'chamfer'}
    l171=[i for i,l in enumerate(lines) if re.match(r'^L171\("',l)]
    if l171:
        lines[l171[0]]='L171("'+part['tools'][roles[kind]]+'")'
        if len(l171)>1:lines[l171[-1]]='L171("'+next_tool+'")'
    for i,l in enumerate(lines):
        if l.startswith('XMW_1='):lines[i]=f'XMW_1=0 YMW_1=0 ZMW_1=I_R9[35]+I_R9[{datum}] CMW_1=0'
        if l.startswith('ATRANS'):lines[i]=f'ATRANS X{text(k["z_anchor"])} Z{text(k["surface_radius"])}'
    stage={'rkm':'key_rough','fkm':'key_finish','dj':'chamfer'}[kind]
    begin=next(i for i,l in enumerate(lines) if l.startswith('G94 G40 G0'))
    end_i=next(i for i in range(begin+1,len(lines)) if lines[i].startswith('ROT'))
    b=[f'G94 G40 G0 X0 Y0 C=DC(0.000)','G0 Z10']
    def add(code):b.append(tagged(code,stage,k['id']))
    if kind=='fkm':
        add('G1 Z'+text(-depth+5)+' F3000');add('G1 Z'+text(-depth)+' F100')
        add('G1 G41 Y'+text(W/2)+' F750');add('G1 X'+text(-straight))
        add('G3 X'+text(-end)+' Y'+text(W/2-R)+' J'+text(-R))
        add('G1 Y'+text(-(W/2-R)));add('G3 X'+text(-straight)+' Y'+text(-W/2)+' I'+text(R))
        add('G1 X0');add('G3 X'+text(R)+' Y'+text(-(W/2-R))+' J'+text(R))
        add('G1 Y'+text(W/2-R));add('G3 X0 Y'+text(W/2)+' I'+text(-R));add('G1 G40 Y0 Z2')
    elif kind=='rkm':
        add('G1 Z2 F400');add('G1 X'+text(-R-D('.3'))+' Z'+text(-depth+D('.1'))+' F200')
        for wall,feed in [(D('.3'),D(550)),(D('.1'),D(700))]:
            b.append('; '+('rough' if wall==D('.3') else 'semi-finish'))
            if wall==D('.1'):add('G1 Z'+text(-depth)+' F60')
            add('G1 '+('G41 ' if wall==D('.3') else '')+'X'+text(R-wall)+' F'+text(feed,0))
            add('G1 Y'+text(W/2-wall)+' F350');add('G1 X'+text(-(L-3*R))+' F'+text(feed,0))
            add('G1 X'+text(-end+wall)+' F350');add('G1 Y'+text(-W/2+wall))
            add('G1 X'+text(-R)+' F'+text(feed,0));add('G1 X'+text(R-wall)+' F350');add('G1 Y'+text(W/2-wall))
        add('G1 G40 Y0 Z2')
    else:
        # Cylinder-aware seed chamfer recipe: the tip offset is frozen with its tool role.
        r=float(k['surface_radius']);half=float(W/2);inner=float(W/2-R)
        z_side=D(str(-2.3-(r-math.sqrt(r*r-half*half))));z_inner=D(str(-2.3-(r-math.sqrt(r*r-inner*inner))))
        r_cut=R-2;y_cut=W/2-2
        add('G01 Z'+text(z_side)+' F100');add('G1 G40 Y'+text(y_cut)+' F1200');add('G1 X'+text(-straight))
        add('G03 X'+text(-straight-r_cut)+' Y'+text(W/2-R)+' J'+text(-r_cut)+' Z'+text(z_inner))
        add('G1 Y0 Z-2.300');add('G1 Y'+text(-(W/2-R))+' Z'+text(z_inner))
        add('G03 X'+text(-straight)+' Y'+text(-y_cut)+' I'+text(r_cut)+' Z'+text(z_side));add('G1 X0')
        add('G03 X'+text(r_cut)+' Y'+text(-(W/2-R))+' J'+text(r_cut)+' Z'+text(z_inner))
        add('G1 Y0 Z-2.300');add('G1 Y'+text(W/2-R)+' Z'+text(z_inner))
        add('G03 X0 Y'+text(y_cut)+' I'+text(-r_cut)+' Z'+text(z_side));add('G1 Y0')
    b.append('G0 G40 Z100')
    if kind=='dj' and not k['chamfer']:return '; Chamfer disabled for '+k['id']+'\nRET\n'
    return '\n'.join(lines[:begin]+b+lines[end_i:])+'\n'


def validate_sync(programs):
    all_events={};streams={}
    for ch in (1,2,3):
        events=[]
        for m in re.finditer(r'(?m)^WAITM\((\d+),([\d,]+)\)',programs[f'{ch}_0.MPF']):
            number=int(m[1]);participants=tuple(int(c) for c in m[2].split(','))
            if number>255 or not set(participants).issubset({1,2,3}) or ch not in participants or len(set(participants))!=len(participants):raise PlanError('/programs','同步事件的参与通道或编号无效')
            if number in all_events and all_events[number]!=participants:raise PlanError('/programs','同号等待事件的参与通道不一致')
            all_events[number]=participants;events.append(number)
        if len(set(events))!=len(events):raise PlanError('/programs','正常路径有重复等待号')
        streams[ch]=events
    for number,participants in all_events.items():
        if any(number not in streams[c] for c in participants):raise PlanError('/programs',f'等待点{number}缺少参与通道')
    edges={n:set() for n in all_events};degree={n:0 for n in all_events}
    for events in streams.values():
        for a,b in zip(events,events[1:]):
            if b not in edges[a]:edges[a].add(b);degree[b]+=1
    ready=[n for n in degree if degree[n]==0];visited=0
    while ready:
        n=ready.pop();visited+=1
        for b in edges[n]:
            degree[b]-=1
            if degree[b]==0:ready.append(b)
    if visited!=len(degree):raise PlanError('/programs','等待事件存在循环依赖')
    return [{'number':n,'participants':list(p)} for n,p in sorted(all_events.items())]


def motion_preview(programs):
    segments=[];mapping=[]
    for file,code in programs.items():
        x=z=None;relative=False;feed=None;previous_stage=None
        for line_number,line in enumerate(code.splitlines(),1):
            tag=re.search(r'; @wb:([^:]+):(.+)$',line)
            code_line=line.split(';')[0].strip()
            if code_line=='G91':relative=True
            if code_line=='G90' or re.search(r'\bG90\b',code_line):relative=False
            if not tag:continue
            sid=file+':'+str(line_number);stage,feature=tag[1],tag[2]
            if previous_stage!=stage:x=z=None
            previous_stage=stage
            mapping.append({'id':sid,'file':file,'line':line_number,'stage':stage,'feature':feature})
            if not file.endswith('_0.MPF'):continue
            if not re.match(r'^G[01](?:\s|$)',code_line):continue
            before_x,before_z=x,z
            xm=re.search(r'\bX('+NUM+')',code_line);zm=re.search(r'\bZ('+NUM+')',code_line)
            angle=re.search(r'ANG=('+NUM+')',code_line);fm=re.search(r'\bF('+NUM+')',code_line)
            if fm:feed=float(fm[1])
            if xm:x=(x+float(xm[1])) if relative and x is not None else float(xm[1])
            if zm:z=(z+float(zm[1])) if relative and z is not None else float(zm[1])
            if angle and before_x is not None and before_z is not None:
                tangent=math.tan(math.radians(float(angle[1])))
                if xm and not zm and abs(tangent)>1e-10:z=before_z+(x-before_x)/2/tangent
                if zm and not xm:x=before_x+2*(z-before_z)*tangent
            if None not in (before_x,before_z,x,z):
                if not all(math.isfinite(a) and abs(a)<10000 for a in (before_x,before_z,x,z)):
                    raise PlanError('/programs','量化后的轨迹端点无效')
                segments.append({'id':sid,'file':file,'line':line_number,'stage':stage,'feature':feature,
                                 'channel':int(file[0]),'rapid':code_line.startswith('G0'),
                                 'start':{'z':round(before_z,6),'r':round(before_x/2,6)},
                                 'end':{'z':round(z,6),'r':round(x/2,6)},'feed':feed,'rounded': 'RND=' in code_line})
    return segments,mapping


def key_motion_preview(programs,keys):
    segments=[]
    for key in keys:
        for kind,stage in [('RKM','key_rough'),('FKM','key_finish'),('DJ','chamfer')]:
            file=f'UZ_{kind}_{key["index"]}.spf';pose={'X':None,'Y':None,'Z':None}
            for line_number,line in enumerate(programs[file].splitlines(),1):
                code=line.split(';')[0].strip()
                motion=re.search(r'\b(G0?0|G0?1|G0?3)(?=\s|$)',code)
                if not motion:continue
                before=dict(pose)
                for axis in pose:
                    m=re.search(r'\b'+axis+'=?('+NUM+')',code)
                    if m:pose[axis]=float(m[1])
                if '@wb:' not in line or None in before.values() or None in pose.values():continue
                points=[]
                if motion[1] in ('G3','G03'):
                    im=re.search(r'\bI=?('+NUM+')',code);jm=re.search(r'\bJ=?('+NUM+')',code)
                    cx=before['X']+(float(im[1]) if im else 0);cy=before['Y']+(float(jm[1]) if jm else 0)
                    radius=math.hypot(before['X']-cx,before['Y']-cy);end_radius=math.hypot(pose['X']-cx,pose['Y']-cy)
                    if radius<=0 or abs(radius-end_radius)>.002:raise PlanError('/programs/'+file,'键槽圆弧量化后不闭合')
                    start_angle=math.atan2(before['Y']-cy,before['X']-cx);end_angle=math.atan2(pose['Y']-cy,pose['X']-cx)
                    sweep=(end_angle-start_angle)%(2*math.pi)
                    for i in range(13):
                        t=i/12;a=start_angle+sweep*t
                        points.append({'x':round(cx+radius*math.cos(a),6),'y':round(cy+radius*math.sin(a),6),'z':round(before['Z']+(pose['Z']-before['Z'])*t,6)})
                else:points=[{k.lower():v for k,v in before.items()},{k.lower():v for k,v in pose.items()}]
                def global_point(p):return {'z':round(float(key['z_anchor'])+p['x'],6),'r':round(float(key['surface_radius'])+p['z'],6)}
                segments.append({'id':file+':'+str(line_number),'file':file,'line':line_number,'stage':stage,'feature':key['id'],'channel':1,
                                 'rapid':motion[1] in ('G0','G00'),
                                 'start':global_point(points[0]),'end':global_point(points[-1]),
                                 'points':[global_point(p) for p in points],'local_points':points,'projection':'nominal-zero-measurement-frame'})
    return segments


def generate(part):
    if current_engine_fingerprint()!=ENGINE_FINGERPRINT:raise PlanError('/engine','生成器文件已变化，请重启工作台后重新生成')
    v=validate(part);source,manifest=frozen();programs={k:v for k,v in source.items() if k.endswith(('.MPF','.SPF','.JOB'))}
    L=v['total'];o=v['origins'];tools=part['tools'];cut=v['cutting'];passes=[]
    for channel in (1,2):
        name=f'{channel}_0.MPF';lines=programs[name].splitlines()
        begin=next(i for i,l in enumerate(lines) if l.startswith(';---SYT-Right'))
        endings=[i for i,l in enumerate(lines) if l.startswith(';---End---') and i>=begin]
        # The seed contains exactly three right-side groups, followed by machine return actions.
        if len(endings)<3:raise PlanError('/machine_profile','冻结样例的粗车组结构变化')
        finish=endings[2]
        body,rows=rough_body(v,channel);passes.extend(rows)
        lines=lines[:begin]+body+lines[finish+1:]
        if channel==1:
            # Initial tool loading after probing must agree with the roughing role.
            lines=[('L171("'+tools['rough1']+'")') if l=='L171("T9")' else l for l in lines]
        s,e=group_bounds(lines,'Sync Turning right side')
        header=lines[s:e]
        if channel==1:
            indexes=[i for i in range(s,e) if re.match(r'^L171\("',lines[i])]
            lines[indexes[0]]='L171("'+tools['rough1']+'")'
            lines[indexes[-1]]='L171("'+tools['finish1']+'")'
        else:
            i=next(i for i in range(s,e) if re.fullmatch(r'T\w+(?: D\d+)?',lines[i]));lines[i]=tools['rough2']
        lines=transform_group(lines,'Right SIDE FINISHING' if channel==1 else 'LEFT SIDE FINISHING',v,'finish',channel,tools['finish'+str(channel)],tools['relief1'] if channel==1 else None)
        if channel==1:
            lines=transform_group(lines,'LFET SIDE RELIEF GROOVE',v,'relief',1,tools['relief1'],tools['rings'])
            s,e=group_bounds(lines,'TURNING SHARP GROOVE')
            tool_lines=[i for i in range(s,e) if re.match(r'^L171\("',lines[i])]
            first_key=v['keys'][0];first_rough=tools['key_rough_a' if first_key['width']<=28 else 'key_rough_b']
            lines[tool_lines[0]]='L171("'+tools['rings']+'")'
            lines[tool_lines[-1]]='L171("'+first_rough+'")'
            for i in range(s,e):
                line=lines[i]
                if re.match(r'^R12=',line):lines[i]='R12='+text(v['dims']['right']['nominal'])
                elif re.match(r'^R13=',line):lines[i]='R13='+text(nearest_z(D(line.split('=')[1]),v))
                elif re.match(r'^G0.* Z'+NUM,line):lines[i]=re.sub(r'\bZ('+NUM+')',lambda m:'Z'+text(nearest_z(D(m[1]),v)),line)
                elif line in ('G0 X155','G0 X150'):lines[i]='G0 X'+text(v['stock']+(5 if line.endswith('155') else 0))
                if re.match(r'^(R\d+=|DB_CYCLE93|G[01]\s)',lines[i]):lines[i]=tagged(lines[i],'rings','ring-group')
            begin=next(i for i,l in enumerate(lines) if l=='UZ_RKM_1')
            end=next(i for i in range(begin,len(lines)) if lines[i]=='UZ_DJ_2')
            calls=['; Generated keyway operations']
            for prefix in ('RKM','FKM','DJ'):
                for k in v['keys']:
                    if prefix!='DJ' or k['chamfer']:calls.append(f'UZ_{prefix}_{k["index"]}')
            lines=lines[:begin]+calls+lines[end+1:]
        else:
            i=next(i for i,l in enumerate(lines) if l=='START3:');j=next(j for j in range(i,len(lines)) if lines[j]=='END3:')
            tail=v['lengths']['tail'];target=v['targets']['tail']
            profile=['START3:',tagged('G0 X'+text(target+1),'grip','tail'),tagged('G1 Z'+text(tail-D('.2'))+' RND=2.5','grip','tail'),
                     tagged('G1 X'+text(v['dims']['middle']['nominal']+2),'grip','tail'),tagged('G1 Z'+text(tail+D('9.9'))+' RND=2','grip','tail'),
                     tagged('G1 X'+text(v['targets']['right']+D('3.5')),'grip','right'),
                     tagged('G1 G40 X'+text(v['stock']+1)+' ANG=30','grip','right'),'END3:']
            lines=lines[:i]+profile+lines[j+1:]
            for i,line in enumerate(lines):
                if line.startswith('G1 X=I_R9[50]-'):lines[i]='G1 X=I_R9[50]-'+text(cut['black_drop'])+' F400'
                if line=='G1 Z=43 F0.5':lines[i]=tagged('G1 Z'+text(tail+10)+' F'+text(cut['feed'],2),'skin','body')
        programs[name]='\n'.join(lines)+'\n'
    programs['3_0.MPF']='\n'.join(transform_group(programs['3_0.MPF'].splitlines(),'RIGHT SIDE RELIEF GROOVE',v,'relief',3,tools['relief3']))+'\n'
    # Runtime measurement results are reset even when the operator selects measurement off.
    dg=programs['DG_CAL_IR9.SPF']
    for index,value in [(50,v['stock']),(51,L),(33,D(part['stock']['center_depth'])),(40,D(part['stock']['spindle_limit']))]:
        dg=re.sub(r'(?m)^I_R9\['+str(index)+r'\]=[^;\n]*',f'I_R9[{index}]={text(value)} ',dg)
    dg='I_R9[41]=0\nI_R9[42]=0\nI_R9[43]=0\n'+dg
    programs['DG_CAL_IR9.SPF']=dg
    for name in ('1_0.MPF','2_0.MPF','3_0.MPF'):
        programs[name]=re.sub(r'(?m)^GOTOF "STEP_"<<I_STEP.*$', 'GOTOF STEP_0 ; Normal path only',programs[name])
    programs['1_0.MPF']=programs['1_0.MPF'].replace('/6PROBE','PROBE' if part['measurement'] else '; PROBE disabled; deviations reset in DG_CAL_IR9')
    for name in list(programs):
        if re.match(r'UZ_(RKM|FKM|DJ)_\d+\.spf',name,re.I):del programs[name]
    operations=[(kind,k) for kind in ('rkm','fkm','dj') for k in v['keys'] if kind!='dj' or k['chamfer']]
    def active_key_tool(kind,k):
        size='a' if k['width']<=28 else 'b'
        return tools['chamfer'] if kind=='dj' else tools[('key_rough_' if kind=='rkm' else 'key_finish_')+size]
    for index,(kind,k) in enumerate(operations):
        variant=1 if k['width']<=28 else 2
        next_tool=active_key_tool(*operations[index+1]) if index+1<len(operations) else 'DECKEL'
        template=source[f'UZ_{kind.upper()}_{variant}.spf']
        programs[f'UZ_{kind.upper()}_{k["index"]}.spf']=key_program(template,k,kind,part,next_tool)
    for k in v['keys']:
        if not k['chamfer']:programs[f'UZ_DJ_{k["index"]}.spf']='; Chamfer disabled\nRET\n'
    prefix=f'; NCtool Shaft Workbench 0.1 | {part["code"]} | SIMULATION CANDIDATE\n'
    programs={k:prefix+code for k,code in programs.items()}
    # All declared local dependencies must be present before any package is deliverable.
    for name,code in programs.items():
        for call in re.findall(r'(?m)^UZ_(?:RKM|FKM|DJ)_\d+',code):
            if call+'.spf' not in programs:raise PlanError('/programs','缺少键槽子程序 '+call)
        if re.search(r'\b(?:NaN|Infinity|inf)\b', '\n'.join(l.split(';')[0] for l in code.splitlines()),re.I):
            raise PlanError('/programs','输出包含非有限数')
    validate_program_structure(programs)
    sync=validate_sync(programs);trajectory,mapping=motion_preview(programs)
    trajectory.extend(key_motion_preview(programs,v['keys']))
    validate_emission(programs,v)
    targets=[{'id':role,'title':v['dims'][role]['fit']+' '+role,'nominal':str(v['dims'][role]['nominal']),
              'lower':str(v['dims'][role]['lower']),'upper':str(v['dims'][role]['upper']),'target':text(value),
              'historical':{'left':'100.400','cap':'100.400','middle':'120.400','bearing':'120.400','right':'135.500','tail':'100.400'}[role]}
             for role,value in v['targets'].items()]
    rings=[]
    ring_lines=programs['1_0.MPF'].splitlines();ring_parameters={}
    for line in ring_lines:
        match=re.match(r'^R(12|13|14|15)=('+NUM+')',line)
        if match:ring_parameters['R'+match[1]]=match[2]
        if line.startswith('DB_CYCLE93('):
            position=D(ring_parameters['R13'])
            if not v['lengths']['tail']+1<position<v['total']-v['origins']['right']-1:
                raise PlanError('/lengths/right','环槽定位参数超出大径轴段；此方案需保留原四槽布局的加工范围')
            rings.append({'id':'ring-'+str(len(rings)+1),'reference_z':text(position),
                          'reference_s':text(v['total']-position),'width_parameter':ring_parameters['R14'],
                          'representation':'cycle-reference-not-exact-contour'})
    warnings=[{'code':'machine-review','title':'机床与刀具需核对','message':'机床动作来自14594226冻结样例；更换机床、刀具或装夹后需重新仿真。'},
              {'code':'nominal-preview','title':'当前为名义几何视图','message':'圆角按控制器RND输出；刀补、机床包络和测量偏差尚未做实体仿真。'},
              {'code':'external-cycles','title':'外部循环依赖','message':'L100/L120/L171/L172/L184/L140/L974、DB_CYCLE93及INDEX专用指令需由机床或仿真环境提供。'}]
    warnings.extend([{'code':'parameterized-assumption','title':'变尺寸的适用性待工艺核定','message':'轴向位置沿已声明图纸分界点保留样例偏移；转接圆角、间隙和夹持适配未由变尺寸实机样例验证。'},
                     {'code':'tool-geometry-assumption','title':'键槽刀具几何待核对','message':'宽度≤28/＞28选A/B刀具角色；增至三槽仅验证调用和几何关系，不代表新刀具及工艺已验收。'}])
    if not part['measurement']:warnings.append({'code':'measurement-off','title':'已关闭端面测量','message':'三通道采用名义零偏；输出已清零41/42/43，不继承上次测量。'})
    return {'format':'nctool-shaft-result/1','input_fingerprint':fingerprint(part),'part':part,'total_length':text(L),
            'targets':targets,'keys':[{'id':k['id'],'title':k['title'],'s':text(k['s']),'length':text(k['length']),'width':text(k['width']),'radius':text(k['radius']),
                                     'bottom_radius':str(k['bottom_radius']),'depth_before':str(k['depth_before']),
                                     'depth_after_min':str(k['depth_after_min']),'depth_after_max':str(k['depth_after_max'])} for k in v['keys']],
            'stages':make_states(v),'rings':rings,'passes':passes,'trajectory':trajectory,'source_map':mapping,'sync_events':sync,
            'programs':programs,'checks':[{'id':'input','title':'尺寸与工艺输入','passed':True},
                                        {'id':'keys','title':'磨后槽深与槽范围','passed':True},
                                        {'id':'sync','title':'三通道等待点配对与顺序','passed':True},
                                        {'id':'package','title':'本地文件、标签与帧复位','passed':True}],
            'warnings':warnings,'export_status':'candidate_for_simulation','machine_acceptance':'not_performed',
            'source_manifest':manifest,'engine_fingerprint':ENGINE_FINGERPRINT}


def validate_emission(programs,v):
    """Check emitted targets independently of interpolation/visualization."""
    required={'1_0.MPF':['left','cap','middle','bearing'],'2_0.MPF':['right','tail']}
    for file,roles in required.items():
        moves=[l for l in programs[file].splitlines() if l.startswith('G1 ') and '; @wb:finish:' in l]
        for role in roles:
            word='X'+text(v['targets'][role])
            if not any(re.search(r'\b'+re.escape(word)+r'\b',l) for l in moves):
                raise PlanError('/programs/'+file,'输出精车目标未匹配 '+role)
    for k in v['keys']:
        file=f'UZ_FKM_{k["index"]}.spf';code=programs[file]
        if f'ATRANS X{text(k["z_anchor"])} Z{text(k["surface_radius"])}' not in code:
            raise PlanError('/programs/'+file,'键槽基准未匹配计划')
        if 'G1 Z'+text(-k['depth'])+' F100' not in code:
            raise PlanError('/programs/'+file,'键槽底未匹配成品位置')


def validate_program_structure(programs):
    """Validate the controlled file/label/frame subset, without interpreting OEM cycles."""
    job=programs.get('KANAL1_2_3.JOB','')
    selections=re.findall(r'(?m)^SELECT (\S+) CH=(\d+)\s*$',job)
    if selections!=[(f'{c}_0.MPF',str(c)) for c in (1,2,3)]:
        raise PlanError('/programs/JOB','JOB通道选择与本机方案不一致')
    for name,code in programs.items():
        clean='\n'.join(l.split(';')[0].strip() for l in code.splitlines())
        if re.search(r'{{|{%|\b(?:NaN|Infinity)\b',clean):
            raise PlanError('/programs/'+name,'有未展开变量或非法数值')
        labels=re.findall(r'(?m)^([A-Za-z_]\w*):',clean)
        if len(labels)!=len(set(labels)):raise PlanError('/programs/'+name,'程序标签重复')
        for label in re.findall(r'\bGOTO[FB]?\s+([A-Za-z_]\w*)',clean):
            if label not in labels:raise PlanError('/programs/'+name,'程序跳转标签不存在 '+label)
        for call in re.findall(r'(?m)^(DG_CAL_IR9|PROBE|UZ_(?:RKM|FKM|DJ)_\d+)\s*$',clean):
            file=call+'.spf' if call.startswith('UZ_') else call+'.SPF'
            if file not in programs:raise PlanError('/programs/'+name,'本地调用缺少文件 '+file)
        if re.fullmatch(r'[123]_0.MPF',name):
            if 'GOTOF STEP_0' not in clean or 'M30' not in clean:
                raise PlanError('/programs/'+name,'正常入口或主程序结束缺失')
            if re.search(r'GOTOF\s+"STEP_"',clean):raise PlanError('/programs/'+name,'本版不支持动态跳步恢复')
        if re.fullmatch(r'UZ_(RKM|FKM|DJ)_\d+\.spf',name) and clean.strip()!='RET':
            motion=clean.find('G94 G40 G0')
            pre=clean[:motion];post=clean[motion:]
            if motion<0 or not all(re.search(r'(?m)^'+s+r'$',pre) for s in ('DIAMOF','G17','G90')):
                raise PlanError('/programs/'+name,'键槽入口坐标量纲或平面模式缺失')
            if not re.search(r'(?s)G40.*\nROT\nTRANS\nDIAMON\n.*\nRET\s*$',post):
                raise PlanError('/programs/'+name,'键槽刀补或局部坐标帧未复位')
