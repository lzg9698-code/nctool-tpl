"""Command-line access to the independent shaft workbench."""
from pathlib import Path
import argparse,json,os,shutil,tempfile
from .domain import PlanError,seed_part
from .post import generate
from .server import encode,candidate_manifest


def write_candidate(part,out):
    """Publish a complete new directory; preserve any existing output."""
    result=generate(part);out=Path(out).resolve()
    if out.exists():raise PlanError('/out-dir','输出目录已存在，请选择新目录；不会覆盖旧结果')
    out.parent.mkdir(parents=True,exist_ok=True)
    pending=Path(tempfile.mkdtemp(prefix=out.name+'.pending-',dir=out.parent)).resolve()
    try:
        for name,code in result['programs'].items():
            (pending/name).write_bytes(code.encode('utf-8'))
        plan={k:v for k,v in result.items() if k not in ('programs','part')}
        for name,data in [('input.json',part),('plan.json',plan),('manifest.json',candidate_manifest(result))]:
            (pending/name).write_bytes(encode(data))
        (pending/'READ_ME.txt').write_text('仿真候选程序。对应机床、刀具、OEM循环、外部仿真和现场验收尚需核定。\n',encoding='utf-8')
        if out.exists():raise PlanError('/out-dir','输出目录已由其他操作创建，停止交付')
        os.rename(pending,out)
    finally:
        if pending.exists():
            if pending.parent!=out.parent or not pending.name.startswith(out.name+'.pending-'):
                raise RuntimeError('Refusing cleanup outside owned staging directory')
            shutil.rmtree(pending)
    return result


def main():
    parser=argparse.ArgumentParser(description='NCtool轴类工作台：完整候选目录生成')
    commands=parser.add_subparsers(dest='command',required=True)
    sample=commands.add_parser('sample',help='保存可编辑的14594226样例输入');sample.add_argument('--output',type=Path,required=True)
    make=commands.add_parser('generate',help='从输入生成完整候选程序目录');make.add_argument('--input',type=Path);make.add_argument('--out-dir',type=Path,required=True)
    args=parser.parse_args()
    try:
        if args.command=='sample':
            with args.output.open('x',encoding='utf-8') as f:json.dump(seed_part(),f,ensure_ascii=False,indent=2)
            print(args.output.resolve());return
        part=json.loads(args.input.read_text(encoding='utf-8-sig')) if args.input else seed_part()
        result=write_candidate(part,args.out_dir)
        print(json.dumps({'output':str(args.out_dir.resolve()),'program_count':len(result['programs']),
                          'purpose':'simulation-candidate','input_fingerprint':result['input_fingerprint'],
                          'engine_fingerprint':result['engine_fingerprint'],'machine_acceptance':'not_performed'},ensure_ascii=False))
    except (OSError,ValueError,TypeError,KeyError) as exc:
        parser.exit(1,'生成未交付：'+str(exc)+'\n')

if __name__=='__main__':main()

