"""Loopback-only workbench host. Atomic drafts, frozen runs, verified ZIP export."""
from __future__ import annotations
from datetime import datetime,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from threading import RLock
import argparse
import hashlib
import io
import json
import mimetypes
import os
import re
import secrets
import tempfile
import uuid
import zipfile
from .domain import PlanError,seed_part,fingerprint
from .post import generate,RESOURCE,ENGINE_FINGERPRINT,current_engine_fingerprint

MAX_BODY=2*1024*1024
LOCK=RLock()


def encode(data):return json.dumps(data,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf-8')


def atomic(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(dir=path.parent,prefix='.pending-',suffix='.json')
    try:
        with os.fdopen(fd,'wb') as f:f.write(encode(data));f.flush();os.fsync(f.fileno())
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)


def record_path(home,collection,id):
    if not re.fullmatch(r'[a-f0-9]{32}',id):raise PlanError('/id','记录ID无效')
    return home/collection/(id+'.json')


def load_record(path):
    document=json.loads(path.read_text(encoding='utf-8'))
    if set(document)!={'payload','sha256'} or fingerprint(document['payload'])!=document['sha256']:
        raise PlanError('/record','本地记录指纹不匹配，停止读取')
    return document['payload']


def save_record(path,payload):atomic(path,{'payload':payload,'sha256':fingerprint(payload)})


def now():return datetime.now(timezone.utc).isoformat()


def candidate_manifest(result):
    programs=result['programs']
    return {'format':'nctool-candidate-package/1','purpose':'simulation-candidate','part_code':result['part']['code'],
              'input_fingerprint':result['input_fingerprint'],'engine_fingerprint':result['engine_fingerprint'],
              'machine_acceptance':'not_performed','programs':{k:hashlib.sha256(v.encode('utf-8')).hexdigest() for k,v in programs.items()},
              'external_dependencies':['INDEX basic cycles','L974 measurement','DB_CYCLE93','machine tooling and workholding profile']}


def zip_package(result):
    buffer=io.BytesIO();programs=result['programs'];manifest=candidate_manifest(result)
    plan={k:v for k,v in result.items() if k not in ('programs','part')}
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
        for name,code in programs.items():z.writestr(name,code.encode('utf-8'))
        z.writestr('input.json',encode(result['part']));z.writestr('plan.json',encode(plan));z.writestr('manifest.json',encode(manifest))
        z.writestr('READ_ME.txt','仿真候选程序包。机床动作来自14594226样例，需在对应机床/控制器/刀具/循环环境完成外部仿真及现场工艺核对。\n'.encode('utf-8'))
    return buffer.getvalue()


def handler_factory(home,static):
    csrf=secrets.token_urlsafe(32)
    workspace_key=hashlib.sha256((str(Path(__file__).resolve().parents[1])+'|'+str(home.resolve())).encode()).hexdigest()
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.1'
        def log_message(self,fmt,*args):pass
        def response(self,status,data,content_type='application/json; charset=utf-8',headers=None):
            raw=data if isinstance(data,bytes) else encode(data)
            self.send_response(status);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(raw)))
            self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store')
            self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
            for key,value in (headers or {}).items():self.send_header(key,value)
            self.end_headers();self.wfile.write(raw)
        def guard(self,write=False):
            own=f'127.0.0.1:{self.server.server_port}';host=self.headers.get('Host','')
            if host not in (own,f'localhost:{self.server.server_port}'):
                self.response(403,{'error':'不允许的Host'});return False
            origin=self.headers.get('Origin')
            if origin and origin not in ('http://'+own,f'http://localhost:{self.server.server_port}'):
                self.response(403,{'error':'不允许的请求来源'});return False
            if write and not secrets.compare_digest(self.headers.get('X-Workbench-Token',''),csrf):
                self.response(403,{'error':'会话已变化，请刷新页面'});return False
            return True
        def body(self):
            if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise PlanError('/request','仅支持application/json')
            try:length=int(self.headers.get('Content-Length','0'))
            except ValueError:raise PlanError('/request','请求长度无效') from None
            if not 0<length<=MAX_BODY:raise PlanError('/request','请求体不能为空或超过2 MB')
            return json.loads(self.rfile.read(length).decode('utf-8'),parse_constant=lambda s:(_ for _ in ()).throw(ValueError('非有限JSON数值')))
        def do_GET(self):
            if not self.guard():return
            try:
                path=self.path.split('?',1)[0]
                if path=='/api/bootstrap':
                    projects=[];runs=[]
                    with LOCK:
                        for p in (home/'projects').glob('*.json'):
                            try:
                                r=load_record(p);projects.append({'id':r['id'],'etag':fingerprint(r),'title':r['part']['title'],'code':r['part']['code'],'updated':r['updated']})
                            except (ValueError,KeyError,OSError):continue
                        for p in (home/'runs').glob('*.json'):
                            try:
                                r=load_record(p);runs.append({'id':r['id'],'code':r['result']['part']['code'],'created':r['created'],'input_fingerprint':r['result']['input_fingerprint']})
                            except (ValueError,KeyError,OSError):continue
                    catalog=json.loads((RESOURCE/'catalog.json').read_text(encoding='utf-8')) if (RESOURCE/'catalog.json').exists() else []
                    self.response(200,{'csrf':csrf,'sample':seed_part(),'projects':sorted(projects,key=lambda x:x['updated'],reverse=True),
                                       'runs':sorted(runs,key=lambda x:x['created'],reverse=True)[:40],'catalog':catalog,'version':'0.1.0','workspace_key':workspace_key,
                                       'engine_current':ENGINE_FINGERPRINT==current_engine_fingerprint()});return
                if path.startswith('/api/projects/'):
                    r=load_record(record_path(home,'projects',path.rsplit('/',1)[1]));self.response(200,{'record':r,'etag':fingerprint(r)});return
                if path.startswith('/api/runs/'):
                    r=load_record(record_path(home,'runs',path.rsplit('/',1)[1]));self.response(200,r);return
                if path=='/drawing.png':
                    p=RESOURCE/'drawing.png';self.response(200,p.read_bytes(),'image/png');return
                if path.startswith('/api/'):
                    self.response(404,{'error':'接口不存在'});return
                relative='workbench.html' if path in ('/','/workbench.html') else path.lstrip('/')
                p=(static/relative).resolve()
                if not p.is_relative_to(static.resolve()) or not p.is_file():self.response(404,b'Not Found','text/plain');return
                self.response(200,p.read_bytes(),mimetypes.guess_type(str(p))[0] or 'application/octet-stream')
            except FileNotFoundError:self.response(404,{'error':'记录不存在'})
            except (PlanError,ValueError,KeyError,TypeError) as exc:self.response(422,{'error':str(exc),'path':getattr(exc,'path','/')})
        def do_POST(self):
            if not self.guard(True):return
            try:
                data=self.body();path=self.path.split('?',1)[0]
                if not isinstance(data,dict):raise PlanError('/request','请求必须为对象')
                if path=='/api/stop':
                    if data.get('workspace_key')!=workspace_key:self.response(403,{'error':'工作区身份不匹配，不会停止服务'});return
                    self.response(200,{'stopping':True})
                    import threading
                    threading.Thread(target=self.server.shutdown,daemon=True).start();return
                if path in ('/api/plan','/api/generate','/api/import/check'):
                    result=generate(data['part'])
                    if path=='/api/generate':
                        id=uuid.uuid4().hex;record={'id':id,'created':now(),'result':result}
                        with LOCK:save_record(record_path(home,'runs',id),record)
                        self.response(200,record)
                    else:self.response(200,{'result':result})
                    return
                if path=='/api/save':
                    part=data['part'];generate(part)
                    with LOCK:
                        id=data.get('id') or uuid.uuid4().hex;file=record_path(home,'projects',id)
                        if file.exists():
                            current=load_record(file)
                            if data.get('etag')!=fingerprint(current):self.response(409,{'error':'零件已在其他窗口修改，请重新打开后保存'});return
                        elif data.get('etag') is not None:
                            self.response(409,{'error':'保存基线已不存在，请另存为新零件'});return
                        record={'id':id,'updated':now(),'part':part};save_record(file,record)
                    self.response(200,{'record':record,'etag':fingerprint(record)});return
                if path.startswith('/api/export/'):
                    with LOCK:record=load_record(record_path(home,'runs',path.rsplit('/',1)[1]))
                    result=record['result']
                    if fingerprint(data['part'])!=result['input_fingerprint']:
                        self.response(409,{'error':'尺寸已变化，请重新生成后导出'});return
                    fresh=generate(result['part'])
                    if fresh['engine_fingerprint']!=result['engine_fingerprint'] or fresh['programs']!=result['programs']:
                        self.response(409,{'error':'生成环境或历史程序变化，请重新生成'});return
                    self.response(200,zip_package(result),'application/zip',{'Content-Disposition':f'attachment; filename="{result["part"]["code"]}-candidate.zip"'});return
                self.response(404,{'error':'接口不存在'})
            except FileNotFoundError:self.response(404,{'error':'记录不存在'})
            except (PlanError,ValueError,KeyError,TypeError,UnicodeError) as exc:
                self.response(422,{'error':str(exc),'path':getattr(exc,'path','/')})
            except (OSError,RuntimeError) as exc:self.response(500,{'error':'本地存储或生成失败，未交付程序包'})
    return Handler


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8789)
    parser.add_argument('--home',type=Path,default=Path(__file__).resolve().parents[1]/'target/shaft-workbench-data')
    args=parser.parse_args();home=args.home.resolve();home.mkdir(parents=True,exist_ok=True)
    lease=(home/'instance.lock').open('a+b')
    try:
        # Reading byte zero before locking fails on Windows when another instance owns it.
        if os.fstat(lease.fileno()).st_size==0:lease.write(b'0');lease.flush()
        lease.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(lease.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(lease.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError:
        lease.close();parser.error('这个数据目录已被另一个工作台使用，请打开已有实例或指定独立--home')
    static=Path(__file__).resolve().parent/'static'
    if not (static/'workbench.html').exists():parser.error('请先执行 node scripts/build_workbench.mjs')
    server=ThreadingHTTPServer(('127.0.0.1',args.port),handler_factory(home,static))
    server.daemon_threads=True
    print(f'NCtool Shaft Workbench http://127.0.0.1:{server.server_port}',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close();lease.close()


if __name__=='__main__':main()
