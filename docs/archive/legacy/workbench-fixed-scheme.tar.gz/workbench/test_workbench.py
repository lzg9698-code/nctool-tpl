from copy import deepcopy
from pathlib import Path
import io,json,re,tempfile,threading,unittest,urllib.request,urllib.error,zipfile
from .domain import seed_part,validate,PlanError,fingerprint
from .post import generate,validate_sync,group_bounds,frozen
from .server import handler_factory,ThreadingHTTPServer,load_record


class PlannerTests(unittest.TestCase):
    def setUp(self):self.part=seed_part()
    def test_complete_package_and_new_rule_targets(self):
        r=generate(self.part)
        self.assertEqual(len(r['programs']),12)
        self.assertEqual(r['export_status'],'candidate_for_simulation')
        self.assertIn('G1 X100.535',r['programs']['1_0.MPF'])
        self.assertIn('G1 X120.300',r['programs']['1_0.MPF'])
        self.assertIn('G1 X135.588',r['programs']['2_0.MPF'])
        self.assertEqual(r['keys'][0]['bottom_radius'],'39.9')
        self.assertEqual(r['keys'][0]['depth_before'],'10.3675')
        self.assertEqual(r['keys'][1]['bottom_radius'],'55.4')
        self.assertTrue(all(c['passed'] for c in r['checks']))
        self.assertEqual([s['id'] for s in r['stages']][0],'incoming')
        self.assertEqual([s['id'] for s in r['stages']][-1],'ground')
    def test_outer_allowance_moves_targets_not_floor_or_relief(self):
        a=generate(self.part);self.part['cutting']['diameter_allowance']='0.7';b=generate(self.part)
        self.assertEqual(a['keys'][0]['bottom_radius'],b['keys'][0]['bottom_radius'])
        self.assertNotEqual(a['keys'][0]['depth_before'],b['keys'][0]['depth_before'])
        for file in ('1_0.MPF','3_0.MPF'):
            ac=[l for l in a['programs'][file].splitlines() if '; @wb:relief:' in l]
            bc=[l for l in b['programs'][file].splitlines() if '; @wb:relief:' in l]
            self.assertEqual(ac,bc)
    def test_lengths_propagate_to_parameter_and_key_position(self):
        self.part['lengths']['left']='220'
        r=generate(self.part)
        self.assertEqual(r['total_length'],'537.000')
        self.assertIn('I_R9[51]=537.000',r['programs']['DG_CAL_IR9.SPF'])
        self.assertIn('ATRANS X523.000 Z50.000',r['programs']['UZ_FKM_1.spf'])
        self.assertIn('ATRANS X202.000 Z67.500',r['programs']['UZ_FKM_2.spf'])
    def test_key_radius_width_length_and_depth_are_same_recipe(self):
        self.part['keys'][0].update(width='30',radius='9',length='195')
        r=generate(self.part);code=r['programs']['UZ_FKM_1.spf']
        self.assertIn('Y15.000',code);self.assertIn('X-177.000',code);self.assertIn('J-9.000',code)
        self.assertEqual(r['keys'][0]['width'],'30.000');self.assertEqual(r['keys'][0]['length'],'195.000')
    def test_third_key_full_closure_and_removal(self):
        self.part['keys'].append({'id':'key-c','title':'键槽C','region':'middle','offset':'56','length':'35','width':'28','radius':'8',
                                 'depth_lower':'7','depth_upper':'7.2','depth_target':'7.1','datum':'average','chamfer':True})
        r=generate(self.part);self.assertEqual(len(r['programs']),15)
        for prefix in ('RKM','FKM','DJ'):self.assertIn('UZ_'+prefix+'_3',r['programs']['1_0.MPF'])
        self.part['keys'].pop(0);r=generate(self.part)
        self.assertEqual(len(r['programs']),12);self.assertNotIn('UZ_FKM_3',r['programs']['1_0.MPF'])

    def test_default_current_and_preselected_tools_match_sample(self):
        result=generate(self.part)['programs'];source,_=frozen()
        def chain(code):return re.findall(r'^L171\("([^"\n]+)"\)',code,re.M)
        for file in result:
            with self.subTest(file=file):self.assertEqual(chain(result[file]),chain(source[file]))

    def test_changed_tools_and_removed_key_rebuild_actual_preselection_chain(self):
        self.part['keys'].pop(0);self.part['keys'][0]['chamfer']=False
        self.part['tools'].update(rough1='T91',finish1='T71',relief1='T121',rings='T141',key_rough_b='CT2021',key_finish_b='6012')
        result=generate(self.part)['programs'];main=result['1_0.MPF'].splitlines()
        def chain(code):return re.findall(r'^L171\("([^"\n]+)"\)',code,re.M)
        for group,expected in [('Sync Turning right side',['T91','T71']),('Right SIDE FINISHING',['T71','T121']),
                               ('LFET SIDE RELIEF GROOVE',['T121','T141']),('TURNING SHARP GROOVE',['T141','CT2021'])]:
            start,end=group_bounds(main,group)
            self.assertEqual(chain('\n'.join(main[start:end+1])),expected)
        self.assertEqual(chain(result['UZ_RKM_1.spf']),['CT2021','6012'])
        self.assertEqual(chain(result['UZ_FKM_1.spf']),['6012','DECKEL'])
        self.assertNotIn('UZ_DJ_1',result['1_0.MPF'])
        self.assertNotIn('L171("T9")',result['1_0.MPF'])

    def test_third_key_preselection_follows_call_order_and_disabled_chamfer(self):
        self.part['keys'].append({'id':'key-c','title':'键槽C','region':'middle','offset':'56','length':'35','width':'28','radius':'8',
                                 'depth_lower':'7','depth_upper':'7.2','depth_target':'7.1','datum':'average','chamfer':False})
        result=generate(self.part)['programs']
        calls=re.findall(r'^UZ_(?:RKM|FKM|DJ)_\d+$',result['1_0.MPF'],re.M)
        expected=['CT1017','CT1021','CT1017','5010','5012','5010','1631','1631','DECKEL']
        self.assertEqual(len(calls),len(expected)-1)
        for i,call in enumerate(calls):
            self.assertEqual(re.findall(r'^L171\("([^"\n]+)"\)',result[call+'.spf'],re.M),expected[i:i+2])
    def test_invalid_inputs_do_not_produce_package(self):
        for path,value in [('stock','100'),('radius','20'),('length','500'),('depth','12')]:
            p=deepcopy(self.part)
            if path=='stock':p['stock']['diameter']=value
            elif path=='radius':p['keys'][0]['radius']=value
            elif path=='length':p['keys'][0]['length']=value
            else:p['keys'][0]['depth_target']=value
            with self.subTest(path=path),self.assertRaises(PlanError):generate(p)
    def test_nonfinite_precision_and_tool_injection_rejected(self):
        for value in ('NaN','Infinity','100.0001',100,True):
            p=deepcopy(self.part);p['stock']['diameter']=value
            with self.subTest(value=value),self.assertRaises(PlanError):generate(p)
        self.part['tools']['finish1']='T12")\nM30'
        with self.assertRaises(PlanError):generate(self.part)
    def test_measurement_off_initializes_every_run(self):
        self.part['measurement']=False;r=generate(self.part)
        self.assertIn('PROBE disabled',r['programs']['1_0.MPF'])
        self.assertIn('I_R9[43]=0',r['programs']['DG_CAL_IR9.SPF'])
        self.assertNotIn('GOTOF "STEP_"',r['programs']['1_0.MPF'])
    def test_sync_missing_participant_and_deadlock_rejected(self):
        programs=generate(self.part)['programs'];programs['2_0.MPF']=programs['2_0.MPF'].replace('WAITM(13,1,2)',';removed')
        with self.assertRaises(PlanError):validate_sync(programs)
        with self.assertRaises(PlanError):validate_sync({'1_0.MPF':'WAITM(10,1,2)\nWAITM(11,1,2)',
                                                     '2_0.MPF':'WAITM(11,1,2)\nWAITM(10,1,2)','3_0.MPF':''})
    def test_source_map_references_actual_emitted_lines(self):
        r=generate(self.part)
        for m in r['source_map']:
            line=r['programs'][m['file']].splitlines()[m['line']-1]
            self.assertIn('@wb:'+m['stage']+':'+m['feature'],line)
        for p in r['trajectory']:
            for point in (p['start'],p['end']):self.assertTrue(abs(point['r'])<10000 and abs(point['z'])<10000)

    def test_keyway_arcs_and_projection_use_actual_emitted_coordinates(self):
        r=generate(self.part);paths=[p for p in r['trajectory'] if p['file']=='UZ_FKM_1.spf']
        arcs=[p for p in paths if len(p['local_points'])>2]
        self.assertEqual(len(arcs),4)
        cut=next(p for p in paths if p['local_points'][0]['x']==0 and p['local_points'][-1]['x']==-181.25)
        self.assertEqual(cut['start']['r'],39.9);self.assertEqual(cut['end']['r'],39.9)
        self.assertEqual(cut['start']['z'],513);self.assertEqual(cut['end']['z'],331.75)
        self.assertTrue(all(p['feature']=='key-a' for p in paths))

    def test_rough_material_state_matches_program_region_targets(self):
        r=generate(self.part);profile=next(s for s in r['stages'] if s['id']=='rough')['profile']
        middle=next(b for b in profile if b['id']=='middle')['diameter'];bearing=next(b for b in profile if b['id']=='bearing')['diameter']
        self.assertEqual(middle,bearing)
        self.assertEqual(middle,'122.535')

    def test_key_crossing_different_finished_diameters_checks_whole_floor(self):
        p=deepcopy(self.part);p['keys']=[{'id':'mixed','title':'crossing','region':'middle','offset':'25','length':'35','width':'28','radius':'8',
                                      'depth_lower':'7','depth_upper':'7.2','depth_target':'7.1','datum':'average','chamfer':True}]
        with self.assertRaises(PlanError):generate(p)
        a=validate(self.part)['keys'][0]
        self.assertEqual(a['depth_after_min'],__import__('decimal').Decimal('10.0565'))
        self.assertIn('cap',a['crossed_surfaces'])

    def test_controlled_program_references_and_frames_reject_corruption(self):
        from .post import validate_program_structure
        base=generate(self.part)['programs']
        changes=[('KANAL1_2_3.JOB','SELECT 3_0.MPF CH=3','SELECT 3_0.MPF CH=2'),
                 ('1_0.MPF','GOTOF STEP_0','GOTOF MISSING_STEP'),
                 ('UZ_FKM_1.spf','G17','G18'),('UZ_FKM_1.spf','\nTRANS\n','\n; missing reset\n')]
        for file,old,new in changes:
            programs=dict(base);programs[file]=programs[file].replace(old,new)
            with self.subTest(file=file,old=old),self.assertRaises(PlanError):validate_program_structure(programs)
        programs=dict(base);del programs['UZ_FKM_1.spf']
        with self.assertRaises(PlanError):validate_program_structure(programs)
        programs=dict(base);programs['2_0.MPF']=programs['2_0.MPF'].replace('WAITM(13,1,2)','WAITM(13,1,2,4)')
        with self.assertRaises(PlanError):validate_sync(programs)

    def test_cli_complete_directory_preserves_existing_output_and_invalid_input(self):
        from .__main__ import write_candidate
        import hashlib
        with tempfile.TemporaryDirectory() as directory:
            target=Path(directory)/'candidate';r=write_candidate(self.part,target)
            manifest=json.loads((target/'manifest.json').read_text(encoding='utf-8'))
            self.assertEqual(len(manifest['programs']),12)
            for name,sha in manifest['programs'].items():
                self.assertEqual(hashlib.sha256((target/name).read_bytes()).hexdigest(),sha)
            self.assertEqual(json.loads((target/'input.json').read_text(encoding='utf-8')),self.part)
            before=(target/'1_0.MPF').read_bytes()
            with self.assertRaises(PlanError):write_candidate(self.part,target)
            self.assertEqual((target/'1_0.MPF').read_bytes(),before)
            self.part['stock']['diameter']='100'
            with self.assertRaises(PlanError):write_candidate(self.part,Path(directory)/'invalid')
            self.assertFalse((Path(directory)/'invalid').exists())
            self.assertFalse(list(Path(directory).glob('*.pending-*')))


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.home=Path(self.temp.name)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(self.home,Path(__file__).parent/'static'))
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.base=f'http://127.0.0.1:{self.server.server_port}'
        self.token=json.load(urllib.request.urlopen(self.base+'/api/bootstrap'))['csrf']
    def tearDown(self):self.server.shutdown();self.server.server_close();self.thread.join();self.temp.cleanup()
    def request(self,path,body=None,headers=None):
        h={'Content-Type':'application/json','X-Workbench-Token':self.token};h.update(headers or {})
        req=urllib.request.Request(self.base+path,data=json.dumps(body).encode() if body is not None else None,headers=h)
        try:
            with urllib.request.urlopen(req) as response:return response.status,response.read()
        except urllib.error.HTTPError as e:return e.code,e.read()
    def test_save_conflict_and_reload(self):
        part=seed_part();s,raw=self.request('/api/save',{'part':part});self.assertEqual(s,200)
        record=json.loads(raw);id=record['record']['id'];part['title']='changed'
        self.assertEqual(self.request('/api/save',{'part':part,'id':id,'etag':'stale'})[0],409)
        self.assertEqual(self.request('/api/save',{'part':part,'id':id,'etag':record['etag']})[0],200)
        self.assertEqual(json.loads(self.request('/api/projects/'+id)[1])['record']['part']['title'],'changed')
    def test_frozen_zip_and_stale_input(self):
        part=seed_part();status,raw=self.request('/api/generate',{'part':part});self.assertEqual(status,200)
        id=json.loads(raw)['id'];status,raw=self.request('/api/export/'+id,{'part':part});self.assertEqual(status,200)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            self.assertIn('3_0.MPF',z.namelist());self.assertIn('UZ_FKM_2.spf',z.namelist())
            self.assertEqual(json.loads(z.read('manifest.json'))['purpose'],'simulation-candidate')
        part['stock']['diameter']='151'
        self.assertEqual(self.request('/api/export/'+id,{'part':part})[0],409)
    def test_invalid_input_returns_no_programs(self):
        part=seed_part();part['stock']['diameter']='100'
        s,raw=self.request('/api/generate',{'part':part});self.assertEqual(s,422)
        self.assertNotIn('programs',json.loads(raw));self.assertFalse(list((self.home/'runs').glob('*')))
    def test_origin_token_and_path_boundary(self):
        body={'part':seed_part()}
        self.assertEqual(self.request('/api/generate',body,{'X-Workbench-Token':''})[0],403)
        self.assertEqual(self.request('/api/generate',body,{'Origin':'https://foreign.example'})[0],403)
        self.assertEqual(self.request('/api/projects/../../etc')[0],422)
        self.assertEqual(self.request('/../server.py')[0],404)
    def test_tampered_history_fails_closed(self):
        _,raw=self.request('/api/generate',{'part':seed_part()});id=json.loads(raw)['id']
        p=self.home/'runs'/(id+'.json');data=json.loads(p.read_text(encoding='utf-8'));data['payload']['result']['programs']['1_0.MPF']='M30\n';p.write_text(json.dumps(data),encoding='utf-8')
        self.assertEqual(self.request('/api/export/'+id,{'part':seed_part()})[0],422)


if __name__=='__main__':
    import sys
    if '--skip-downloads' in sys.argv:
        sys.argv.remove('--skip-downloads')
        suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]);filtered=unittest.TestSuite()
        def add_tests(items):
            for test in items:
                if isinstance(test,unittest.TestSuite):add_tests(test)
                elif not any(name in test.id() for name in ('test_frozen_zip_and_stale_input','test_tampered_history_fails_closed')):filtered.addTest(test)
        add_tests(suite)
        raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(filtered).wasSuccessful())
    unittest.main()

