"""Deterministic part targets and material states. No CNC/PLC side effects."""
from __future__ import annotations
from copy import deepcopy
from decimal import Decimal, InvalidOperation, ROUND_CEILING
import hashlib
import json
import re

D = Decimal
LENGTH_IDS = ('left', 'shoulder', 'bearing', 'middle', 'right', 'tail')
DIAMETER_IDS = ('left', 'cap', 'middle', 'bearing', 'right', 'tail')
REGION_LABELS = {'left':'长轴段','cap':'端部配合','middle':'中间轴段','bearing':'轴承区','right':'大径轴段','tail':'短轴段'}
TOOLS = {'rough1':'T9','rough2':'T5','finish1':'T7','finish2':'T8','relief1':'T12','relief3':'T3','rings':'T14',
         'key_rough_a':'CT1017','key_finish_a':'5010','key_rough_b':'CT1021','key_finish_b':'5012','chamfer':'1631'}


class PlanError(ValueError):
    def __init__(self, path, message):
        self.path = path
        super().__init__(message)


def num(value, path, minimum=None, maximum=None):
    if not isinstance(value,str) or not re.fullmatch(r'-?\d+(?:\.\d{1,3})?',value):
        raise PlanError(path,'请输入最多三位小数的十进制数')
    try: result=D(value)
    except InvalidOperation: raise PlanError(path,'数值无效') from None
    if not result.is_finite(): raise PlanError(path,'数值必须有限')
    if minimum is not None and result<D(str(minimum)): raise PlanError(path,f'不能小于 {minimum}')
    if maximum is not None and result>D(str(maximum)): raise PlanError(path,f'不能大于 {maximum}')
    return result


def text(value, precision=3):
    return format(D(value),f'.{precision}f')


def fingerprint(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def seed_part():
    def dim(n,lo,hi,fit): return {'nominal':n,'lower':lo,'upper':hi,'fit':fit}
    return {'format':'nctool-shaft/1','code':'14594226','title':'输出轴 · 100 × 210','machine_profile':'index-g420-14594226',
            'lengths':{'left':'210','shoulder':'22','bearing':'29','middle':'47','right':'186','tail':'33'},
            'diameters':{'left':dim('100','100.013','100.035','m6'),'cap':dim('100','99.913','100','h9'),
                         'middle':dim('120','120.013','120.035','m6'),'bearing':dim('119.8','119.746','119.8','h8'),
                         'right':dim('135','135.063','135.088','r6'),'tail':dim('100','99.913','100','h9')},
            'stock':{'diameter':'150','center_depth':'29.61','spindle_limit':'600'},
            'cutting':{'diameter_allowance':'0.5','fs_face_allowance':'0.1','rough_remaining':'2',
                       'ap1':'5','ap2':'5.63','feed':'0.5','black_drop':'5.5'},
            'keys':[{'id':'key-a','title':'键槽 A','region':'left','offset':'6','length':'197.25','width':'28','radius':'8',
                     'depth_lower':'10','depth_upper':'10.2','depth_target':'10.1','datum':'high-end','chamfer':True},
                    {'id':'key-b','title':'键槽 B','region':'right','offset':'7','length':'171.25','width':'36','radius':'10',
                     'depth_lower':'12','depth_upper':'12.3','depth_target':'12.1','datum':'average','chamfer':True}],
            'tools':dict(TOOLS),'measurement':True,'notes':''}


def validate(part):
    if not isinstance(part,dict): raise PlanError('/','零件必须为对象')
    allowed={'format','code','title','machine_profile','lengths','diameters','stock','cutting','keys','tools','measurement','notes'}
    if set(part)!=allowed or part.get('format')!='nctool-shaft/1': raise PlanError('/','零件格式或字段不匹配')
    if not isinstance(part['code'],str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,48}',part['code']):
        raise PlanError('/code','零件号仅支持字母、数字、下划线或连字符，最多48字')
    if not isinstance(part['title'],str) or not 1<=len(part['title'])<=120 or any(c in part['title'] for c in '\r\n'):
        raise PlanError('/title','名称不能为空或包含换行')
    if part['machine_profile']!='index-g420-14594226': raise PlanError('/machine_profile','机床方案未支持')
    if type(part['measurement']) is not bool: raise PlanError('/measurement','测量开关须为布尔值')
    if not isinstance(part['notes'],str) or len(part['notes'])>4000: raise PlanError('/notes','备注过长')
    if not isinstance(part['lengths'],dict) or set(part['lengths'])!=set(LENGTH_IDS): raise PlanError('/lengths','轴向尺寸不完整')
    lengths={k:num(part['lengths'][k],'/lengths/'+k,5,1200) for k in LENGTH_IDS}
    total=sum(lengths.values())
    if total>2000: raise PlanError('/lengths','本机方案的总长上限为2000 mm')
    if lengths['left']<25: raise PlanError('/lengths/left','长轴段需容纳17 mm端部配合及接近过渡')
    if not isinstance(part['diameters'],dict) or set(part['diameters'])!=set(DIAMETER_IDS): raise PlanError('/diameters','配合尺寸不完整')
    dims={}
    for role in DIAMETER_IDS:
        item=part['diameters'][role];path='/diameters/'+role
        if not isinstance(item,dict) or set(item)!={'nominal','lower','upper','fit'}: raise PlanError(path,'尺寸字段不完整')
        n=num(item['nominal'],path+'/nominal',20,400);lo=num(item['lower'],path+'/lower',10,450);hi=num(item['upper'],path+'/upper',10,450)
        if lo>hi or abs(lo-n)>2 or abs(hi-n)>2: raise PlanError(path,'上下限颠倒或偏离名义尺寸超过2 mm')
        if not isinstance(item['fit'],str) or len(item['fit'])>24: raise PlanError(path+'/fit','配合标记无效')
        dims[role]={'nominal':n,'lower':lo,'upper':hi,'fit':item['fit']}
    if dims['cap']['nominal']!=dims['left']['nominal']: raise PlanError('/diameters/cap','端部配合与长轴段名义直径须相同')
    if not dims['left']['nominal']<dims['middle']['nominal']<=dims['right']['nominal']:
        raise PlanError('/diameters','本方案要求长轴段 < 中间轴段 ≤ 大径轴段')
    if dims['tail']['nominal']>=dims['right']['nominal']: raise PlanError('/diameters/tail','短轴段必须小于大径轴段')
    if dims['bearing']['nominal']>dims['middle']['nominal']: raise PlanError('/diameters/bearing','轴承区不能大于相邻中间轴段')
    if not isinstance(part['cutting'],dict) or set(part['cutting'])!={'diameter_allowance','fs_face_allowance','rough_remaining','ap1','ap2','feed','black_drop'}:
        raise PlanError('/cutting','切削参数不完整')
    c=part['cutting']
    cutting={'diameter_allowance':num(c['diameter_allowance'],'/cutting/diameter_allowance',0,2),
             'fs_face_allowance':num(c['fs_face_allowance'],'/cutting/fs_face_allowance',0,.5),
             'rough_remaining':num(c['rough_remaining'],'/cutting/rough_remaining',.2,6),
             'ap1':num(c['ap1'],'/cutting/ap1',.5,8),'ap2':num(c['ap2'],'/cutting/ap2',.5,10),
             'feed':num(c['feed'],'/cutting/feed',.01,1),'black_drop':num(c['black_drop'],'/cutting/black_drop',.5,10)}
    if cutting['feed']!=cutting['feed'].quantize(D('.01')): raise PlanError('/cutting/feed','同步进给须为0.01的整数倍')
    if not isinstance(part['stock'],dict) or set(part['stock'])!={'diameter','center_depth','spindle_limit'}: raise PlanError('/stock','毛坯输入不完整')
    stock=num(part['stock']['diameter'],'/stock/diameter',30,500)
    targets={role:item['upper']+cutting['diameter_allowance'] for role,item in dims.items()}
    if stock-cutting['black_drop']<=max(targets.values())+cutting['rough_remaining']:
        raise PlanError('/stock/diameter','去黑皮后材料不足以覆盖各磨前目标和粗车余量')
    center_depth=num(part['stock']['center_depth'],'/stock/center_depth',1,60)
    if center_depth*2>=total:raise PlanError('/stock/center_depth','两端中心孔深度不能占满总长')
    limit=num(part['stock']['spindle_limit'],'/stock/spindle_limit',50,3000)
    if limit!=limit.to_integral_value(): raise PlanError('/stock/spindle_limit','转速上限须为整数')
    if not isinstance(part['tools'],dict) or set(part['tools'])!=set(TOOLS): raise PlanError('/tools','刀具角色不完整')
    for role,name in part['tools'].items():
        if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,40}',name): raise PlanError('/tools/'+role,'刀具标识不可包含引号、空格或指令')
    if not isinstance(part['keys'],list) or not 1<=len(part['keys'])<=3: raise PlanError('/keys','本版支持1～3处键槽')
    origins={};cursor=D(0)
    for role in LENGTH_IDS: origins[role]=cursor;cursor+=lengths[role]
    region_intervals={'left':(D(0),lengths['left']),'middle':(origins['shoulder'],origins['right']),
                      'right':(origins['right'],origins['tail']),'tail':(origins['tail'],total)}
    surface_intervals=[('cap',D(0),D(17)),('left',D(17),lengths['left']),
                       ('middle',origins['shoulder'],origins['bearing']),('bearing',origins['bearing'],origins['middle']),
                       ('middle',origins['middle'],origins['right']),('right',origins['right'],origins['tail']),('tail',origins['tail'],total)]
    keys=[];seen=set()
    allowed_key={'id','title','region','offset','length','width','radius','depth_lower','depth_upper','depth_target','datum','chamfer'}
    for index,k in enumerate(part['keys']):
        path='/keys/'+str(index)
        if not isinstance(k,dict) or set(k)!=allowed_key: raise PlanError(path,'键槽字段不完整')
        if not isinstance(k['id'],str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,48}',k['id']) or k['id'] in seen: raise PlanError(path+'/id','特征ID无效或重复')
        seen.add(k['id'])
        if not isinstance(k['title'],str) or len(k['title'])>80: raise PlanError(path+'/title','键槽名称无效')
        if k['region'] not in region_intervals: raise PlanError(path+'/region','键槽所属轴段无效')
        if k['datum'] not in ('high-end','average','low-end'): raise PlanError(path+'/datum','键槽定位基准无效')
        if type(k['chamfer']) is not bool: raise PlanError(path+'/chamfer','倒角开关无效')
        offset=num(k['offset'],path+'/offset',1,1500);length=num(k['length'],path+'/length',20,1200)
        width=num(k['width'],path+'/width',28,80);radius=num(k['radius'],path+'/radius',8,40)
        if 2*radius>min(width,length): raise PlanError(path+'/radius','角部圆弧无法容纳于槽宽/槽长')
        lo=num(k['depth_lower'],path+'/depth_lower',1,30);hi=num(k['depth_upper'],path+'/depth_upper',1,30)
        depth=num(k['depth_target'],path+'/depth_target',1,30)
        if lo>hi or depth<lo or depth>hi: raise PlanError(path+'/depth_target','槽深目标必须在图纸区间内')
        start,end=region_intervals[k['region']];position=start+offset
        if position+length>end-1: raise PlanError(path+'/length','键槽超出所属轴段，需保留至少1 mm端部范围')
        outer=dims[k['region']];floor=outer['nominal']/2-depth
        crossed=[role for role,a,b in surface_intervals if max(position,a)<min(position+length,b)]
        min_depth=min(dims[role]['lower']/2-floor for role in crossed)
        max_depth=max(dims[role]['upper']/2-floor for role in crossed)
        if floor<=0 or min_depth<lo or max_depth>hi: raise PlanError(path+'/depth_target','固定槽底在外圆磨后不能覆盖全部图纸槽深范围')
        if width/2>=outer['nominal']/2-3: raise PlanError(path+'/width','键槽过宽，超出本版圆柱倒角策略范围')
        keys.append({**k,'index':index+1,'s':position,'z_anchor':total-position-radius,'length':length,'width':width,'radius':radius,
                     'depth':depth,'bottom_radius':floor,'surface_radius':outer['nominal']/2,
                     'depth_after_min':min_depth,'depth_after_max':max_depth,
                     'depth_before':targets[k['region']]/2-floor,'crossed_surfaces':crossed})
    for i,a in enumerate(keys):
        for b in keys[i+1:]:
            if a['region']==b['region'] and max(a['s'],b['s'])<min(a['s']+a['length'],b['s']+b['length']):
                raise PlanError('/keys','同一轴段的键槽范围重叠；本版只支持同一周向的独立槽')
    return {'lengths':lengths,'dims':dims,'total':total,'stock':stock,'cutting':cutting,'targets':targets,
            'origins':origins,'region_intervals':region_intervals,'keys':keys}


def make_states(v):
    lengths=v['lengths'];total=v['total'];s=v['origins'];targets=v['targets'];dims=v['dims'];cut=v['cutting']
    def bands(mode):
        rows=[]
        for region in LENGTH_IDS:
            role=region if region in ('left','bearing','right','tail') else 'middle'
            d=dims[role]['nominal'] if mode=='finished' else targets[role]
            if mode=='rough': d=targets['middle' if region=='bearing' else role]+cut['rough_remaining']
            if mode=='rough' and region=='tail': d=targets['tail']+1
            if mode=='stock': d=v['stock']
            if mode=='skin': d=v['stock']-cut['black_drop'] if region!='tail' else targets['tail']+1
            rows.append({'id':region,'s0':text(s[region]),'s1':text(s[region]+lengths[region]),'diameter':text(d)})
        return rows
    definitions=[('incoming','入机毛坯','stock','定长、两端面及中心孔已完成；确认来料与支撑条件。','驱动盘＋尾座'),
                 ('grip','夹口准备','stock','二通道先加工短端夹口，主体保持毛坯。','驱动盘＋尾座'),
                 ('skin','去黑皮','skin','夹紧卡爪后去除主体黑皮，夹口维持支撑。','卡爪＋尾座'),
                 ('rough','双刀粗车','rough','按当前材料和磨前目标计算成对刀次；每刀在等待点协调。','卡爪＋尾座'),
                 ('finish','磨前精车','target','长轴段、端配合、轴承区等分别按成品上限加直径余量。','驱动盘＋尾座'),
                 ('relief','ES / FS槽','target','槽局部轮廓零附加余量；FS关联端面独立留量。','驱动盘＋尾座'),
                 ('rings','窄环槽','target','包装循环沿用冻结样例，图中槽形为名义示意，需外部仿真核对。','驱动盘＋尾座'),
                 ('key_rough','键槽粗 / 半精','target','槽底定位于成品位置；半精后侧壁仍留精铣材料。','卡爪＋尾座'),
                 ('key_finish','键槽精铣','target','精铣侧壁和角圆弧；槽底不随外圆磨削余量移动。','卡爪＋尾座'),
                 ('chamfer','键槽倒角 / 下料','target','完成槽口去锐边，交付磨前中间件。','卡爪＋尾座'),
                 ('ground','磨后目标','finished','这是后续磨削目标，程序包不包含磨削执行。','后续工序')]
    result=[]
    for index,(id,title,mode,description,holding) in enumerate(definitions):
        profile=bands(mode)
        if id=='grip': profile[-1]['diameter']=text(targets['tail']+1)
        if id=='finish' or index>4:
            profile.insert(0,{'id':'cap','s0':'0.000','s1':'17.000','diameter':text(dims['cap']['nominal'] if mode=='finished' else targets['cap'])})
            profile[1]['s0']='17.000'
        key_states=[]
        if index>=7:
            for k in v['keys']:
                wall=D('.1') if id=='key_rough' else D(0)
                key_states.append({'id':k['id'],'title':k['title'],'s':text(k['s']),'length':text(k['length']-2*wall),
                                   'width':text(k['width']-2*wall),'radius':text(k['radius']),
                                   'bottom_radius':str(k['bottom_radius']),'depth':str(k['depth_before'] if id!='ground' else k['depth_after_min'])})
        result.append({'id':id,'title':title,'description':description,'holding':holding,'profile':profile,'keys':key_states,
                       'reliefs':index>=5,'rings':index>=6,'cutting_stage':id!='ground'})
    return result
