import {build} from '../ui/node_modules/vite/dist/node/index.js';
import {resolve,dirname,sep} from 'node:path';
import {fileURLToPath} from 'node:url';
import {writeFileSync,readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const destination=resolve(root,'workbench/static');
if(!destination.startsWith(root+sep)||!destination.endsWith(sep+'workbench'+sep+'static'))throw new Error('Unsafe build output');
execFileSync(process.execPath,[resolve(root,'ui/node_modules/typescript/bin/tsc'),'--project',resolve(root,'ui/tsconfig.workbench.json')],{cwd:root,stdio:'inherit'});
console.log('Build output:',destination);
await build({configFile:false,root:resolve(root,'ui'),base:'/',
  build:{outDir:destination,emptyOutDir:true,sourcemap:true,
    rollupOptions:{input:resolve(root,'ui/workbench.html')}}});
const files=['ui/src/workbench/main.tsx','ui/src/workbench/style.css','ui/workbench.html','ui/tsconfig.json','ui/tsconfig.workbench.json','ui/package.json','ui/package-lock.json','scripts/build_workbench.mjs'];
const manifest={format:'nctool-workbench-ui/1',files:Object.fromEntries(files.map(p=>[p,createHash('sha256').update(readFileSync(resolve(root,p))).digest('hex')]))};
writeFileSync(resolve(root,'workbench/static/source-manifest.json'),JSON.stringify(manifest,null,2));
