"""Launch/reuse this workspace's local app, without touching foreign listeners."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time,urllib.request,urllib.error,webbrowser

ROOT=Path(__file__).resolve().parents[1]
def identity(home):return hashlib.sha256((str(ROOT)+'|'+str(home)).encode()).hexdigest()
def probe(url):
    try:
        with urllib.request.urlopen(url+'/api/bootstrap',timeout=1) as r:return json.load(r)
    except (OSError,ValueError):return None
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--port',type=int,default=8789)
    p.add_argument('--home',type=Path,default=ROOT/'target/shaft-workbench-data');p.add_argument('--no-open',action='store_true')
    args=p.parse_args();home=args.home.resolve();home.mkdir(parents=True,exist_ok=True)
    url=f'http://127.0.0.1:{args.port}';existing=probe(url)
    if existing:
        if existing.get('workspace_key')!=identity(home):raise SystemExit('该端口由其他服务或工作区使用；请指定另一端口，不会停止该服务。')
        if not existing.get('engine_current',True):raise SystemExit('服务代码已变化，请先运行停止工作台，再重新启动。')
    else:
        logs=home/'logs';logs.mkdir(exist_ok=True)
        with (logs/'server.log').open('ab') as log:
            child=subprocess.Popen([sys.executable,'-u','-m','workbench.server','--port',str(args.port),'--home',str(home)],cwd=ROOT,
                                   stdin=subprocess.DEVNULL,stdout=log,stderr=log,
                                   creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        for _ in range(80):
            existing=probe(url)
            if existing:break
            if child.poll() is not None:raise SystemExit('服务启动失败，请查看 '+str(logs/'server.log'))
            time.sleep(.15)
        if not existing or existing.get('workspace_key')!=identity(home):
            child.terminate();raise SystemExit('未确认工作台启动，已停止本轮进程。')
    print(url)
    if not args.no_open:webbrowser.open(url)
if __name__=='__main__':main()
