"""Verify launch ownership, material preservation and non-download delivery evidence."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib,json,socket,subprocess,sys,tempfile,threading,time,urllib.request

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'target/workbench-v1'

def run(*args,success=True):
    result=subprocess.run([sys.executable,*args],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=25)
    assert (result.returncode==0)==success,(args,result.stdout,result.stderr)
    return result.stdout+result.stderr

def port():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]

def get(url):
    with urllib.request.urlopen(url,timeout=3) as r:return json.load(r)

def gone(url):
    for _ in range(30):
        try:get(url+'/api/bootstrap')
        except OSError:return
        time.sleep(.1)
    raise AssertionError('owned service did not stop')

def post(url,path,data,token):
    request=urllib.request.Request(url+path,data=json.dumps(data).encode(),headers={'Content-Type':'application/json','X-Workbench-Token':token})
    with urllib.request.urlopen(request,timeout=10) as r:return r.read()

def main():
    OUT.mkdir(parents=True,exist_ok=True);checks=[]
    def passed(name):checks.append(name);print('PASS',name,flush=True)
    with tempfile.TemporaryDirectory(prefix='launch-',dir=OUT,ignore_cleanup_errors=True) as folder:
        chosen=port();home=Path(folder)/'home';url=f'http://127.0.0.1:{chosen}'
        args=['--port',str(chosen),'--home',str(home)]
        try:
            run('scripts/start_workbench.py',*args,'--no-open');boot=get(url+'/api/bootstrap')
            assert boot['engine_current'];key=boot['workspace_key']
            run('scripts/start_workbench.py',*args,'--no-open');assert get(url+'/api/bootstrap')['workspace_key']==key
            passed('launcher starts and reuses the same owned instance')
            rejected=run('-m','workbench.server','--port',str(port()),'--home',str(home),success=False)
            assert '已被另一个工作台使用' in rejected,rejected
            passed('exclusive data-directory lease rejects a second instance')
            run('scripts/stop_workbench.py','--port',str(chosen),'--home',str(Path(folder)/'foreign'),success=False)
            assert get(url+'/api/bootstrap')['workspace_key']==key
            passed('stop refuses a different workspace')
            run('scripts/stop_workbench.py',*args);gone(url)
            run('scripts/start_workbench.py',*args,'--no-open');assert get(url+'/api/bootstrap')['engine_current']
            run('scripts/stop_workbench.py',*args);gone(url)
            passed('owned stop and restart work without deleting data')
        finally:
            try:
                current=get(url+'/api/bootstrap')
                if current.get('workspace_key')==locals().get('key'):
                    run('scripts/stop_workbench.py',*args);gone(url)
            except OSError:pass
            time.sleep(.2) # Let the owned Windows process release the log handle.
        class Foreign(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):
                raw=b'{"workspace_key":"foreign"}';self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
        foreign=ThreadingHTTPServer(('127.0.0.1',0),Foreign);thread=threading.Thread(target=foreign.serve_forever,daemon=True);thread.start()
        try:
            foreign_url=f'http://127.0.0.1:{foreign.server_port}'
            run('scripts/start_workbench.py','--port',str(foreign.server_port),'--home',str(home),'--no-open',success=False)
            assert get(foreign_url+'/api/bootstrap')['workspace_key']=='foreign'
            passed('launcher refuses a foreign listener and leaves it running')
        finally:foreign.shutdown();foreign.server_close();thread.join()

    original=json.loads((OUT/'source-baseline/manifest.json').read_text(encoding='utf-8'))
    changed=[f['path'] for f in original['files'] if hashlib.sha256((ROOT/f['path']).read_bytes()).hexdigest()!=f['sha256']]
    assert set(changed)=={'cli/ui/source.sha256','docs/README.md'},changed
    passed('all 336 baseline files preserved except generated UI source fingerprint and documented navigation additions')
    nc=json.loads((ROOT/'target/proposal-review/nc-source-before.json').read_text(encoding='utf-8'))
    assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha for name,sha in nc.items())
    passed(f'all {len(nc)} original drawing and NC files remain byte-identical')
    browser=json.loads((OUT/'browser/report.json').read_text(encoding='utf-8'))
    assert browser['errors']==[] and len(browser['passed'])==19 and browser.get('skipDownloads') is True
    assert browser['source']==hashlib.sha256((ROOT/'ui/src/workbench/main.tsx').read_bytes()).hexdigest()
    passed('19 current browser workflow checks pass; no download triggered or inspected')

    url='http://127.0.0.1:8789';boot=get(url+'/api/bootstrap');assert boot['engine_current']
    part=boot['sample'];result=json.loads(post(url,'/api/plan',{'part':part},boot['csrf']))['result']
    assert 'L171("T9")\nL172(0)\nL171("T7")' in result['programs']['1_0.MPF']
    assert 'L171("CT1017")\nL172(0)\nL171("CT1021")' in result['programs']['UZ_RKM_1.spf']
    assert 'G1 X100.535' in result['programs']['1_0.MPF']
    passed('formal 8789 service computes the confirmed current/preselected tool chain')
    cli=Path(tempfile.mkdtemp(prefix='cli-',dir=OUT))
    run('-m','workbench','sample','--output',str(cli/'part.json'))
    run('-m','workbench','generate','--input',str(cli/'part.json'),'--out-dir',str(cli/'candidate'))
    manifest=json.loads((cli/'candidate/manifest.json').read_text(encoding='utf-8'))
    assert len(manifest['programs'])==12 and manifest['purpose']=='simulation-candidate'
    assert all(hashlib.sha256((cli/'candidate'/name).read_bytes()).hexdigest()==sha for name,sha in manifest['programs'].items())
    run('-m','workbench','generate','--out-dir',str(cli/'candidate'),success=False)
    passed('documented CLI creates all 12 files and refuses existing output')
    ui=json.loads((ROOT/'workbench/static/source-manifest.json').read_text(encoding='utf-8'))
    assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha for name,sha in ui['files'].items())
    passed('served UI source manifest matches current source')
    receipt={'checks':checks,'head':original['head'],'dirty':True,'url':url,'engine_fingerprint':result['engine_fingerprint'],
             'browser_report':browser,'baseline_changed':changed,'source_nc_count':len(nc),
             'machine_acceptance':'not_performed','downloads':'not_tested_user_requested_stop','cli_output':str(cli/'candidate'),
             'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for directory in ['workbench','ui/src/workbench'] for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts}}
    (OUT/'delivery-verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':main()
