from pathlib import Path
import argparse,json,urllib.request
from start_workbench import ROOT,identity,probe

p=argparse.ArgumentParser(description='仅停止同工作区的轴类编程工作台')
p.add_argument('--port',type=int,default=8789);p.add_argument('--home',type=Path,default=ROOT/'target/shaft-workbench-data')
a=p.parse_args();url=f'http://127.0.0.1:{a.port}';b=probe(url)
if not b:raise SystemExit('没有检测到本端口的工作台服务。')
if b.get('workspace_key')!=identity(a.home.resolve()):raise SystemExit('端口属于其他服务或数据目录，不会停止。')
req=urllib.request.Request(url+'/api/stop',data=json.dumps({'workspace_key':b['workspace_key']}).encode(),
                           headers={'Content-Type':'application/json','X-Workbench-Token':b['csrf']})
with urllib.request.urlopen(req,timeout=3) as r:
    assert json.load(r)['stopping']
print('本工作台已停止。')
