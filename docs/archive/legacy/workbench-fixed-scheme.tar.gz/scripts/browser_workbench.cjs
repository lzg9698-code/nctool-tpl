// Actual browser acceptance. Own loopback process, separate data, no user assets.
const {chromium}=require(process.env.NCTOOL_PLAYWRIGHT||'playwright');
const {spawn}=require('node:child_process');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const out=path.join(root,'target/workbench-v1/browser');fs.mkdirSync(out,{recursive:true});
const home=fs.mkdtempSync(path.join(root,'target/workbench-browser-'));
const python=process.env.NCTOOL_PYTHON||'python';
const child=spawn(python,['-u','-m','workbench.server','--port','0','--home',home],{cwd:root,windowsHide:true});
const skipDownloads=process.argv.includes('--skip-downloads');
let browser;const errors=[];const steps=[];
function ready(){return new Promise((resolve,reject)=>{let log='';const t=setTimeout(()=>reject(new Error(log||'startup timeout')),20000);
 child.stdout.on('data',b=>{log+=b;const m=log.match(/http:\/\/127\.0\.0\.1:\d+/);if(m){clearTimeout(t);resolve(m[0]);}});
 child.stderr.on('data',b=>log+=b);child.on('exit',c=>{clearTimeout(t);reject(new Error('server exited '+c+' '+log));});});}
async function mark(name){steps.push(name);console.log('PASS',name);}
(async()=>{try{
 const url=await ready();browser=await chromium.launch({headless:true,executablePath:process.env.NCTOOL_CHROMIUM||undefined});
 const context=await browser.newContext({viewport:{width:1440,height:1100},acceptDownloads:true});const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await page.goto(url);await page.getByText('计算已更新',{exact:true}).waitFor({timeout:30000});
 await page.screenshot({path:path.join(out,'01-workbench.png'),fullPage:true});
 assert.equal(await page.locator('.target-value').getByText('Φ100.535',{exact:true}).count(),1);await mark('seed targets and state canvas');
 await page.getByRole('button',{name:'阶段：键槽精铣',exact:true}).click();
 await page.getByRole('img',{name:'键槽 A局部平面刀路',exact:true}).waitFor();
 await page.screenshot({path:path.join(out,'04-keyway-plan.png'),fullPage:true});
 const point=page.locator('.key-canvas path[role="button"]').nth(3);await point.focus();await page.keyboard.press('Enter');
 assert((await page.locator('.code-caption').innerText()).includes('UZ_FKM_1.spf'));assert(await page.locator('.code-line.focus').count());await mark('keyway arc connects to its actual program line');
 await page.getByRole('tab',{name:'程序',exact:true}).click();await page.getByRole('button',{name:'1_0.MPF',exact:true}).click();assert((await page.locator('.code-lines').innerText()).includes('G1 X100.535'));await mark('stage and program viewing');
 await page.getByRole('tab',{name:'加工视图',exact:true}).click();
 await page.getByLabel('名义直径 · 长轴段',{exact:true}).fill('');await page.getByRole('alert').waitFor();
 await page.getByLabel('名义直径 · 长轴段',{exact:true}).fill('105');await page.getByText('Φ105.535',{exact:true}).waitFor();await mark('clear and retype nominal diameter preserves deviations');
 await page.getByLabel('长轴段',{exact:true}).fill('220');await page.getByText('计算已更新',{exact:true}).waitFor();
 await page.getByRole('button',{name:'生成程序',exact:true}).click();await page.getByRole('button',{name:'下载候选包',exact:true}).waitFor();
 await page.waitForFunction(()=>!document.querySelector('.export-button').disabled);
 assert((await page.locator('.code-lines').innerText()).includes('G1 X105.535'));await mark('diameter and length propagate to emitted code');
 if(!skipDownloads){
 const [zip,zipResponse]=await Promise.all([page.waitForEvent('download'),page.waitForResponse(r=>r.url().includes('/api/export/')),page.getByRole('button',{name:'下载候选包',exact:true}).click()]);
 const zipBody=await zipResponse.body();await zip.saveAs(path.join(out,'modified-candidate.zip'));
 const downloaded=fs.readFileSync(path.join(out,'modified-candidate.zip'));
 assert.equal(await zip.failure(),null);assert.equal(downloaded.length,zipBody.length,JSON.stringify({url:zip.url(),name:zip.suggestedFilename(),http:zipResponse.status(),bytes:zipBody.length,downloaded:downloaded.length}));
 assert.equal(downloaded.subarray(0,2).toString(),'PK',JSON.stringify({status:zipResponse.status(),headers:zipResponse.headers(),method:zipResponse.request().method(),url:zipResponse.url()}));await mark('complete candidate ZIP download');
 }
 await page.getByRole('button',{name:'保存',exact:true}).click();await page.getByText('零件已保存',{exact:true}).waitFor();
 await page.reload();await page.getByText('计算已更新',{exact:true}).waitFor();assert.equal(await page.getByLabel('名义直径 · 长轴段',{exact:true}).inputValue(),'105');assert.equal(await page.getByLabel('长轴段',{exact:true}).inputValue(),'220');await mark('save and draft reload');
 await page.getByRole('button',{name:'键槽',exact:true}).click();await page.getByRole('button',{name:'添加',exact:true}).click();await page.getByText('计算已更新',{exact:true}).waitFor();
 await page.getByRole('button',{name:'生成程序',exact:true}).click();await page.waitForFunction(()=>!document.querySelector('.export-button').disabled);assert(await page.getByRole('button',{name:'UZ_FKM_3.spf',exact:true}).count());await mark('third key adds matching calls and files');
 await page.getByRole('button',{name:'UZ_FKM_3.spf',exact:true}).click();assert((await page.locator('.code-lines').innerText()).includes('G3'));await page.screenshot({path:path.join(out,'02-third-key-program.png'),fullPage:true});
 await page.getByLabel('键槽 A · 长度',{exact:true}).fill('1000');await page.getByRole('alert').waitFor();assert(await page.getByRole('button',{name:'下载候选包',exact:true}).isDisabled());assert(await page.getByRole('button',{name:'生成程序',exact:true}).isDisabled());await mark('invalid geometry clears output and blocks export');
 await page.getByLabel('键槽 A · 长度',{exact:true}).fill('196.25');await page.getByText('计算已更新',{exact:true}).waitFor();assert(await page.getByRole('button',{name:'下载候选包',exact:true}).isDisabled());await mark('changed inputs cannot download old run');
 await page.getByRole('button',{name:'工艺',exact:true}).click();await page.getByRole('checkbox',{name:'执行两端面测量',exact:true}).uncheck();await page.getByText('计算已更新',{exact:true}).waitFor();
 await page.getByRole('button',{name:'生成程序',exact:true}).click();await page.waitForFunction(()=>!document.querySelector('.export-button').disabled);await page.getByRole('button',{name:'1_0.MPF',exact:true}).click();assert((await page.locator('.code-lines').innerText()).includes('PROBE disabled'));await mark('measurement off is explicit in output');
 const parameterPath=path.join(out,'roundtrip-part.json');
 if(!skipDownloads){
 const [params]=await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:'参数',exact:true}).click()]);await params.saveAs(parameterPath);
 }else{
 const boot=await (await context.request.get(url+'/api/bootstrap')).json();
 const record=await (await context.request.get(url+'/api/runs/'+boot.runs[0].id)).json();
 fs.writeFileSync(parameterPath,JSON.stringify(record.result.part));
 }
 const parameterData=JSON.parse(fs.readFileSync(parameterPath,'utf8'));parameterData.code='IMPORTED-SHAFT';fs.writeFileSync(parameterPath,JSON.stringify(parameterData));
 await page.locator('input[type="file"]').setInputFiles(parameterPath);await page.getByText('零件参数已导入',{exact:true}).waitFor();await page.getByText('计算已更新',{exact:true}).waitFor();assert((await page.locator('.breadcrumb').innerText()).includes('IMPORTED-SHAFT'));await mark(skipDownloads?'validated JSON parameter import':'JSON parameter export and validated import');
 await page.getByRole('button',{name:/生成记录/}).click();await page.locator('.history-item').first().click();await page.getByText('已载入旧记录的输入，重新生成后可导出',{exact:true}).waitFor();await page.getByText('计算已更新',{exact:true}).waitFor();assert(await page.getByRole('button',{name:'下载候选包',exact:true}).isDisabled());await mark('history restores inputs without inheriting export state');
 await page.getByRole('button',{name:'复制',exact:true}).click();await page.getByText('已复制尺寸和工艺；生成与验收记录不继承',{exact:true}).waitFor();await page.getByText('计算已更新',{exact:true}).waitFor();assert((await page.locator('.breadcrumb').innerText()).includes('COPY'));assert(await page.getByRole('button',{name:'下载候选包',exact:true}).isDisabled());await mark('copy creates a new draft without run identity');
 await page.getByRole('button',{name:'保存',exact:true}).click();await page.getByText('零件已保存',{exact:true}).waitFor();
 await page.getByRole('button',{name:/样例工艺库/}).click();assert.equal(await page.locator('.catalog-grid button').count(),11);await page.getByRole('button',{name:/14595443/}).click();assert((await page.locator('.reference-detail').innerText()).includes('R14=5.15'));await page.getByRole('button',{name:'关闭对话框',exact:true}).click();await mark('11 sample references remain scoped');
 await page.getByRole('tab',{name:/检查/}).click();await page.screenshot({path:path.join(out,'03-checks.png'),fullPage:true});
 const b=await context.request.get(url+'/api/bootstrap');const boot=await b.json();const record=boot.projects[0];
 const saved=await (await context.request.get(url+'/api/projects/'+record.id)).json();saved.record.part.title+=' remote';
 const response=await context.request.post(url+'/api/save',{headers:{'X-Workbench-Token':boot.csrf},data:{part:saved.record.part,id:record.id,etag:saved.etag}});assert.equal(response.status(),200);
 await page.getByRole('button',{name:'保存',exact:true}).click();await page.getByRole('alert').waitFor();assert((await page.getByRole('alert').innerText()).includes('其他窗口修改'));await mark('stale save conflict is surfaced');
 page.on('dialog',d=>d.accept());
 await page.getByTitle('重新打开当前零件',{exact:true}).click();await page.getByText(/已打开 14594226-COPY/).waitFor();
 await page.getByText('计算已更新',{exact:true}).waitFor();await page.getByRole('button',{name:'尺寸',exact:true}).click();
 assert((await page.getByLabel('名称',{exact:true}).inputValue()).endsWith(' remote'));await mark('reopen reloads the saved project after a conflict');
 await page.getByRole('button',{name:'新建零件',exact:true}).click();await page.getByText('新零件采用同型输出轴方案',{exact:true}).waitFor();
 await page.getByText('计算已更新',{exact:true}).waitFor();assert((await page.locator('.breadcrumb').innerText()).includes('NEW-SHAFT'));
 assert.equal(await page.getByLabel('名义直径 · 长轴段',{exact:true}).inputValue(),'100');
 await page.getByRole('button',{name:'生成程序',exact:true}).click();await page.waitForFunction(()=>!document.querySelector('.export-button').disabled);
 assert.equal(await page.locator('.file-list button').count(),12);await mark('new part resets defaults and generates the complete 12-file plan');
 await page.getByRole('button',{name:'参考图纸',exact:true}).click();
 await page.waitForFunction(()=>{const i=document.querySelector('.modal img');return i&&i.complete&&i.naturalWidth>0;});
 await page.getByRole('button',{name:'关闭对话框',exact:true}).click();await mark('reference drawing is available in the actual UI');
 assert.deepEqual(errors,[]);await mark('no uncaught browser errors');
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({passed:steps,errors,url,home,skipDownloads,created:new Date().toISOString(),source:require('node:crypto').createHash('sha256').update(fs.readFileSync(path.join(root,'ui/src/workbench/main.tsx'))).digest('hex')},null,2));
 }catch(e){fs.writeFileSync(path.join(out,'failure.txt'),String(e.stack||e));throw e;}finally{if(browser)await browser.close();child.kill();}
})().catch(e=>{console.error(e);process.exitCode=1;});
