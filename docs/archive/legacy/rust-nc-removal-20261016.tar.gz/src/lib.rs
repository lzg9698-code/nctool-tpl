//! # nctool-tpl —— 通用 Jinja 模板引擎
//!
//! 基于 [minijinja]（Jinja2 的 Rust 实现，近乎零依赖、渲染最快）提供四个核心能力：
//!
//! 1. [`parse`]：语法检查 + 生成 AST（带行列定位）
//! 2. [`extract_variables`]：提取模板中**引用过**的所有变量名（含模板内部声明的）
//! 3. [`extract_undeclared`]：提取模板中引用、但**未在模板内部声明**的变量
//!    （即运行时要由外部上下文提供的参数），并区分**可选 / 必选**（见 [`Variable::optional`]）
//!    —— 对标 Python `jinja2.meta.find_undeclared_variables`
//! 4. [`Renderer`]：用上下文渲染出任意文本；领域扩展由调用方显式注册
//!
//! # 示例
//!
//! ```
//! use nctool_tpl::{parse, extract_undeclared, Variable};
//!
//! let source = r#"{% set feed = 0.15 %}G1 X{{ diameter / 2 }} F{{ feed }}"#;
//! let ast = parse(source, "demo.j2").unwrap();
//!
//! let undeclared: Vec<Variable> = extract_undeclared(&ast);
//! assert_eq!(undeclared.len(), 1);
//! assert_eq!(undeclared[0].name, "diameter");
//! assert!(!undeclared[0].optional); // 必选
//! ```
//!
//! # 稳定性
//!
//! 公共 API 为 [`parse`] / [`extract_variables`] / [`extract_undeclared`] /
//! [`Renderer`] / [`Variable`] / [`TplError`] / [`Ast`]。[`Ast`] 内部字段已私有化
//! （通过方法访问），[`TplError`] 标注 `#[non_exhaustive]`，以便未来扩展而不破坏
//! 下游。2.0 公共接口不注册任何领域过滤器。

#![warn(missing_docs)]

mod error;
mod extract;
mod renderer;

// 公共 API 再导出
pub use error::TplError;
pub use extract::{
    extract_member_accesses, extract_template_refs, extract_undeclared, extract_variables, parse,
    Ast, Variable,
};
pub use renderer::Renderer;

/// Callback traits for opt-in renderer extensions.
pub use minijinja::functions::Function;
/// Filter callback argument and return traits.
pub use minijinja::value::{FunctionArgs, FunctionResult};
/// 渲染上下文值类型（`minijinja::Value` 的**再导出**）。
///
/// 下游（如 `nctool-core`）应统一从这里引用，**而不是**在自己的 `Cargo.toml`
/// 里再声明一份 `minijinja` 依赖。原因：渲染上下文是本库公共签名的一部分
/// （见 [`Renderer::render`]），一旦下游解析到不同的 minijinja 版本，
/// 两边的 `Value` 就是**两个不同的类型**，拼不到一起。
///
/// 由本 crate 单点持有依赖并再导出，可保证整个 workspace 里只有一个
/// `minijinja::Value`，把"版本漂移导致类型不匹配"从可能变成不可能。
pub use minijinja::{Error as EngineError, ErrorKind as EngineErrorKind, Value};

/// [`Value`] 的类别标签（[`Value::kind`] 的返回类型）。
///
/// 与 [`Value`] 一并再导出：下游拿到 `Value` 后要判断"是数值还是容器"时，
/// 需要的正是这个类型；不导出就只能靠 `try_iter()` 试探，既低效又易错。
pub use minijinja::value::ValueKind;

#[cfg(test)]
use error::{extract_identifier_at, extract_quoted, extract_undefined_var_name};

#[cfg(test)]
mod tests {
    use super::*;

    fn names(vars: &[Variable]) -> Vec<String> {
        vars.iter().map(|v| v.name.clone()).collect()
    }

    /// 提取器返回值必须满足的不变量（A8：弱断言补强）。
    ///
    /// 在任意模板（包括 fuzz 生成的乱码）上都必须成立；把 fuzz 测试从
    /// «不 panic» 提升到 «不 panic **且**产出仍自洽»。
    fn assert_extract_invariants(src: &str, all: &[Variable], undeclared: &[Variable]) {
        let mut seen = std::collections::HashSet::new();
        for v in all {
            assert!(!v.name.is_empty(), "变量名不应为空，输入 {src:?}");
            assert!(
                seen.insert(v.name.as_str()),
                "`extract_variables` 应按名字去重，出现重复: {v:?}"
            );
            assert!(
                v.line >= 1 && v.col >= 1,
                "行列应 1 起: {v:?}，输入 {src:?}"
            );
            assert!(v.start <= v.end, "span 应有序: {v:?}，输入 {src:?}");
        }
        let all_names: std::collections::HashSet<&str> =
            all.iter().map(|v| v.name.as_str()).collect();
        let mut seen_u = std::collections::HashSet::new();
        for v in undeclared {
            assert!(
                all_names.contains(v.name.as_str()),
                "未声明项必须是全集的子集: {v:?}，输入 {src:?}"
            );
            assert!(
                seen_u.insert(v.name.as_str()),
                "`extract_undeclared` 也应按名字去重: {v:?}"
            );
        }
    }

    #[test]
    fn extract_basic() {
        let src = r#"{% set feed = 0.15 %}
O1000 ({{ program_name }})
G0 X{{ start_x }} Z{{ start_z }}
G1 X{{ diameter / 2 }} F{{ feed * 1.2 | round(2) }}
{% for hole in holes %}
  G81 X{{ hole.x }} Y{{ hole.y }}
{% endfor %}"#;
        let ast = parse(src, "demo.j2").unwrap();

        // 引用过的所有变量（feed/hole 是模板内部声明的，但仍被引用）
        let all = names(&extract_variables(&ast));
        assert!(all.contains(&"program_name".to_string()));
        assert!(all.contains(&"start_x".to_string()));
        assert!(all.contains(&"diameter".to_string()));
        assert!(all.contains(&"holes".to_string()));
        assert!(all.contains(&"feed".to_string()));
        assert!(all.contains(&"hole".to_string()));
        assert!(!all.contains(&"loop".to_string()));

        // 未声明变量 = 需外部提供的参数；feed/hole/loop 都不应出现
        let undeclared = names(&extract_undeclared(&ast));
        assert_eq!(
            undeclared,
            vec!["program_name", "start_x", "start_z", "diameter", "holes"]
        );
    }

    #[test]
    fn extract_dedup_and_order() {
        let src = "{{ a }} {{ b }} {{ a }} {{ c }}";
        let ast = parse(src, "t.j2").unwrap();
        let all = names(&extract_variables(&ast));
        assert_eq!(all, vec!["a", "b", "c"]);
    }

    #[test]
    fn extract_with_local_and_macro() {
        let src = r#"{% macro round2(x) %}{{ x * 2 }}{% endmacro %}
{{ round2(value) }}
{% set ns = namespace(foo=1) %}
{% with y = ns.foo %}{{ y }}{% endwith %}"#;
        let ast = parse(src, "t.j2").unwrap();
        let undeclared = names(&extract_undeclared(&ast));
        // 只需外部提供 value；x 是宏参数、round2 是宏名、ns/y 是 set/with 局部，
        // namespace 是内置全局、foo 是 kwarg 名字/属性名（非变量引用）
        assert_eq!(undeclared, vec!["value".to_string()]);
    }

    #[test]
    fn parse_syntax_error_line() {
        let src = "G0 X10\n{{ name \nG1 Z5";
        let err = parse(src, "bad.j2").unwrap_err();
        match err {
            TplError::Parse { line, .. } => assert!(line >= 2),
            _ => panic!("expected parse error"),
        }
    }

    #[test]
    fn parse_error_column_is_located() {
        // 未闭合括号：minijinja 报 `unexpected }`，列号应精确指向 `}`（非恒 1）
        let src = "{{ (1 + 2 }}";
        let err = parse(src, "bad.j2").unwrap_err();
        match err {
            TplError::Parse { line, col, .. } => {
                assert_eq!(line, 1);
                assert_eq!(col, 11, "应定位到 }} 所在列，实际 col={col}");
            }
            _ => panic!("expected parse error"),
        }
    }

    #[test]
    fn parse_error_column_on_multiline() {
        // 多行模板：行列均来自字节偏移换算，不应退化到 col=1
        let src = "G0 X0\nG1 Z5\n  {{ x | }}\n";
        let err = parse(src, "bad.j2").unwrap_err();
        match err {
            TplError::Parse { line, col, .. } => {
                assert_eq!(line, 3);
                assert!(col >= 6, "错误应在第 3 行 `{{ x | }}` 附近，实际 col={col}");
            }
            _ => panic!("expected parse error"),
        }
    }

    #[test]
    fn extract_undeclared_required_by_default() {
        let src = "G1 X{{ diameter }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "diameter");
        assert!(!v[0].optional, "无兜底引用的变量应为必选");
    }

    #[test]
    fn extract_undeclared_default_chain_optional() {
        // 直接 default 过滤器：变量缺失时由默认值兜底 → 可选
        let src = "G1 F{{ feed | default(0.15) }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "feed");
        assert!(v[0].optional, "default 兜底的变量应为可选");

        // 别名 d 同样生效
        let src = "G1 F{{ feed | d(0.15) }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v[0].name, "feed");
        assert!(v[0].optional, "d 别名也应视为兜底");
    }

    #[test]
    fn extract_undeclared_set_with_default_optional() {
        // README 示例：default_feed 有 default 兜底 → 可选；feed 为模板局部
        let src = "{% set feed = default_feed | default(0.15) %}G1 F{{ feed }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "default_feed");
        assert!(v[0].optional, "default_feed 应有 default 兜底 → 可选");
    }

    #[test]
    fn extract_undeclared_set_self_default_stays_optional() {
        // 「自赋值兜底」惯用法：`{% set x = x | default(v) %}`
        // x 的 RHS 引用是兜底引用 → 应判可选；后续 `{{ x }}` 引用的是
        // set 出来的局部量，不能再把 x 翻回必选。
        let src = "{% set R1 = R1 | default(4000) %}S1={{ R1 }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1, "只应识别出 R1：{v:?}");
        assert_eq!(v[0].name, "R1");
        assert!(v[0].optional, "自赋值兜底的变量应保持可选");
    }

    #[test]
    fn extract_undeclared_set_self_assign_without_default_is_required() {
        // 对照：没有 default 兜底时，`{% set x = x + 1 %}` 的 RHS 引用仍为必选
        let src = "{% set R1 = R1 + 1 %}S1={{ R1 }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1, "只应识别出 R1：{v:?}");
        assert!(!v[0].optional, "无兜底的 RHS 引用应为必选");
    }

    #[test]
    fn extract_undeclared_mixed_reference_is_required() {
        // 同一变量既出现在兜底上下文、又出现在必选上下文 → 整体视为必选
        let src = "G1 F{{ feed | default(0.15) }} X{{ feed }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "feed");
        assert!(!v[0].optional, "存在非兜底引用时仍应视为必选");
    }

    #[test]
    fn extract_undeclared_defined_test_optional() {
        // defined 测试：被检查变量缺失时模板仍可安全执行 → 可选
        let src = "{% if radius is defined %}{{ 'ok' }}{% else %}{{ 'missing' }}{% endif %}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "radius");
        assert!(v[0].optional, "defined 测试保护的变量应为可选");
    }

    #[test]
    fn extract_undeclared_default_does_not_protect_arithmetic() {
        // 回归：default 兜底**不**向下传播到操作数子树。
        // minijinja 先求值 (a + b) 再套 default —— undefined 参与加法即报错，
        // default 救不了。若误判为可选，上层校验会放行、严格模式渲染却失败，
        // 产出不完整 G-code（本领域最坏的失败模式）。
        let src = "G1 X{{ (a + b) | default(1) }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 2, "a、b 都应被提取");
        for var in &v {
            assert!(
                !var.optional,
                "{} 参与运算，default 无法兜底，应为必选",
                var.name
            );
        }
    }

    #[test]
    fn extract_undeclared_default_does_not_protect_attribute_chain() {
        // 回归：{{ a.b | default(1) }} 会先对 undefined 的 a 取属性并报错，
        // 故根变量 a 必选——不能因外层 default 判为可选。
        let src = "G1 X{{ a.b | default(1) }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "a");
        assert!(!v[0].optional, "属性链的根变量应为必选");
    }

    #[test]
    fn extract_undeclared_defined_does_not_protect_attribute_chain() {
        // 回归：与 default 同理，{% if a.b is defined %} 中的 a 必选。
        let src = "{% if a.b is defined %}G1{% endif %}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "a");
        assert!(!v[0].optional, "属性链的根变量应为必选");
    }

    #[test]
    fn extract_undeclared_optional_survives_filter_chain() {
        // 裸变量经 default 兜底后，再串接其他过滤器仍应判可选：
        // x 缺失 → default 补 1 → nc_fixed 求值，全程不报错。
        // 防止「只认直接操作数」的修复误伤过滤器链场景。
        let src = "G1 X{{ x | default(1) | nc_fixed(3) }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1);
        assert_eq!(v[0].name, "x");
        assert!(v[0].optional, "过滤器链不应破坏 default 兜底");
    }

    #[test]
    fn extract_debug_global_is_not_undeclared() {
        // 回归：debug 是 minijinja 启用 debug feature 后注入的内置全局，
        // 不应被当作需要外部提供的参数。
        let src = "{{ debug() }}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert!(v.is_empty(), "debug 为内置全局，不应进入未声明集合: {v:?}");
    }

    #[test]
    fn extract_with_block_binds_progressively() {
        // 回归：minijinja 的 {% with %} 按「求值右值 → 绑定目标」逐条交错执行，
        // 故 {% with a=1, b=a+1 %} 中 b 的初值看到的是本块绑定的 a，而非外部变量。
        // 提取器若先求值全部右值再统一绑定，会把 a 误报为必选（渲染其实正常）。
        let src = "{% with a=1, b=a+1 %}{{ b }}{% endwith %}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert!(
            v.is_empty(),
            "a 已由 with 块绑定，不应进入未声明集合: {v:?}"
        );
    }

    #[test]
    fn extract_with_block_rhs_sees_outer_binding() {
        // 反向回归：右值在目标绑定**前**求值，故 {% with y = y + 1 %} 的 y 仍必选。
        // 防止「逐条交错」的修复把自引用场景误判为模板局部（漏报）。
        let src = "{% with y = y + 1 %}{{ y }}{% endwith %}";
        let ast = parse(src, "t.j2").unwrap();
        let v = extract_undeclared(&ast);
        assert_eq!(v.len(), 1, "自引用右值中的 y 应记为必选: {v:?}");
        assert_eq!(v[0].name, "y");
        assert!(!v[0].optional);
    }

    #[test]
    fn extract_variables_carries_optional() {
        // extract_variables 同样携带 optional（表示该变量所有引用是否均在兜底上下文）
        let src = "{{ a }}{{ b | default(1) }}";
        let ast = parse(src, "t.j2").unwrap();
        let all = extract_variables(&ast);
        let a = all.iter().find(|v| v.name == "a").unwrap();
        let b = all.iter().find(|v| v.name == "b").unwrap();
        assert!(!a.optional);
        assert!(b.optional);
    }

    // -----------------------------------------------------------------------
    // 多模板渲染（include / extends / import）
    // -----------------------------------------------------------------------

    #[test]
    fn render_template_include() {
        let mut r = Renderer::new();
        r.add_template("sub.j2", "X{{ x }}").unwrap();
        r.add_template("main.j2", "G0 {% include \"sub.j2\" %} Z{{ z }}")
            .unwrap();
        let ctx = minijinja::context! { x => 1.0, z => 2.0 };
        let out = r.render_template("main.j2", &ctx).unwrap();
        assert_eq!(out, "G0 X1.0 Z2.0");
    }

    #[test]
    fn render_template_extends() {
        let mut r = Renderer::new();
        r.add_template(
            "base.j2",
            "HEAD {% block content %}default{% endblock %} TAIL",
        )
        .unwrap();
        r.add_template(
            "child.j2",
            "{% extends \"base.j2\" %}{% block content %}GCODE{% endblock %}",
        )
        .unwrap();
        let ctx = minijinja::context! {};
        let out = r.render_template("child.j2", &ctx).unwrap();
        assert_eq!(out, "HEAD GCODE TAIL");
    }

    #[test]
    fn render_template_import_macro() {
        let mut r = Renderer::new();
        r.add_template("macros.j2", "{% macro greet(n) %}Hi {{ n }}{% endmacro %}")
            .unwrap();
        r.add_template(
            "main.j2",
            "{% from \"macros.j2\" import greet %}{{ greet(\"world\") }}",
        )
        .unwrap();
        let ctx = minijinja::context! {};
        let out = r.render_template("main.j2", &ctx).unwrap();
        assert_eq!(out, "Hi world");
    }

    #[test]
    fn from_import_alias_binds_alias_not_original() {
        // {% from "m" import helper as h %}：绑定的是别名 h（对齐 minijinja 语义），
        // helper 与 h 都不应记为未声明变量
        let src = r#"{% from "macros.j2" import helper as h %}{{ h() }}"#;
        let vars = extract_undeclared(&parse(src, "alias.j2").unwrap());
        assert!(
            vars.iter().all(|v| v.name != "h" && v.name != "helper"),
            "导入绑定不应记为未声明: {vars:?}"
        );
        // 渲染端对齐：别名可调用（严格模式不报 undefined）
        let mut r = Renderer::new();
        r.add_template("macros.j2", "{% macro helper() %}H{% endmacro %}")
            .unwrap();
        let out = r.render(src, "alias.j2", &minijinja::context! {}).unwrap();
        assert_eq!(out, "H");
    }

    #[test]
    fn set_inside_block_does_not_leak() {
        // block 体是独立作用域（对齐 minijinja VM 的帧语义）：
        // 块内 set 的名字块外不可见，块外引用按未声明处理
        let src = "{% block prep %}{% set feed = 0.1 %}{% endblock %}G1 F{{ feed }}";
        let vars = extract_undeclared(&parse(src, "blk.j2").unwrap());
        assert!(
            vars.iter().any(|v| v.name == "feed" && !v.optional),
            "块内 set 不应消除块外引用的未声明性: {vars:?}"
        );
        // 渲染端对齐：严格模式报未定义；宽松模式留空（G1 F，而非 G1 F0.1）
        let mut strict = Renderer::new();
        strict.add_template("blk.j2", src).unwrap();
        assert!(matches!(
            strict.render_template("blk.j2", &minijinja::context! {}),
            Err(TplError::UndefinedVariable { .. })
        ));
        let mut lenient = Renderer::new().with_lenient();
        lenient.add_template("blk.j2", src).unwrap();
        let out = lenient
            .render_template("blk.j2", &minijinja::context! {})
            .unwrap();
        assert_eq!(out, "G1 F");
    }

    #[test]
    fn undefined_var_in_included_template_not_recovered_from_main_source() {
        // extends 的父模板块内未定义变量：错误可能未包装直接冒泡（携带父模板
        // 名与字节范围），此时不能用主（子）模板源码恢复变量名（范围错位会
        // 得到无关标识符，宁缺毋错）
        let mut r = Renderer::new();
        r.add_template("base.j2", "{% block c %}{{ missing }}{% endblock %}")
            .unwrap();
        r.add_template("child.j2", "{% extends \"base.j2\" %}")
            .unwrap();
        let err = r
            .render_template("child.j2", &minijinja::context! {})
            .unwrap_err();
        match err {
            TplError::UndefinedVariable { name, variable, .. } => {
                assert_eq!(name, "base.j2");
                assert_eq!(variable, "", "不应从子模板源码错误恢复变量名");
            }
            TplError::Render { .. } => {
                // minijinja 将子模板错误包为 BadInclude/EvalBlock 时，顶层即
                // Render 变体、不触发变量名恢复——同样符合"不错位恢复"
            }
            other => panic!("应为 UndefinedVariable/Render: {other:?}"),
        }
        // include 路径：子模板错误被包为 BadInclude，消息可定位子模板名
        let mut r2 = Renderer::new();
        r2.add_template("sub.j2", "{{ missing }}").unwrap();
        r2.add_template("main.j2", "{% include \"sub.j2\" %}")
            .unwrap();
        let err = r2
            .render_template("main.j2", &minijinja::context! {})
            .unwrap_err();
        match err {
            TplError::Render { name, message } => {
                assert_eq!(name, "main.j2");
                assert!(message.contains("sub.j2"), "消息应可定位子模板: {message}");
                // 外层 BadInclude 包装自身不含原因，必须把根因补回消息，
                // 否则用户只看到"某个 include 挂了"而不知为何
                assert!(
                    message.contains(" ← "),
                    "消息应带嵌套根因（` ← ` 分隔）: {message}"
                );
            }
            other => panic!("应为 Render（BadInclude 包装）: {other:?}"),
        }
    }

    #[test]
    fn opaque_render_error_reports_offending_expression() {
        // 回归：minijinja 对"对字符串取负"这类错误不设 detail，消息退化成
        // `invalid operation (in neg.j2:1)`——既不知错在哪句也不知错的是什么。
        // 此时 range() 仍精确指向出错表达式，据此补出可操作提示。
        let mut r = Renderer::new();
        r.add_template("neg.j2", "{% set v = -U_A %}{{ v | default(0) }}\n")
            .unwrap();
        let err = r
            .render_template("neg.j2", &minijinja::context! { U_A => "abc" })
            .unwrap_err();
        let message = err.to_string();
        assert!(message.contains("出错表达式"), "{message}");
        assert!(message.contains("-U_A"), "应给出出错表达式片段: {message}");
    }

    #[test]
    fn detailed_error_does_not_add_snippet() {
        // 已有可读原因（detail 非空）时不补片段，避免消息冗余
        let mut r = Renderer::new();
        r.add_template("div.j2", "X{{ U_A / 2 }}\n").unwrap();
        let err = r
            .render_template("div.j2", &minijinja::context! { U_A => "abc" })
            .unwrap_err();
        let message = err.to_string();
        assert!(
            message.contains("tried to use / operator"),
            "原有可读原因应保留: {message}"
        );
        assert!(
            !message.contains("出错表达式"),
            "有可读原因时不应再补片段: {message}"
        );
    }

    #[test]
    fn parse_error_column_counts_chars_not_bytes() {
        // 列号按字符计（与 Variable.col 的 minijinja span 口径一致）：
        // 两个仅前缀字节构成不同、字符构成相同的模板，错误列应相同
        let a = parse("( xx ) {{ 1 + }}", "a.j2").unwrap_err();
        let b = parse("( 中文 ) {{ 1 + }}", "b.j2").unwrap_err();
        let (la, ca) = match a {
            TplError::Parse { line, col, .. } => (line, col),
            other => panic!("应为 Parse 错误: {other:?}"),
        };
        let (lb, cb) = match b {
            TplError::Parse { line, col, .. } => (line, col),
            other => panic!("应为 Parse 错误: {other:?}"),
        };
        assert_eq!(la, lb);
        assert!(ca > 1, "应携带字节范围（col 非回退值 1）");
        assert_eq!(
            ca, cb,
            "等字符数前缀（'( xx ) ' 与 '( 中文 ) '）后的同一语法错误，列号应按字符口径一致"
        );
    }

    #[test]
    fn extract_template_refs_static_names() {
        // 静态（字符串字面量）引用按出现顺序去重；动态引用（变量名）忽略
        let ast = parse(
            "{% include \"a.j2\" %}{% include \"a.j2\" %}{% include name %}",
            "r.j2",
        )
        .unwrap();
        assert_eq!(extract_template_refs(&ast), vec!["a.j2".to_string()]);

        // 嵌套语句体内与 import/from 同样收集
        let ast = parse(
            "{% for i in items %}{% include \"b.j2\" %}{% endfor %}",
            "r2.j2",
        )
        .unwrap();
        assert_eq!(extract_template_refs(&ast), vec!["b.j2".to_string()]);

        let ast = parse("{% from \"d.j2\" import x %}", "r3.j2").unwrap();
        assert_eq!(extract_template_refs(&ast), vec!["d.j2".to_string()]);
    }

    #[test]
    fn render_template_not_found_errors() {
        let r = Renderer::new();
        let ctx = minijinja::context! {};
        let err = r.render_template("missing.j2", &ctx).unwrap_err();
        match err {
            TplError::TemplateNotFound { name, .. } => {
                assert_eq!(name, "missing.j2");
            }
            _ => panic!("应为 TemplateNotFound 错误"),
        }
    }

    #[test]
    fn add_template_syntax_error() {
        let mut r = Renderer::new();
        let err = r.add_template("bad.j2", "{{ oops ").unwrap_err();
        match err {
            TplError::Parse { message, .. } => assert!(message.contains("syntax")),
            _ => panic!("应为 Parse 错误（注册时语法检查失败）"),
        }
    }

    #[test]
    fn render_single_string_still_works() {
        // 向后兼容：无模板注册时，render() 单字符串渲染不受影响
        let r = Renderer::new();
        let ctx = minijinja::context! { x => 42.0 };
        let out = r.render("X{{ x }}", "s.j2", &ctx).unwrap();
        assert_eq!(out, "X42.0");
    }

    #[test]
    fn add_template_same_name_replaces_silently() {
        // 同名注册静默替换（后者覆盖前者）
        let mut r = Renderer::new();
        r.add_template("dup.j2", "ONE").unwrap();
        r.add_template("dup.j2", "TWO {{ x }}").unwrap();
        let out = r
            .render_template("dup.j2", &minijinja::context! { x => 2 })
            .unwrap();
        assert_eq!(out, "TWO 2");
    }

    // -----------------------------------------------------------------------
    // 错误细分验证
    // -----------------------------------------------------------------------

    #[test]
    fn error_unknown_filter_is_subdivided() {
        let r = Renderer::new();
        let ctx = minijinja::context! { x => 1.0 };
        let err = r
            .render("{{ x | nonexistent_filter }}", "f.j2", &ctx)
            .unwrap_err();
        match err {
            TplError::UnknownFilter { filter, .. } => {
                assert_eq!(filter, "nonexistent_filter");
            }
            _ => panic!("应为 UnknownFilter，实际: {err:?}"),
        }
    }

    #[test]
    fn error_unknown_test_is_subdivided() {
        let r = Renderer::new();
        let ctx = minijinja::context! { x => 1.0 };
        let err = r
            .render("{% if x is nonexistent_test %}yes{% endif %}", "t.j2", &ctx)
            .unwrap_err();
        match err {
            TplError::UnknownTest { test, .. } => {
                assert_eq!(test, "nonexistent_test");
            }
            _ => panic!("应为 UnknownTest，实际: {err:?}"),
        }
    }

    #[test]
    fn error_undefined_variable_is_subdivided() {
        let r = Renderer::new();
        let ctx = minijinja::context! {};
        let err = r.render("{{ missing }}", "u.j2", &ctx).unwrap_err();
        match err {
            // 变量名从源码错误位置尽力恢复
            TplError::UndefinedVariable { variable, .. } => {
                assert_eq!(variable, "missing", "应恢复出变量名");
            }
            _ => panic!("应为 UndefinedVariable，实际: {err:?}"),
        }
    }

    #[test]
    fn undefined_variable_attr_chain_leaves_empty() {
        // 属性链缺失时无法确定缺失的是基础名还是属性 → variable 为空（宁缺毋错）
        let r = Renderer::new();
        let ctx = minijinja::context! { x => 42.0 };
        let err = r.render("{{ x.missing_attr }}", "a.j2", &ctx).unwrap_err();
        match err {
            TplError::UndefinedVariable { variable, .. } => {
                assert!(variable.is_empty(), "属性链场景不应给出误导性名字");
            }
            _ => panic!("应为 UndefinedVariable，实际: {err:?}"),
        }
    }

    #[test]
    fn undefined_variable_recovered_in_registered_template() {
        // render_template 路径（env 内模板）同样恢复变量名
        let mut r = Renderer::new();
        r.add_template("t.j2", "V={{ missing2 }}").unwrap();
        let ctx = minijinja::context! {};
        let err = r.render_template("t.j2", &ctx).unwrap_err();
        match err {
            TplError::UndefinedVariable { variable, .. } => assert_eq!(variable, "missing2"),
            _ => panic!("应为 UndefinedVariable，实际: {err:?}"),
        }
    }

    #[test]
    fn extract_identifier_and_var_name_work() {
        assert_eq!(
            extract_identifier_at("{{ missing }}", 3),
            Some("missing".to_string())
        );
        assert_eq!(
            extract_identifier_at("G1 X{{ m1 }}", 7),
            Some("m1".to_string())
        );
        assert_eq!(extract_identifier_at("(( x", 0), None);
        // 裸标识符 → 恢复；属性/下标链 → 宁缺毋错
        assert_eq!(
            extract_undefined_var_name("{{ missing }}", 3..10),
            Some("missing".to_string())
        );
        assert_eq!(
            extract_undefined_var_name("{{ x.missing_attr }}", 3..17),
            None
        );
        assert_eq!(extract_undefined_var_name("{{ table[key] }}", 3..13), None);
    }

    /// 回归（第四轮 P2-11）：**过滤器名不得被当成缺失变量名**。
    ///
    /// 实测：`{{ missing | upper }}` 的 `UndefinedError` span 只覆盖 `upper`
    /// （minijinja 把错误定位到过滤器上），于是消息报「未定义变量 'upper'」——
    /// 把用户指向一个过滤器名。同类形态还有 `{{ x | f | g }}` 与 `{% if x | f %}`。
    ///
    /// 两种**不属于**本缺陷、且必须保持原样的情形（实测确认）：
    /// - `{{ a + missing }}` / `{{ missing + 1 }}` 走 `InvalidOperation`，
    ///   归入 `TplError::Render`，本就不提取变量名；
    /// - `{{ missing ~ "x" }}` 的 span 覆盖整条表达式，但首个标识符确实是变量，
    ///   必须继续能恢复出 `missing` —— 所以不能用"标识符须覆盖整个 span"这种
    ///   更粗的判据去修，那会误伤它。
    #[test]
    fn filter_name_is_not_reported_as_undefined_variable() {
        let mut r = Renderer::new();
        for (src, name) in [
            ("{{ missing | upper }}", "f0.j2"),
            ("{{ missing | upper | lower }}", "f1.j2"),
            ("{% if missing | upper %}1{% endif %}", "f2.j2"),
        ] {
            r.add_template(name, src).unwrap();
            let err = r
                .render_template(name, &minijinja::context! {})
                .unwrap_err();
            match err {
                TplError::UndefinedVariable {
                    variable, message, ..
                } => assert!(
                    variable.is_empty(),
                    "过滤器名不是变量名，应留空而不是报 {variable:?}：{message}"
                ),
                other => panic!("{src} 应为 UndefinedVariable，实际: {other:?}"),
            }
        }

        // 反向：以下必须继续正确恢复，别把保护做成误伤
        assert_eq!(
            extract_undefined_var_name("{{ missing }}", 3..10),
            Some("missing".to_string())
        );
        assert_eq!(
            extract_undefined_var_name("{{ missing ~ \"x\" }}", 3..16),
            Some("missing".to_string()),
            "span 覆盖整条表达式时，首个标识符确实是变量，应继续恢复"
        );
        assert_eq!(
            extract_undefined_var_name("{{ x.attr | upper }}", 11..16),
            None,
            "紧跟在 `|` 之后的一律不采纳"
        );
    }

    #[test]
    fn error_display_includes_subdivision() {
        let err = TplError::UndefinedVariable {
            name: "t.j2".to_string(),
            variable: "x".to_string(),
            message: "variable 'x' is undefined".to_string(),
        };
        let display = format!("{err}");
        assert!(display.contains("未定义变量"));
        assert!(display.contains("'x'"));
        assert!(display.contains("t.j2"));
    }

    // -----------------------------------------------------------------------
    // 严格 / 宽松模式切换
    // -----------------------------------------------------------------------

    #[test]
    fn default_is_strict_mode() {
        let r = Renderer::new();
        assert!(!r.is_lenient(), "默认应为严格模式");
        let ctx = minijinja::context! {};
        let err = r.render("{{ missing }}", "s.j2", &ctx).unwrap_err();
        match err {
            TplError::UndefinedVariable { .. } => {}
            _ => panic!("严格模式下未定义变量应报错，实际: {err:?}"),
        }
    }

    #[test]
    fn with_lenient_renders_undefined_as_empty() {
        let r = Renderer::new().with_lenient();
        assert!(r.is_lenient());
        let ctx = minijinja::context! { x => 42 };
        let out = r.render("X{{ x }} {{ missing }}", "l.j2", &ctx).unwrap();
        assert_eq!(out, "X42 ", "宽松模式下未定义变量渲染为空字符串");
    }

    #[test]
    fn with_strict_switches_back_to_strict() {
        let r = Renderer::new().with_lenient().with_strict();
        assert!(!r.is_lenient());
        let ctx = minijinja::context! {};
        let err = r.render("{{ missing }}", "s2.j2", &ctx).unwrap_err();
        match err {
            TplError::UndefinedVariable { .. } => {}
            _ => panic!("切回严格模式后未定义变量应报错"),
        }
    }

    #[test]
    fn lenient_mode_still_extracts_required_variables() {
        // 宽松模式只影响渲染行为，不影响 extract_undeclared 的必选判定
        let _r = Renderer::new().with_lenient();
        let ast = parse("X{{ x }} Y{{ y | default(1) }}", "e.j2").unwrap();
        let vars = extract_undeclared(&ast);
        let names: Vec<&str> = vars.iter().map(|v| v.name.as_str()).collect();
        assert!(names.contains(&"x"), "无 default 的 x 应仍为必选");
        let x = vars.iter().find(|v| v.name == "x").unwrap();
        assert!(!x.optional, "宽松模式不影响 optional 判定");
    }

    #[test]
    fn extract_quoted_works() {
        assert_eq!(
            extract_quoted("unknown filter 'foo'"),
            Some("foo".to_string())
        );
        assert_eq!(
            extract_quoted("variable \"x\" is undefined"),
            Some("x".to_string())
        );
        assert_eq!(extract_quoted("no quotes here"), None);
    }

    // -----------------------------------------------------------------------
    // 边界 case：空模板 / 纯文本 / 注释 / 保留名
    // -----------------------------------------------------------------------

    #[test]
    fn empty_template_parses_and_has_no_vars() {
        let ast = parse("", "empty.j2").unwrap();
        assert!(extract_variables(&ast).is_empty());
        assert!(extract_undeclared(&ast).is_empty());
    }

    #[test]
    fn pure_text_has_no_vars() {
        let ast = parse("G1 X10 Y20\nM3 S1000", "text.j2").unwrap();
        assert!(extract_variables(&ast).is_empty());
        assert!(extract_undeclared(&ast).is_empty());
    }

    #[test]
    fn comments_do_not_produce_vars() {
        let src = "{# this is a comment with x y z #}G1 X{{ actual }}";
        let ast = parse(src, "comment.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["actual"]);
    }

    #[test]
    fn reserved_names_not_undeclared() {
        // loop / self / super / caller 是引擎内置，不算未声明
        let src = "{% for item in items %}{{ loop.index }} {{ self }} {{ super }} {{ caller }}{% endfor %}";
        let ast = parse(src, "reserved.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["items"]);
    }

    // -----------------------------------------------------------------------
    // 边界 case：作用域（for / macro / set）
    // -----------------------------------------------------------------------

    #[test]
    fn for_loop_var_not_undeclared() {
        let src = "{% for x in xs %}{{ x }}{% endfor %}";
        let ast = parse(src, "for.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["xs"]);
    }

    #[test]
    fn macro_params_not_undeclared() {
        let src = "{% macro greet(name, greeting) %}{{ greeting }} {{ name }}{% endmacro %}{{ greet(\"world\", \"Hi\") }}";
        let ast = parse(src, "macro.j2").unwrap();
        // 宏参数 name/greeting 不算未声明；greet 是宏调用也不算
        assert!(extract_undeclared(&ast).is_empty());
    }

    #[test]
    fn set_declared_var_not_undeclared() {
        let src = "{% set x = 1 %}{% set y = x + 2 %}{{ x }} {{ y }} {{ z }}";
        let ast = parse(src, "set.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["z"]);
    }

    // -----------------------------------------------------------------------
    // 作用域语义：set/with/for/macro 的作用域正确性
    // -----------------------------------------------------------------------

    #[test]
    fn self_referential_set_reports_undeclared() {
        // {% set total = total + price %}：右侧 total 引用外层（上下文）值，
        // 必须出现在未声明集合中，否则校验漏报、严格渲染才报错
        let src = "{% set total = total + price %}T{{ total }}";
        let ast = parse(src, "selfset.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["total", "price"]);
        assert!(
            undeclared.iter().all(|v| !v.optional),
            "自引用 set 引用的变量应为必选"
        );
    }

    #[test]
    fn set_inside_for_does_not_leak() {
        // for 是独立作用域（Jinja2 语义）：循环内 set 的名字在循环外不可见，
        // 循环后引用 hx 应视为未声明（渲染时缺失会报错）
        let src = "{% for h in holes %}{% set hx = h.x %}{{ hx }}{% endfor %}{{ hx }}";
        let ast = parse(src, "leak.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["holes", "hx"]);
    }

    #[test]
    fn for_var_not_visible_after_loop() {
        let src = "{% for x in items %}{{ x }}{% endfor %}{{ x }}";
        let ast = parse(src, "forleak.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["items", "x"]);
    }

    #[test]
    fn with_var_not_visible_after_block() {
        let src = "{% with y = 1 %}{{ y }}{% endwith %}{{ y }}";
        let ast = parse(src, "withleak.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["y"]);
    }

    #[test]
    fn set_inside_if_persists_to_template_scope() {
        // if 不创建作用域（Jinja2 语义）：if 内 set 的名字在其后可见
        let src = "{% if cond %}{% set tmp = 1 %}{% endif %}{{ tmp }}";
        let ast = parse(src, "ifset.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["cond"]);
    }

    #[test]
    fn for_filter_expr_sees_loop_var() {
        // for 的 if 过滤表达式可引用循环变量（Jinja2 语义）
        let src = "{% for x in items if x > 0 %}{{ x }}{% endfor %}";
        let ast = parse(src, "forfilter.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["items"]);
    }

    #[test]
    fn macro_body_scoped() {
        // 宏体内 set 的名字不泄漏到外层
        let src = "{% macro m() %}{% set inner = 1 %}{{ inner }}{% endmacro %}{{ m() }}{{ inner }}";
        let ast = parse(src, "macrosc.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["inner"]);
    }

    #[test]
    fn with_self_referential_value_reports_outer_var() {
        // {% with y = y + 1 %}：右侧 y 引用外层/上下文值，不应被误判为局部
        let src = "{% with y = y + base %}{{ y }}{% endwith %}";
        let ast = parse(src, "withself.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["y", "base"]);
    }

    #[test]
    fn nested_default_all_optional() {
        // {{ a | default(b | default(1)) }}：a 和 b 都在兜底上下文
        let src = "{{ a | default(b | default(1)) }}";
        let ast = parse(src, "nest.j2").unwrap();
        let vars = extract_variables(&ast);
        for v in &vars {
            assert!(v.optional, "{} 应标记为可选", v.name);
        }
        assert_eq!(vars.len(), 2);
    }

    #[test]
    fn filter_chain_extracts_vars() {
        let src = "{{ x | abs | round(2) }}";
        let ast = parse(src, "chain.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["x"]);
    }

    #[test]
    fn complex_expression_vars() {
        let src = "G1 X{{ (diameter / 2) + offset | round(2) }} F{{ feed * 1.5 }}";
        let ast = parse(src, "complex.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["diameter", "offset", "feed"]);
    }

    #[test]
    fn string_and_list_literals_no_vars() {
        let src = r#"{{ "hello" }} {{ [1, 2, 3] }} {{ {"a": 1} }}"#;
        let ast = parse(src, "literal.j2").unwrap();
        assert!(extract_undeclared(&ast).is_empty());
    }

    #[test]
    fn whitespace_control_parses() {
        let src = "{%- set x = 1 -%}\n{{- x -}}\n";
        let ast = parse(src, "ws.j2").unwrap();
        assert!(extract_undeclared(&ast).is_empty());
    }

    #[test]
    fn variable_name_with_underscores_and_digits() {
        let src = "{{ my_var_1 }} {{ _private }} {{ x2 }}";
        let ast = parse(src, "names.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["my_var_1", "_private", "x2"]);
    }

    // -----------------------------------------------------------------------
    // 极端输入：Unicode / 特殊字符 / 超长 / 深嵌套
    // -----------------------------------------------------------------------

    #[test]
    fn unicode_content_renders() {
        // 模板内容（非变量名）含中文/emoji，应正常解析和渲染
        let src = "G1 X{{ x }} (中文注释 ✅)";
        let r = Renderer::new();
        let ctx = minijinja::context! { x => 10.0 };
        let out = r.render(src, "unicode.j2", &ctx).unwrap();
        assert!(out.contains("中文注释 ✅"));
        assert!(out.contains("X10"));
    }

    #[test]
    fn special_characters_in_text() {
        // 反斜杠、引号、控制字符在纯文本中应正常透传
        let src = r#"path: C:\temp\file "quoted" tab:	here"#;
        let ast = parse(src, "special.j2").unwrap();
        assert!(extract_undeclared(&ast).is_empty());
        let r = Renderer::new();
        let ctx = minijinja::context! {};
        let out = r.render(src, "special.j2", &ctx).unwrap();
        assert!(out.contains(r"C:\temp\file"));
        assert!(out.contains("\"quoted\""));
    }

    #[test]
    fn very_long_variable_name() {
        // 256 字符变量名
        let long_name = "x".repeat(256);
        let src = format!("{{{{ {long_name} }}}}");
        let ast = parse(&src, "long.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        assert_eq!(undeclared.len(), 1);
        assert_eq!(undeclared[0].name.len(), 256);
    }

    #[test]
    fn many_distinct_variables() {
        // 1000 个不同变量，验证去重和性能
        let mut src = String::new();
        for i in 0..1000 {
            src.push_str(&format!("{{{{ var_{i} }}}} "));
        }
        let ast = parse(&src, "many.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        assert_eq!(undeclared.len(), 1000);
        let all = extract_variables(&ast);
        assert_eq!(all.len(), 1000);
    }

    #[test]
    fn deeply_nested_ifs() {
        // 50 层嵌套 if
        let mut src = String::new();
        for i in 0..50 {
            src.push_str(&format!("{{% if v{i} > 0 %}}"));
        }
        src.push_str("DEEP");
        for _ in 0..50 {
            src.push_str("{% endif %}");
        }
        let ast = parse(&src, "deep.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        assert_eq!(undeclared.len(), 50);
    }

    #[test]
    fn deeply_nested_defaults() {
        // 50 层嵌套 default：{{ a | default(b | default(c | ... | default(0))) }}
        let mut expr = String::from("0");
        for i in (0..50).rev() {
            expr = format!("v{i} | default({expr})");
        }
        let src = format!("{{{{ {expr} }}}}");
        let ast = parse(&src, "nestdef.j2").unwrap();
        let vars = extract_variables(&ast);
        assert_eq!(vars.len(), 50);
        // 所有变量都在 default 兜底链中，应全为可选
        for v in &vars {
            assert!(v.optional, "{} 应标记为可选", v.name);
        }
    }

    #[test]
    fn mixed_optional_required_in_chain() {
        // default 链中混入非兜底引用：{{ a | default(b) }} {{ c }}
        // a 可选（在 default 操作数位置），b 必选（default 的参数位置），c 必选
        let src = "{{ a | default(b) }} {{ c }}";
        let ast = parse(src, "mixed.j2").unwrap();
        let vars = extract_variables(&ast);
        let get = |n: &str| vars.iter().find(|v| v.name == n).unwrap();
        assert!(get("a").optional, "a 应可选");
        assert!(!get("b").optional, "b 应必选（default 参数）");
        assert!(!get("c").optional, "c 应必选");
    }

    #[test]
    fn comment_with_special_chars() {
        // 注释中含模板语法字符，不应被解析
        let src = "{# {{ not_a_var }} {% if x %} #}{{ real_var }}";
        let ast = parse(src, "comment.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["real_var"]);
    }

    #[test]
    fn raw_block_ignores_template_syntax() {
        // raw 块内的模板语法不应被解析
        let src = "{% raw %}{{ not_var }} {% if x %}{% endraw %}{{ real }}";
        let ast = parse(src, "raw.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["real"]);
    }

    #[test]
    fn empty_for_loop_body() {
        let src = "{% for x in items %}{% endfor %}";
        let ast = parse(src, "emptyfor.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        let names: Vec<&str> = undeclared.iter().map(|v| v.name.as_str()).collect();
        assert_eq!(names, vec!["items"]);
    }

    #[test]
    fn macro_with_no_args() {
        let src = "{% macro say_hi() %}HI{% endmacro %}{{ say_hi() }}";
        let ast = parse(src, "macro0.j2").unwrap();
        assert!(extract_undeclared(&ast).is_empty());
    }

    #[test]
    fn variable_starting_with_digit_is_syntax_error() {
        // Jinja2 变量名不能以数字开头
        let result = parse("{{ 1bad }}", "baddigit.j2");
        assert!(result.is_err());
    }

    #[test]
    fn types_are_send_and_sync() {
        // 编译时断言：核心类型可跨线程共享和移动
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<Renderer>();
        assert_send_sync::<Variable>();
        assert_send_sync::<TplError>();
        // Ast 带生命周期，用 'static 验证
        assert_send_sync::<Ast<'static>>();
    }

    #[test]
    fn multi_thread_render_shared_renderer() {
        // 多个线程共享同一个 Renderer（&self），同时渲染不同模板
        use std::sync::Arc;
        use std::thread;

        let renderer = Arc::new(Renderer::new());
        let mut handles = vec![];

        for i in 0..8 {
            let r = Arc::clone(&renderer);
            handles.push(thread::spawn(move || {
                let src = format!("G1 X{{{{ x }}}} F{{{{ feed }}}} ; thread {i}");
                let ctx = minijinja::context! { x => i as f64 * 10.0, feed => 0.15 };
                let out = r.render(&src, &format!("t{i}.j2"), &ctx).unwrap();
                assert!(out.contains(&format!("X{}", i * 10)));
                assert!(out.contains("F0.15"));
                out
            }));
        }

        for h in handles {
            h.join().unwrap();
        }
    }

    #[test]
    fn multi_thread_parse_and_extract() {
        // 多个线程同时解析和提取变量
        use std::thread;

        let mut handles = vec![];
        for i in 0..8 {
            handles.push(thread::spawn(move || {
                let src = format!("{{{{ var_{i} }}}} {{{{ common }}}}");
                let name = format!("t{i}.j2");
                let ast = parse(&src, &name).unwrap();
                let undeclared = extract_undeclared(&ast);
                assert_eq!(undeclared.len(), 2);
                undeclared
            }));
        }
        for h in handles {
            let result = h.join().unwrap();
            assert_eq!(result.len(), 2);
        }
    }

    // -----------------------------------------------------------------------
    // Fuzz 测试：随机模板输入不 panic
    // -----------------------------------------------------------------------

    /// 简单 LCG 伪随机数生成器（无需额外依赖）。
    struct SimpleRng {
        state: u64,
    }

    impl SimpleRng {
        fn new(seed: u64) -> Self {
            SimpleRng { state: seed }
        }
        fn next_u64(&mut self) -> u64 {
            // LCG 参数（Numerical Recipes）
            self.state = self
                .state
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            self.state
        }
        fn next_usize(&mut self, max: usize) -> usize {
            (self.next_u64() as usize) % max
        }
    }

    #[test]
    fn fuzz_random_templates_no_panic() {
        // 5000 次随机模板输入，验证 parse/extract 绝不 panic
        let charset: Vec<char> = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \t\n{}%#|/-=!<>()[].,;:\"'&".chars().collect();
        let keywords = [
            "if",
            "for",
            "set",
            "macro",
            "default",
            "defined",
            "end",
            "else",
            "elif",
            "include",
            "extends",
            "import",
            "from",
            "as",
            "in",
            "not",
            "and",
            "or",
            "is",
            "{{",
            "}}",
            "{%",
            "%}",
            "{#",
            "#}",
            "|",
            "default(",
            "is defined",
            "is undefined",
        ];

        let mut rng = SimpleRng::new(20260830);

        for iteration in 0..5000 {
            // 随机生成长度 0-200 的字符串
            let len = rng.next_usize(201);
            let mut s = String::with_capacity(len);
            for _ in 0..len {
                if rng.next_usize(10) < 3 {
                    // 30% 概率插入关键字片段
                    let kw = keywords[rng.next_usize(keywords.len())];
                    s.push_str(kw);
                } else {
                    // 70% 概率插入随机字符
                    s.push(charset[rng.next_usize(charset.len())]);
                }
            }

            let name = format!("fuzz_{iteration}.j2");
            // 断言分两层：① 绝不 panic（本测试的底线）；② **返回值仍满足提取器
            // 自己的契约** —— 此前是 `let _ = ...`，只验证了第一层，容易造成
            // "提取器已被 fuzz 验证" 的错觉。
            if let Ok(ast) = parse(&s, &name) {
                let all = extract_variables(&ast);
                let undeclared = extract_undeclared(&ast);
                assert_extract_invariants(&s, &all, &undeclared);
            }
        }
        // 如果到达这里，说明 5000 次迭代均无 panic 且不变量成立
    }

    #[test]
    fn fuzz_random_render_no_panic() {
        // 1000 次随机渲染输入，验证 render 绝不 panic
        let charset: Vec<char> = "abcdefghijklmnopqrstuvwxyz0123456789 \t\n{}%|/-=!<>()[].,;:"
            .chars()
            .collect();
        let mut rng = SimpleRng::new(42);
        let renderer = Renderer::new();

        for iteration in 0..1000 {
            let len = rng.next_usize(101);
            let mut s = String::with_capacity(len);
            for _ in 0..len {
                s.push(charset[rng.next_usize(charset.len())]);
            }

            let ctx = minijinja::context! { x => 1.0, y => "test", z => vec![1, 2, 3] };
            // 弱断言补强（A8）：不只是 "不 panic"，而是断言 `RichResult` 的形状
            // 恒定 —— 成功时 Ok(String)，失败时 Err(TplError) 且 Display 不为空。
            // 之前 `let _ =` 抛掉返回值，一个"永远返回 Err 且消息为空"的退步
            // 也能通过。
            match renderer.render(&s, &format!("r{iteration}.j2"), &ctx) {
                Ok(out) => {
                    // 成功渲染：输出是字符串（可为空——空模板合法）
                    let _: &str = &out;
                }
                Err(e) => {
                    assert!(
                        !e.to_string().is_empty(),
                        "渲染错误必须带可读消息，输入 {s:?}"
                    );
                }
            }
        }
        // 如果到达这里，说明 1000 次迭代均无 panic 且返回形状恒定
    }

    // -----------------------------------------------------------------------
    // 内存/性能：大模板、深嵌套、无 O(n²)
    // -----------------------------------------------------------------------

    #[test]
    fn large_template_1mb_parses_and_extracts() {
        // 生成约 1MB 的模板（重复 G-code 行，每行含变量）
        let line = "G1 X{{ diameter / 2 }} Y{{ y_pos }} F{{ feed }} S{{ speed }}\n";
        let repeats = 1_000_000 / line.len();
        let src: String = line.repeat(repeats);
        assert!(
            src.len() >= 900_000,
            "模板应接近 1MB，实际 {} 字节",
            src.len()
        );

        let ast = parse(&src, "large.j2").unwrap();
        let undeclared = extract_undeclared(&ast);
        // 只有 4 个不同变量（diameter, y_pos, feed, speed）
        assert_eq!(undeclared.len(), 4);
        let all = extract_variables(&ast);
        assert_eq!(all.len(), 4);
    }

    #[test]
    fn large_template_render_performance() {
        // 100KB 模板渲染应在合理时间内完成
        let line = "G1 X{{ x }} Y{{ y }} F{{ feed }}\n";
        let repeats = 100_000 / line.len();
        let src: String = line.repeat(repeats);
        assert!(
            src.len() >= 90_000,
            "模板源应接近 100KB，实际 {} 字节",
            src.len()
        );

        let r = Renderer::new();
        let ctx = minijinja::context! { x => 10.0, y => 20.0, feed => 0.15 };
        let start = std::time::Instant::now();
        let out = r.render(&src, "large_render.j2", &ctx).unwrap();
        let elapsed = start.elapsed();
        // 渲染后输出应非空且包含预期内容（不精确卡长度，因 f64 格式和换行处理可能变化）
        assert!(!out.is_empty());
        assert!(out.contains("G1 X10.0 Y20.0 F0.15"));
        // 输出行数应与 repeats 一致
        let line_count = out.lines().count();
        assert_eq!(line_count, repeats, "输出行数应与 repeats 一致");
        assert!(
            elapsed.as_millis() < 2000,
            "渲染 100KB 应 < 2s，实际 {:?}",
            elapsed
        );
    }

    #[test]
    fn deeply_nested_100_levels_no_stack_overflow() {
        // 100 层嵌套 if（minijinja 解析器有递归深度限制，应在 parse 阶段报错而非栈溢出）
        let mut src = String::new();
        for i in 0..100 {
            src.push_str(&format!("{{% if v{i} > 0 %}}"));
        }
        src.push_str("DEEP");
        for _ in 0..100 {
            src.push_str("{% endif %}");
        }
        // 无论成功还是语法错误，都不应 panic 或栈溢出
        let result = parse(&src, "deep100.j2");
        match result {
            Ok(ast) => {
                // 如果解析成功（minijinja 允许 100 层），变量提取也不应栈溢出，
                // 且仍满足提取器不变量（A8：弱断言补强——此前是 `let _ =`）
                let all = extract_variables(&ast);
                let undeclared = extract_undeclared(&ast);
                assert_extract_invariants(&src, &all, &undeclared);
            }
            Err(_) => {
                // 解析失败是正常的（递归深度限制），不是 bug
            }
        }
    }

    #[test]
    fn many_duplicate_references_efficient() {
        // 同一变量被引用 10000 次，去重后应只有 1 个，且不 O(n²)
        let src = "{{ x }}".repeat(10000);
        let ast = parse(&src, "dup.j2").unwrap();
        let all = extract_variables(&ast);
        let undeclared = extract_undeclared(&ast);
        assert_eq!(all.len(), 1);
        assert_eq!(undeclared.len(), 1);
        assert_eq!(all[0].name, "x");
    }

    #[test]
    fn render_error_on_undefined() {
        // Strict 模式下，缺失变量必须报错而不是静默输出空值
        let src = "G1 X{{ missing_var }}";
        let renderer = Renderer::new();
        let ctx = minijinja::context! {};
        let err = renderer.render(src, "gcode.j2", &ctx).unwrap_err();
        match err {
            TplError::UndefinedVariable {
                variable, message, ..
            } => {
                // 变量名从源码错误位置尽力恢复
                assert_eq!(variable, "missing_var", "应恢复出变量名");
                assert!(
                    message.contains("undefined"),
                    "Strict 模式应报未定义值错误: {message}"
                );
            }
            _ => panic!("应为 UndefinedVariable 错误"),
        }
    }
}
