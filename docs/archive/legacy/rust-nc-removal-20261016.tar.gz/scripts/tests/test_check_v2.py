"""Architecture guard regressions without invoking Cargo or rebuilding WebUI."""
import copy
import importlib.util
from pathlib import Path
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / "check_v2.py"
SPEC = importlib.util.spec_from_file_location("check_v2", SCRIPT)
CHECK = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECK)


def packages():
    metadata = {
        name: {"name": name, "dependencies": [
            {"name": dependency, "kind": None} for dependency in sorted(dependencies)
        ]}
        for name, dependencies in CHECK.NEUTRAL_DEPENDENCIES.items()
    }
    metadata["nctool-tpl"] = {
        "name": "nctool-tpl", "dependencies": [{"name": "minijinja", "kind": None}],
    }
    metadata["nctool-cli"] = {
        "name": "nctool-cli",
        "features": {"default": [], "nc-bundle": ["dep:" + name for name in sorted(CHECK.NC_PACKAGES)]},
        "dependencies": [
            {"name": name, "kind": None, "optional": True} for name in sorted(CHECK.NC_PACKAGES)
        ] + [
            {"name": "nctool-plugin-" + name, "kind": None, "optional": False}
            for name in ("template", "parameters")
        ],
    }
    return metadata


TEMPLATE_TREE = "nctool-plugin-template nctool-plugin-parameters"
NC_TREE = TEMPLATE_TREE + " " + " ".join(sorted(CHECK.NC_PACKAGES))


class ArchitectureTest(unittest.TestCase):
    def check(self, metadata=None, workspace=NC_TREE, template=TEMPLATE_TREE, nc=NC_TREE):
        CHECK.check_architecture(metadata or packages(), workspace, template, nc)

    def test_optional_nc_bundle_and_pure_engine(self):
        self.check()

    def test_domain_implementations_stay_out_of_neutral_dependencies(self):
        for package in CHECK.NEUTRAL_DEPENDENCIES:
            for dependency in CHECK.NC_PACKAGES | {"nctool-plugin-nc-model"}:
                with self.subTest(package=package, dependency=dependency):
                    metadata = packages()
                    metadata[package]["dependencies"].append({"name": dependency, "kind": None})
                    with self.assertRaises(AssertionError):
                        self.check(metadata)
        metadata = packages()
        metadata["nctool-runtime"]["dependencies"].append({"name": "nctool-plugin-nc", "kind": "dev"})
        self.check(metadata)

    def test_nc_bundle_is_explicit_complete_and_optional(self):
        for features in [{"default": ["nc-bundle"]}, {"nc-bundle": []}]:
            with self.subTest(features=features):
                metadata = packages()
                metadata["nctool-cli"]["features"].update(features)
                with self.assertRaises(AssertionError):
                    self.check(metadata)
        for name in CHECK.NC_PACKAGES:
            with self.subTest(name=name):
                with self.assertRaises(AssertionError):
                    self.check(template=TEMPLATE_TREE + " " + name)
                with self.assertRaises(AssertionError):
                    self.check(nc=NC_TREE.replace(name, ""))
                metadata = packages()
                next(d for d in metadata["nctool-cli"]["dependencies"] if d["name"] == name)["optional"] = False
                with self.assertRaises(AssertionError):
                    self.check(metadata)

    def test_default_build_keeps_template_and_parameters(self):
        for name in ("nctool-plugin-template", "nctool-plugin-parameters"):
            with self.subTest(name=name):
                with self.assertRaises(AssertionError):
                    self.check(template=TEMPLATE_TREE.replace(name, ""))
                metadata = packages()
                next(d for d in metadata["nctool-cli"]["dependencies"] if d["name"] == name)["optional"] = True
                with self.assertRaises(AssertionError):
                    self.check(metadata)

    def test_engine_production_dependencies_stay_minimal(self):
        metadata = packages()
        metadata["nctool-tpl"]["dependencies"].append({"name": "criterion", "kind": "dev"})
        self.check(metadata)
        changed = copy.deepcopy(metadata)
        changed["nctool-tpl"]["dependencies"].append({"name": "serde_json", "kind": None})
        with self.assertRaises(AssertionError):
            self.check(changed)

    def test_legacy_desktop_dependency_is_rejected(self):
        for tree in ["tauri v2", "tauri-runtime v2", "nctool-gui v1"]:
            with self.subTest(tree=tree), self.assertRaises(AssertionError):
                self.check(workspace=tree)

    def test_shared_parameter_module_keeps_generic_helpers_alongside_optional_nc(self):
        """共享参数不能因保留可选 NC 的刀具输入辅助函数而整体判为退役。"""
        module = CHECK.ROOT / "ui/src/lib/managedParameters.ts"
        self.assertTrue(module.exists(), "共享参数模块缺失，引用方会失效")
        text = module.read_text(encoding="utf-8")
        for expected in ["pointerTokens", "pointerValue", "applyOverrides", "managedRequest", "managedFields"]:
            with self.subTest(exported=expected):
                self.assertIn(f"export function {expected}", text)


if __name__ == "__main__":
    unittest.main()
