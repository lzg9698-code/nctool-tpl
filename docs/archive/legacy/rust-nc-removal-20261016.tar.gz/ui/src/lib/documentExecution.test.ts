import { describe, expect, it } from "vitest";
import { newDocument, parseData, encode, DraftNumber, type Run } from "./data";
import { decodeDraft, encodeDraft } from "./drafts";
import {
  activePanels,
  documentActions,
  documentInput,
  selectDocumentAction,
  documentSignature,
  historyExecutionReason,
  restoreDocument,
} from "./documentExecution";
const text = {
  id: "template.render",
  ui_schema: {
    document_input: {
      default: true,
      bindings: {
        source: "source",
        context: "context",
        defaults: "defaults",
        schema: "schema",
        extensions: "extensions",
      },
    },
  },
};
const managed = {
  id: "template.render.managed",
  ui_schema: {
    document_input: {
      match_metadata: "parameters",
      bindings: {
        source: "source",
        template: "id",
        context: "context",
        defaults: "defaults",
        schema: "schema",
        bindings: "metadata.parameters.bindings",
        preset_id: "parameter_preset_id",
        extensions: "extensions",
      },
    },
  },
};
const report = {
  id: "report.make",
  ui_schema: {
    document_input: {
      match_metadata: "report",
      bindings: {
        payload: "effective_context",
        format: "metadata.report.format",
      },
    },
  },
};
const nc = {
  id: "nc.generate",
  ui_schema: {
    document_input: {
      match_metadata: "nc",
      bindings: {
        source: "source",
        template: "id",
        params: "effective_context",
        schema: "schema",
        defaults: "defaults",
        specs: "metadata.nc.specs",
        options: "metadata.nc.options",
        machine_id: "metadata.nc.machine_id",
      },
    },
  },
};
function run(action = "template.render.managed"): Run {
  return {
    id: "r1",
    title: "History",
    action,
    input: {},
    status: "succeeded",
    started_at: 0,
  };
}
describe("generic document execution and optional NC capabilities", () => {
  it("keeps generic metadata ordinary unless an external provider declares it", () => {
    const doc = newDocument();
    doc.asset.metadata = {
      title: "NC machine",
      report: { format: "csv" },
      machine: {},
      process: {},
      turning: {},
    };
    expect(selectDocumentAction(doc, [text]).entry?.id).toBe(text.id);
    expect(selectDocumentAction(doc, [text, report]).entry?.id).toBe(report.id);
    expect(documentInput(doc, report)).toEqual({ payload: {}, format: "csv" });
    expect(
      selectDocumentAction(doc, [
        text,
        report,
        { ...report, id: "other.report" },
      ]).error,
    ).toMatch("多个插件");
    doc.generationAction = report.id;
    expect(selectDocumentAction(doc, [text]).error).toMatch("不可用");
  });
  it("does not downgrade NC metadata including null to ordinary rendering", () => {
    for (const value of [null, {}, { operation: { id: "groove" } }, false]) {
      const doc = newDocument();
      doc.asset.metadata = { nc: value };
      for (const requested of [undefined, text.id, managed.id]) {
        doc.generationAction = requested;
        expect(selectDocumentAction(doc, [text, managed]).entry).toBeUndefined();
        expect(selectDocumentAction(doc, [text, managed]).error).toMatch("不能降级");
        expect(() => documentInput(doc, text)).toThrow("不能降级");
        expect(() => documentInput(doc, managed)).toThrow("不能降级");
      }
      doc.generationAction = undefined;
      expect(selectDocumentAction(doc, [text], [text, nc]).error).toMatch("nc.generate 当前不可用");
      // Raw metadata stays intact for the matching provider to validate.
      expect(selectDocumentAction(doc, [text, nc]).entry).toBe(nc);
      expect(doc.asset.metadata.nc).toBe(value);
    }
  });
  it("selects NC by metadata or explicit intent only when its action is available", () => {
    const doc = newDocument();
    doc.asset.metadata = { nc: {}, parameters: { bindings: { x: "shared-x" } } };
    expect(selectDocumentAction(doc, [text, managed, nc]).entry).toBe(nc);
    // Current capabilities supplement an older association catalog.
    expect(selectDocumentAction(doc, [text, nc], [text]).entry).toBe(nc);
    for (const id of [nc.id, "process.generate.managed", "sync-turning.generate", "undercut.generate"]) {
      const provider = { ...nc, id };
      doc.asset.metadata = { execution: { action: id } };
      expect(selectDocumentAction(doc, [text]).error).toMatch("当前不可用");
      expect(selectDocumentAction(doc, [text, provider]).entry).toBe(provider);
      doc.generationAction = text.id;
      expect(selectDocumentAction(doc, [text, provider]).error).toMatch("不能降级");
      delete doc.asset.metadata.execution;
      doc.generationAction = id;
      expect(selectDocumentAction(doc, [text]).error).toMatch("当前不可用");
      expect(selectDocumentAction(doc, [text, provider]).entry).toBe(provider);
      expect(() => documentInput(doc, provider)).not.toThrow();
      doc.generationAction = undefined;
      expect(selectDocumentAction(doc, [text]).entry).toBe(text);
    }
  });
  it("keeps contributed actions and panels only while their actions are available", () => {
    const panels = [
      { id: "templates", view: "template-editor", actions: [text.id] },
      { id: "tools", view: "nc.parameters", actions: [nc.id] },
      { id: "process", view: "nc.process", actions: ["process.generate"] },
      { id: "parameters", view: "parameter.library", actions: [] },
      { id: "report", view: "report.form", actions: [report.id, nc.id] },
    ];
    expect(documentActions([text, report, nc, { id: "machine.list" }])).toEqual([text, report, nc]);
    expect(activePanels(panels, [text, report])).toEqual([
      { id: "parameters", view: "parameter.library", actions: [] },
      { id: "report", view: "report.form", actions: [report.id] },
    ]);
    expect(activePanels(panels, [text, report, nc])).toEqual([
      { id: "tools", view: "nc.parameters", actions: [nc.id] },
      { id: "parameters", view: "parameter.library", actions: [] },
      { id: "report", view: "report.form", actions: [report.id, nc.id] },
    ]);
  });
  it("preserves NC bindings and exact effective parameters without changing original JSON", () => {
    const doc = newDocument();
    doc.id = "nc-template";
    doc.asset.defaults = { depth: 2 };
    doc.asset.metadata = { nc: { specs: { x: { type: "integer" } }, options: { line_numbers: true }, machine_id: "lathe" } };
    doc.context = parseData('{"x":9007199254740993,"nested":{"enabled":true},"empty":null}');
    const original = encode(doc);
    const input = documentInput(doc, nc);
    expect(encode(input.params)).toBe('{"depth":2,"x":9007199254740993,"nested":{"enabled":true},"empty":null}');
    expect(input.template).toBe("nc-template");
    expect(input.specs).toEqual(doc.asset.metadata.nc.specs);
    expect(input.options).toEqual({ line_numbers: true });
    expect(input.machine_id).toBe("lathe");
    expect(encode(doc)).toBe(original);
    doc.context.x = new DraftNumber("-");
    expect(() => documentInput(doc, nc)).toThrow();
  });
  it("preserves exact and nested JSON input, and rejects incomplete numeric drafts", () => {
    const doc = newDocument();
    doc.asset.metadata = { report: { format: "csv" } };
    doc.asset.defaults = { other: null };
    doc.context = parseData('{"x":9007199254740993,"nested":{"enabled":true}}');
    expect(encode(documentInput(doc, report).payload)).toBe(
      '{"other":null,"x":9007199254740993,"nested":{"enabled":true}}',
    );
    doc.context.x = new DraftNumber("-");
    expect(() => documentInput(doc, report)).toThrow();
  });
  it("forwards only explicit extensions on plain and managed rendering and invalidates changed choices", () => {
    const doc = newDocument();
    expect(documentInput(doc, text).extensions).toEqual([]);
    doc.asset.metadata = {
      parameters: {},
      execution: { extensions: ["math"] },
    };
    expect(selectDocumentAction(doc, [text, managed]).entry?.id).toBe(
      managed.id,
    );
    expect(documentInput(doc, managed).extensions).toEqual(["math"]);
    const original = documentSignature(doc, managed.id);
    doc.extensions = [];
    expect(documentInput(doc, managed).extensions).toEqual([]);
    expect(documentSignature(doc, managed.id)).not.toBe(original);
  });
});
describe("history recovery", () => {
  it("inherits an asset default when the selection has no preset choice", () => {
    const doc = newDocument();
    doc.asset.metadata = { parameters: { preset_id: "default-preset" } };
    expect(documentInput(doc, managed).preset_id).toBe("default-preset");
    doc.parameterSelection = {};
    expect(documentInput(doc, managed).preset_id).toBe("default-preset");
  });
  it("forwards an explicit preset decline instead of dropping it", () => {
    const doc = newDocument();
    doc.asset.metadata = { parameters: { preset_id: "default-preset" } };
    doc.parameterSelection = { preset_id: null };
    // Dropping it would let the backend fall back to the asset's saved preset.
    expect(documentInput(doc, managed).preset_id).toBeNull();
  });
  it("keeps unavailable runs readable but refuses execution and restoration", () => {
    for (const id of [
      "nc.generate",
      "process.generate",
      "sync-turning.generate",
      "missing.external",
    ]) {
      const history = run(id);
      expect(historyExecutionReason(history, [text, managed])).not.toBe("");
      expect(() => restoreDocument(history, [text, managed])).toThrow();
    }
  });
  it("allows available NC history execution without adding document restoration support", () => {
    for (const id of [nc.id, "process.generate", "sync-turning.generate", "undercut.generate"]) {
      const history = run(id);
      history.input = { snapshot: { asset: { source: "old", metadata: { nc: {} } } } };
      const provider = { ...nc, id };
      expect(historyExecutionReason(history, [text, provider])).toBe("");
      expect(historyExecutionReason(history, [text])).toMatch("没有可用提供方");
      expect(() => restoreDocument(history, [provider])).toThrow("不支持恢复为模板文档");
    }
  });
  it("blocks ordinary history rendering of NC snapshots in either saved input", () => {
    for (const provider of [text, managed]) {
      for (const useReplay of [false, true]) {
        const history = run(provider.id);
        const input = { snapshot: { asset: { source: "old", metadata: { nc: null } } } };
        history.input = useReplay ? {} : input;
        history.result = {
          artifacts: [],
          diagnostics: [],
          data: { replay_input: useReplay ? input : {} },
        };
        expect(historyExecutionReason(history, [provider, nc])).toMatch("不能通过普通渲染");
        expect(() => restoreDocument(history, [provider, nc])).toThrow("不能通过普通渲染");
      }
    }
  });
  it("restores the frozen parameter request and referenced sources without live asset resolution or history mutation", () => {
    const history = run();
    history.input = { source: "old live source", context: { x: 0 } };
    history.result = {
      artifacts: [],
      diagnostics: [],
      data: {
        replay_input: parseData(
          '{"snapshot":{"template":"main","templates":{"main":"{% include \'header\' %} {{ x }}","header":"frozen header"},"asset":{"source":"older saved source","metadata":{"parameters":{"preset_id":"live-preset","bindings":{"x":"shared-x"}}}}},"parameter_snapshot":{"version":1,"records":[]},"parameter_request":{"values":{"x":9007199254740993},"defaults":{"y":2},"schema":{"type":"object"},"bindings":{"x":"shared-x"},"preset_id":"frozen-preset"},"extensions":["math"]}',
        ),
      },
    };
    const original = encode(history);
    const doc = restoreDocument(history, [managed]);
    expect(doc.asset.source).toContain("include");
    expect(encode(doc.context)).toBe('{"x":9007199254740993}');
    expect(doc.asset.defaults).toEqual(parseData('{"y":2}'));
    expect(doc.parameterSelection).toEqual({});
    expect(doc.extensions).toEqual(["math"]);
    expect(doc.asset.metadata?.parameters).not.toHaveProperty("preset_id");
    const input = documentInput(doc, managed);
    expect(input.snapshot.templates.header).toBe("frozen header");
    expect(input.parameter_request.preset_id).toBe("frozen-preset");
    expect(encode(input.parameter_request.values)).toBe(
      '{"x":9007199254740993}',
    );
    expect(input).not.toHaveProperty("source");
    expect(input).not.toHaveProperty("context");
    doc.context.x = parseData("42");
    doc.asset.source += " edited";
    const edited = documentInput(doc, managed);
    expect(encode(edited.parameter_request.values)).toBe('{"x":42}');
    expect(edited.snapshot.templates.main).toMatch("edited");
    expect(encode(history)).toBe(original);
    expect(decodeDraft(encodeDraft(doc))).toEqual(doc);
    doc.parameterSelection = { preset_id: "new-live-preset" };
    const live = documentInput(doc, managed);
    expect(live.preset_id).toBe("new-live-preset");
    expect(live).not.toHaveProperty("parameter_snapshot");
    expect(live).not.toHaveProperty("parameter_request");
  });
  it("retains ordinary template snapshot references and original input defaults/extensions", () => {
    const history = run(text.id);
    history.input = {
      snapshot: {
        template: "root",
        templates: { root: "{{ x }}", base: "frozen" },
        asset: null,
      },
      context: { x: null },
      defaults: { y: true },
      extensions: ["math"],
    };
    const doc = restoreDocument(history, [text]);
    expect(doc.context).toEqual({ x: null });
    expect(doc.asset.defaults).toEqual({ y: true });
    const input = documentInput(doc, text);
    expect(input.snapshot.templates.base).toBe("frozen");
    expect(input.extensions).toEqual(["math"]);
  });
});
