# Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/) 格式和 [语义化版本](https://semver.org/)。

## 版本策略

- **0.x 阶段**：API 仍在演进，`minor` 版本升级可能包含破坏性变更（如本版本的 API 收窄、错误细分）。
- **1.0.0**：公共 API 稳定后发布，此后严格遵循语义化版本（`major` = 破坏性变更，`minor` = 向后兼容新功能，`patch` = 向后兼容修复）。
- 破坏性变更均在 `Changed` 节明确标注，并在 README 中说明迁移方式。

---

## [未发布]

### 2026-10-15：异步响应与依赖状态修复（R6–R8）

继 R5 之后完成本轮项目审查的另外三项 P2。

- **R6**：`识别参数` 的晚响应不再覆盖请求期间的新规格。请求前捕获文档 key、源码与规格版本三元组，晚响应在 `editDoc` 更新回调内核对版本，不一致即整体丢弃并提示重新识别；一致时从**当前**规格增量补充缺失变量，不删除或覆写期间新增字段。新增同源比较 `sameSchema`（归一化可选容器，未写完的数值草稿判为版本已变）。回归 6 项覆盖源码变更丢弃、仅规格变更丢弃、增量合并保留自定义 title 与 required 不重复、容器缺失归一化、无新发现不改 asset、失败不跳转。
- **R7**：共享参数目录响应绑定 group 与请求序号，切组即清空不属于当前组的条目；乱序返回的旧组回包被丢弃，不会再出现以“共享预置”身份加载参数定义草稿。回归 3 项覆盖切走后旧回包不显示、切组清空、反向场景。
- **R8**：生成入口统一下沉 `busy` 门禁，与工具栏按钮 `disabled` 同源，快捷键无法在任务 queued/running 期间再排队；快捷键限定在模板工作台上下文，存在对话框/菜单或焦点位于可编辑控件时不生效。回归覆盖忙时、跨页、焦点、对话框与入口门禁。
- Windows 本机：默认与 all-features workspace/all-targets 各 259 项、文档 2 项、前端 16 文件 99 项、Python 24 项、三组隔离浏览器、Clippy `-D warnings`、Rust 1.89、架构与资源检查通过；锁文件未变。未执行远端 CI 或发布。

### 2026-10-15：退役引用、产物交付与草稿保护（R1–R4）

本轮项目审查确认的四项 P1。

- **R1**：被 `include`/`import`/`extends`（含动态与多层引用）的旧加工模板不再绕过退役校验。模板在实际加载时检查冻结元数据，未执行的引用不会被误拒；`TemplateSnapshot` 新增格式 2，完整冻结每个来源的 metadata。格式 1 旧快照保留解析与无依赖重放，实际加载依赖时返回 `snapshot_compatibility`（历史快照未保存该信息，不能假定通用），需重新检查当前资产建立格式 2；原历史与 artifact 仍可查看，不用实时资产补齐冻结快照。协议文档同步，RPC/服务版本仍为 1，未新增依赖。
- **R2**：`--out-dir` 多文件交付按实际目标文件系统识别名称冲突。暂存文件改用独占创建，`A.txt`/`a.txt`、尾点、尾空格等在同一文件系统上指向同一物理文件时整批失败，不再静默覆盖后报告成功。
- **R3**：高级规格 JSON 编辑器按文档身份隔离编辑器状态，外部值同步不进入用户撤销历史；切到另一文档后撤销不会把前一份规格写入当前文档草稿。同文档正常撤销、插件页与参数页编辑器同样受保护。
- **R4**：共享参数保存的晚响应不再覆盖保存期间的新编辑与持久草稿。响应绑定资产身份，只推进对应草稿的 `expected` 指纹；读取、新建、切换分组或卸载后到达的旧响应一律不写回。
- Windows 本机：Rust 默认与 all-features workspace/all-targets 各 254 项、文档 2 项、前端 84 项、Python 24 项、三组隔离浏览器、Clippy `-D warnings`、Rust 1.89、架构与资源检查通过；锁文件未变，生成资源经正式脚本重建。未执行远端 CI 或发布。完整取舍与兼容边界见 [P1 修复记录](docs/P1_FIXES_2026-10-15.md)。

### 2026-10-15：受管依赖检查按冻结引用集合判断过期

修复项目审查 R5（P2）：原先缺失的可选引用后来可解析时，`parameter.dependencies.check` 仍返回 current。

- 模板依赖范围由冻结来源集合自身推导，不再只看工作区现存模板清单。检查用冻结 snapshot 调用 `template.inspect`，按 include/import/from/extends 得到该结果实际依赖的模板名，再与当前磁盘集合双向比较源码，覆盖“原先不可解析、现在可解析”“源码已改”“已删除”三种变化。
- 冻结集合中从未被引用的新增资产不进入比较，不会把仍有效的结果误报过期；根模板源码仍按草稿排除，其变化只经 `template_metadata` 判定。
- `cli/tests/managed_parameters.rs` 新增 3 项回归：AZ→ANEWZ 过期判定并保留冻结重放 AZ、无关新增不误报、可达依赖的增删改检测。Windows 本机：默认与 all-features workspace/all-targets 各 259 项、文档 1 项、Clippy `-D warnings`、Rustfmt 通过；`target/r5-verify` 用真实 CLI 复现审查证据。未执行远端 CI 或发布。
- 删除退役残留文件 `ui/src/lib/managedParameters.ts`。它被 `scripts/check_v2.py` 列为必须移除的退役入口，却在提交中保留且无任何代码引用，导致架构检查断言失败；8 个同类退役文件均已删除。删除前已把工作树版本备份到本地忽略目录，2026-10-14 加工归档另有早期原字节。同时删除重构遗留的无调用者导出 `hasSharedParameters`/`managedFields`（签名把文档当资产传）与 `model.ts` 未使用的导入，前端类型检查恢复干净。

### 2026-10-15：现行文档与维护范围清理

- 根 README 与当前文档统一面向 Rust 通用模板平台，移除仓库外产品、私有研究及设备工艺资料的使用依赖。
- 删除过时研究提案、外部产品交付清单、一次性审查提示与专用车削计划占位页；有历史反向链接的路径保留简短归档入口。技术历史版本仍在现有 tar/manifest，已有 archive 文件保持原字节。
- 删除旧离线作业迁移工具及测试，移除无消费者的 YAML 数值分支和 `serde_yaml` 开发依赖；定向更新被撤回的 `yoke-derive` 0.8.3 → 0.8.4。
- 设置页不再展示退役能力，共享参数启用状态与后端一致；CI 纳入前端 lint 和第三组浏览器验收。
- Windows 最终验证：默认/math 各 248 项 Rust 测试、2 项文档测试、前端 62 项、Python 24 项、三组浏览器、Clippy、MSRV 和资源检查通过。Rust/npm 审计均 0 漏洞，Rust 无维护告警；未执行本轮远端三平台 CI 或发布。见[清理与最终验证](docs/archive/records/2026-10-15-rust-platform-cleanup.md)。

### 2026-10-14：WebUI 视觉与架构重构

- 界面改版为深蓝导航、浅灰工作区与清晰面板，新增明暗主题切换（浏览器本地偏好），编辑器通过 CSS 变量换色且不重建 EditorView。
- `App.tsx` 由 2361 行拆为约 260 行外壳；工作区/文档/任务状态移入 scoped Zustand store，文档操作、参数预设、会话生命周期与各面板分别成模块。
- 菜单与对话框改用 Radix DropdownMenu/Dialog，通知改用 Sonner；保留错误/成功通知的 alert/status 语义。补充 Testing Library 交互测试，原有静态与领域边界测试保留。
- 新增必要前端依赖（Tailwind 4、Radix、Sonner、Zustand、Testing Library、jsdom 28），维持 Vite 7.3.6、TypeScript 5.9.3、Vitest 5.0.3。`npm run --prefix ui lint` 为 TypeScript 未使用声明检查。
- 研究原型与图纸证据已迁出本仓库，由各自位置维护。[重构资源](docs/UI_REFACTOR_RESOURCES.md) · [实施与验证记录](docs/archive/records/2026-10-14-ui-refactor.md)。Windows 本机验证：前端 56 项、生产构建与资源一致性、`check_v2`、三组隔离浏览器验收通过；未运行三平台 CI 或发行，依赖审计 Rust 侧因公告库下载中断未完成。

### 2026-10-14：Rust 工作台收束为通用模板

- 移除 Rust 内置 NC、机床、多工序、同步粗车、越程槽及受管加工/轨迹能力，从当前导航、构建、示例和验收退出。
- 保留共享参数定义/预置、绑定、来源、冻结和受管模板渲染；math 改为独立 feature，配置 enabled 与请求 extensions 均显式，扩展选择进入重执行输入。根启动器改为 math 构建与 template profile。
- 旧领域标记禁止降级 render，旧加工历史原 artifact 可查看但不可重跑；旧配置只读预览、显式备份/指纹应用，混合加工资产包整体拒绝，用户数据不删除。
- 429 文件完整工作树基线保存在本地 target，205 文件加工及旧上下文按原路径归档。[归档与恢复](docs/archive/legacy/RUST_NC_RETIREMENT.md) · [实施与验证记录](docs/archive/records/2026-10-14-rust-template-simplification.md)。Windows本机验证：Rust 253项、文档4项、前端37项、Python 101项、两组浏览器验收及依赖审计通过；未运行三平台CI或发行，不代表验收已通过。

### 2026-10-14：固定方案轴类工作台归档退役

- 将旧工作台源码、静态页面、启动/停止入口及独立构建与验收脚本移出当前树，按原路径归档42个文件并逐文件校验，本地用户数据保留。
- 当时提供的离线输入迁移工具已于后续清理退出当前维护，历史版本随加工上下文归档保留，不继承旧 NC 与验收身份。
- [归档与恢复说明](docs/archive/legacy/WORKBENCH_RETIREMENT.md)。

### 2026-10-13：NC 最终处理链收敛

- 组合 NC 文本直接消费插件内部共享最终处理函数，移除虚拟模板的重复检查和渲染；保留机床/选项校验、行号游标与告警、取消和非有限输出拒绝。
- 修复 `nc.output.finalize` 新任务的重放参数格式，使其能按原动作重执行；已有历史保持原内容。
- 增加输出/诊断一致性、无关模板损坏隔离、非法输入与取消、历史重执行回归。本轮 Windows 验证见[实施记录](docs/archive/records/2026-10-13-nc-finalize-iteration.md)。

### 2026-10-08：阶段审查与收尾

- 共享资产删除要求字符串指纹，非法类型返回输入错误，过期指纹保留冲突保护。
- 受管服务与专用车削重执行校验冻结快照、NC 上下文和轨迹预设结构，拒绝畸形输入，避免进程 panic；原历史内容保持不可变。
- 修复 CLI 无法重新启用 `nc-managed`、`sync-turning`、`undercut` 内置插件的问题，补充回归测试。
- 根目录运行资产 `parameters/`、`templates/` 纳入忽略规则；可导入示例继续独立维护。验收支持独立报告目录，保留历史报告。
- 完成 Windows 全量本地验证与阶段记录，详见[收尾记录](docs/archive/records/PHASE_CLOSEOUT_2026-10-08.md)。产品、组件及协议版本各自维护。

### 2026-10-08：专用车削工作台与模板展示

- 同步粗车与越程槽高级设置支持新建、编辑完整 Jinja/NC 模板源码、语法校验、指纹保存与另存副本；实际生成消费自定义源码，旧任务保留冻结模板。专用模板仍从通用入口隐藏，模板附加运动不计入预设轨迹图。

- 同步粗车 ap2 支持计算后自动回填，计算/生成自动补齐留空值；保留手填值，无有效推荐时阻止生成。

- 同步粗车与越程槽统一左右侧标签、表格、状态反馈和高级设置；按窗口宽度布局输入/结果与双通道程序，支持键盘切换。
- 单侧预览独立保留，生成成功、预览、失败与过期状态明确；有效结果才允许复制、导出和加入组合。
- 专用模板按工艺元数据从通用模板入口隐藏，插件高级设置仍可选择；旧编辑草稿保留，资产、算法与后端 API 不变。
- 增加模板分类、展示隔离和响应式验收，并更新专用插件及受管参数浏览器回归入口。

### 独立参数管理与受管工艺生成

- 新增通用参数定义、共享预置、来源、冻结解析和冲突保护；新增刀具类型、具体刀具、材料、加工预置与标准资产页面。
- 新增 parameter.resolve、nc.parameters.resolve、nc.operation.prepare 及三个 managed 生成服务，各使用 v1 契约，保留原生成路径。
- Rust 完成键槽、左右同步车、ES/FS 越程槽与卡簧槽原始输入计算；组合使用当前任务片段、推进双通道同步号、分配 MPF/SPF，全部成功后交付。
- 提供 V3 全部 28 份模板的可导入包、逐模板计算映射、Python/Rust 对照与 WebUI 验收工具；运行时不依赖 Python/V3。
- CLI --out-dir 原子交付完整文件目录，多文件 --out 拒绝写入；新增参数选择确认、恢复推荐、草稿与过期结果检查。

### 2026-10-07：移除旧桌面 GUI

#### Removed

- 旧 Tauri 桌面 GUI 全部源码、前端依赖清单、图标、权限、打包配置及桌面启动脚本。
- GUI 专属 workspace 排除项、忽略规则、Dependabot 更新配置、`--include-legacy-gui` 审计选项及七条 Tauri 安全告警忽略规则。

#### Changed

- 当前文档与开发规则改用 CLI/WebUI 入口；保留历史 GUI 资料、迁移补丁和指纹记录，明确已删除的历史路径。
- 架构检查增加旧桌面源码和入口不存在、workspace 与 NC 组合无 Tauri 依赖的门槛；当前产品版本、业务代码和锁文件保持不变。

### 2026-10-07：Codex 开发规则与依赖审计

#### Added

- 项目 `AGENTS.md` 与审查、验证、文档/发布准备三个专用 Skills，约定 GitHub、隔离浏览器及 Context7 的使用与证据边界。
- 只读 Cargo/npm 依赖审计入口与报告，错误不误判为通过；CI 增加审计及报告上传，发布复用验证包含该门槛。
- Dependabot 覆盖当前 `ui`、Cargo 与 Actions；贡献指南与 PR 模板增加审计入口。

### 2026-10-07：项目文档整理

#### Added

- 文档总览与当前 WebUI 使用指南，按使用、开发、状态发布和历史资料导航。
- 集中历史归档与原路径索引，保留旧设计、迁移基线、阶段审查和验证记录。

#### Changed

- 模板、机床、工艺核对、UI 验收、状态、路线图及发布文档对齐当前 2.x 实现；历史测试结论与当前能力分别记录。
- Issue/PR 模板使用当前动作、JSON 输入与插件配置，不再引导使用旧 CLI、TOML 或内置机床方案。

### 2.x 实现记录（未发布，按阶段归纳）

本节依据源码与 [2026-10-01 至 10-04 阶段记录](docs/archive/records/IMPLEMENTATION_HISTORY_2026-10-04.md)补记，不推断正式发布日期。CLI/WebUI 为 2.2.0，核心组件为 2.0.0；实际发布状态另行记录。

#### 2.0：通用模板平台与可选领域插件

- **BREAKING**：原 core 拆分为资产、SDK、运行时及领域插件；旧 CLI、`/api` 路由、工序文件和业务模板不自动迁移，旧 GUI 退出 workspace。发行包不包含旧业务模板与内置机床方案。
- 独立 MiniJinja 引擎保持通用渲染，数学/NC 扩展按需注册；引入通用 JSON 资产、指纹冲突保护与模板快照。
- 增加版本化服务、依赖生命周期、事件及可选提供方；本地外部插件通过双向 JSON-RPC 调用宿主服务。
- CLI/HTTP 统一动作，NC 执行参数校验、派生及后处理，多工序按实际末行号续编并整体交付；增加 Python 报告示例。

#### 2.1：模板工作台

- 独立 React/TypeScript WebUI、使用/编辑双模式、模板库多文档与 CodeMirror 编辑器。
- 可视化参数定义、嵌套对象/数组表单、数值字面量保留、工作区草稿、保存冲突比较与模板/预设操作。
- 后台任务、取消、执行历史与结果过期状态；通用模板执行保存源码集合快照。

#### 2.2 与后续收口

- NC、机床及顺序工序专用视图按插件贡献载入；外部插件保留 Schema 表单。
- 本地插件检查/安装、配置表单、依赖预检查与下一次启动状态；输出逐行比较、历史重执行及工作区集合导入导出。
- 增加模板语法速查与试跑；模板库通过文档动作绑定选择 NC 生成，保留源码草稿与领域规格。
- 2026-10-03 关闭 R01–R10：非有限 NC 数值、机床入口校验、缺失领域能力、Schema/specs/defaults、动态引用、严格机床字段、原始 JSON 草稿、可选引用快照、整数范围和结果过期。证据见[审查关闭记录](docs/archive/records/CODE_REVIEW_2026-10-02.md)。
- 2026-10-04 增加完整源码恢复基线；标签发布依赖完整 CI，发行二进制按明确 target 构建并附 SHA-256。
- 历史页和工作区导入按职责拆分；新任务记录宿主/插件版本及服务绑定，新增只读 replay-check，重执行保存来源和实际环境比较。旧记录兼容保留，不承诺完整环境复现。


### 旧版 0.x / 1.0 未发布记录（原文保留）

以下记录属于 2.0 升级前的实现、候选或历史批次，不代表当前支持的命令、资产格式或发行状态。当前能力见 [项目状态](docs/PROJECT_STATUS.md)，原设计与迁移资料见[历史归档](docs/archive/README.md)。

以下引用为历史文件，当前仓库未保留：`docs/ARCHITECTURE_REVIEW.md`、`docs/CODE_REVIEW_2026-09-18.md`、`docs/CODE_REVIEW_2026-09-19.md`、`docs/CODE_REVIEW_2026-09-23.md`、`docs/TEMPLATE_INTEGRATION_PLAN.md`、`docs/err-num-precision-design.md`、`docs/err-num-underflow-design.md`、`docs/review/SUMMARY-2026-09-27.md`。仅保留原记录，不补造证据。


### 2026-09-30：仓库工具链与发布配置收口

#### Changed

- GitHub Actions 改为固定完整 commit SHA，设定 runner 超时，并让分支新提交自动取消过期 CI。
- Release workflow 按 job 缩小 `GITHUB_TOKEN` 权限；crates.io token 只在手动发布步骤注入，二进制 job 不可读取。
- 前端开发基线改为 Node 24 LTS；保留 Node 22.12+ 兼容范围并由 npm 严格检查，CI 与本机共用 `.nvmrc`，Node 类型定义与运行时对齐。
- 前端生产构建同时类型检查应用代码和 Vite 配置；统一 `.editorconfig`、`.npmrc` 与本地 `.env` 忽略规则。
- Dependabot 将 React/ReactDOM 类型和 Vite/plugin-react 的 major 升级分别成组，避免拆开发出的 peer dependency 冲突 PR。
- macOS CLI 集成测试对 loopback `connect_timeout` 的瞬时 `EAGAIN`/`Interrupted` 做有界重试。

#### Added

- Dependabot 每周检查 GitHub Actions、Cargo workspace 和 GUI npm 锁文件依赖；合并 minor/patch 更新，并将 Node 类型定义的 major 更新留给运行时迁移时处理。
- `gui/README.md` 记录 Tauri 本地开发、构建前置条件和当前 Windows NSIS 打包目标。

### 2026-09-30：1.0.0 候选版本准备

- 三个 crates 及其 workspace 内依赖约束升级为 `1.0.0`；该版本尚未发布。
- Release workflow 的 tag 事件只执行验证和二进制构建；crates.io 上传需手动触发并显式启用。
- 候选 tag 的 GitHub Release 标记为预发布；跨平台构建通过后附有三平台 CLI 资产，尚未定稿。
- 修复 macOS 临时目录经过 symlink 且预设父目录尚未创建时，路径规范化漏掉模板根保护的问题。
- 请求体读线程上限测试改为等待服务端计数器达到饱和，避免慢 CI runner 上固定 sleep 导致误报。

### 2026-09-29：1.0 升级预备收口（当前工作区）

#### Added

- 导入 NCTool V3 导出模板 28 份；源文件哈希与归档 manifest 对照，模板清单状态均为
  `unreviewed`。完整路径与 SHA-256 见 `docs/archive/legacy/TEMPLATE_ZIP_IMPORT_REPORT.md`。
- 桌面 GUI 增加模板管理、机床配置管理、配置诊断和预设编辑页面； Web UI 增加模板/机床资产
  管理、预设导入导出/重命名和编辑器静态检查。

#### Changed

- **BREAKING（1.0 前公共 API 收紧）**：`nctool-core::derive::derived_names` 与
  `TemplateEntry::invalidate_analysis` 不再是公共 API；`TemplateEntry::source_text` 改为私有，
  读取改用 `source_text()`，替换源码改用 `with_source_text()`。后者自动使缓存分析失效。迁移说明见
  `docs/archive/legacy/RELEASE.md` §4.5。
- Tauri 命令只负责参数适配；模板、机床、预设、lint、校验、渲染和配置视图都调用共享
  `nctool_cli::server::route`。删除启动时配置快照，避免桌面端用旧配置。
- 提交到 `/api/lint` 的 `source` 可覆盖磁盘源码，用于检查尚未保存的编辑器缓冲区。
- 模板清单中的 `status` 暴露到 HTTP/Tauri 类型，Web 列表和桌面渲染页显式显示 `unreviewed` 工艺风险。
- 模板清单更新经 core 资产写入接口做指纹保护；新模板已创建但清单更新失败时，响应包含警告。

#### Fixed

- 预设导入拒绝覆盖无法解析的现有预设文件，拒绝导入文档内重复名称；读取快照先取指纹，写入时冲突保护不再拿旧数据覆盖并发修改。
- 模板重命名对源文件删除做指纹校验；并发编辑时保留源文件并返回冲突。
- CLI / Web / 桌面端均阻止删除当前配置的默认机床，避免留下无法解析的默认机床 ID。
- Web 编辑器重载源码时同步更新文件指纹；演示模式支持预设重命名和 YAML 导出。
- 更新 Vite 与 React 插件，消除 `npm audit` 报告的开发服务器漏洞。

本段收录 2026-09-18 第三轮代码审查（`docs/CODE_REVIEW_2026-09-18.md`）的修复，按报告 §3
的批次顺序分两组：

- **批次一（堵住静默出错）**：五条「不报错但产出错误数值」的路径。改动全在 `core`，
  未触及公共 API 形状（`DeriveError` 新增变体，该枚举本就 `#[non_exhaustive]`）。
- **批次二（修好度量闭环）**：覆盖率门禁口径、自证测试、MSRV 声明、CI 卫生。
  **不改变任何运行时行为**，只让既有的质量声明从「文档里的一句话」变成可验证的事实。

**本段还收录五组后加的改动**（时序上晚于第三轮审查的批次一/二，故列于前）：

- **零件级批量生成 `nctool part generate`**（Backlog F4 #2 落地）——见下方同名小节。
- **第五轮代码审查的 2 条 P1 修复**（`docs/CODE_REVIEW_2026-09-23.md`）——见「批次十八」。
- **2026-09-24 两线合并**：并行开发线（远程）的批次十一～二十二一并并入本段。
- **2026-09-26 GUI 契约门禁 + 覆盖率口径修订** —— 见下方「批次三十」。
- **2026-09-27 第六轮审查三项 P0 收口**（`docs/review/SUMMARY-2026-09-27.md`，进行中）——
  见下方「批次三十一」；其余 P1/P2 后续批次续记。

> ⚠️ **关于「批次 N」的两套编号（2026-09-24 说明）**
>
> 2026-09-22 ~ 09-24 期间存在**两条并行开发线**：本地线做三大编辑模块 / `part generate` /
> 下溢与精度修复，远程线做 `nctool lint` / golden 刷新守卫 / 选项对拍 / 发布包收窄。
> 两条线各自从「批次十一」往下编号，因此本段 **同一编号会对应两条不同的小节**
> （重复编号：十五、十六、十七、十八）。
>
> | 编号 | 本地线主题 | 远程线主题 |
> | --- | --- | --- |
> | 批次十五 | 参数预设编辑（编辑模块三 T03） | 本地文件读取上限 + 错误链（第四轮批次 D） |
> | 批次十六 | 写盘底座与模板编辑（T01 + T02） | 消除 CLI ↔ Web UI 生成选项隐患 |
> | 批次十七 | 机床配置编辑 + UI 构建期拆分（T04） | 覆盖率洼地补齐（A3） |
> | 批次十八 | JSON/YAML 数值下溢（第五轮 P1-1） | 收窄发布包（A5） |
> | 批次十九～二十二 | —（本地线未使用） | golden 保护 / 弱断言 / `nctool lint` / 注释对齐 |
>
> **后续新增小节接续本段现有最大编号往后排，不复用旧编号**（注意：本句曾写作「一律用 批次二十三 及以后」，那是 2026-09-24 写下时二十三尚空着；此后二十三～二十九 已被占用，照抄会造出重复编号）。合并详情见 `overview.md`。

### 批次三十一：第六轮审查三项 P0 收口（SUMMARY-2026-09-27，2026-09-27）

依据 `docs/review/SUMMARY-2026-09-27.md`（3 P0 / 18 P1 / 38 P2）。本批记录三项 P0
与它们的硬前置（P1 先行项）；其余 P1 / P2 按批次续记。

#### Changed（P0-1 跨进程写互斥 + MSRV 抬升）

- **新增 `core/src/asset/lock.rs`**：`DirLock` OS 级 advisory 锁（std `File::try_lock`/
  `unlock`，1.89 稳定，零新增依赖；进程死亡由 OS 自动释放，无 stale/TTL 问题）。
  `WriteKernel::write_guarded` 流程变为「取锁 → 读快照 → 比对 → 写 → 释放」——
  修复全 crate 写路径零互斥的 check-then-write：两进程并发写同一文件可双双通过
  乐观锁比对、后 `rename` 者胜、先写者的编辑被静默丢弃。
- **等待时长可注入**：`write_guarded_with_wait`、`PresetStore::{save,upsert,remove}_with_wait`
  保留旧签名委托；CLI 默认 `CLI_LOCK_WAIT = 2s`，服务侧预设保存/删除传 `Duration::ZERO`
  （try-lock，拿不到即 409 —— serve 循环单线程，阻塞等锁会钉死 UI）。
- **新增 `WriteError::LockBusy { path }`**：与 `Conflict` 分工写死（冲突=内容已被改、以新
  内容为基线重试；锁争用=另一进程正在写、稍后重试同一操作）。`classify_write_error`
  单表加一行 → CLI 归 `write_conflict`(6)、HTTP 409 `write_conflict`，退出码矩阵与
  `exit_code_matrix` 测试零改动；HTTP 正文固定脱敏文案不带路径（路径只进 stderr），
  `Display`/CLI 消息带路径。锁文件 `<stem>.nctool.lock` 只 unlock 不 unlink（unlink 会破互斥）。
- **MSRV 1.85 → 1.89**（std 文件锁 API 稳定所需）：四份 `rust-version`、CI `msrv` job
  （toolchain `@1.89`、步骤改 publish-only 三包）、README / CONTRIBUTING / RELEASE /
  ROADMAP / overview 同步；本地 `cargo +1.89 check -p nctool-tpl -p nctool-core
  -p nctool-cli --locked` 实测通过。历史批次文档（CHANGELOG 旧记录 / 审查报告）不改写。
- **模板 `create` 的 `O_EXCL` 建议按架构 §3.1 撤回**：并发同名 `new` 由持锁串行化，
  后到者 `Conflict` → `template_duplicate`(6)，退出码契约零改动；`template.rs`、
  `templates.rs` 中「仍是 check-then-write、会静默覆盖」的旧注释同步改写。
- 测试：`concurrent_writes_to_same_path_never_corrupt`（两写者恰一 Ok、败者 Conflict、
  文件=胜者全文）、`try_lock_reports_busy_then_succeeds_after_release`、
  `lock_file_is_named_stem_nctool_lock_and_survives_release`（命名 + 不 unlink + 可再取）、
  classify / `from_write_error` / `write_error_resp` 各补 LockBusy 案例。

#### Changed（P0-2 转速上界随机床联动，Q-01 / Q-12）

- **`ParamSpec.max_from`**（serde default，磁盘模板不可声明，`with_max_from` builder）：
  `tool_change.spindle_speed` = 静态 `1..=6000` + `max_from("machine.max_spindle_rpm")`
  双保险 —— 无机床上下文或机床值非法时静态兜底，绝不以 0/负数为上界全量误杀。
- **校验链路穿机床上下文**：`validate_template_with_machine` / `validate_with_vars_with_machine` /
  `TemplateRegistry::validate_with_machine`（旧签名委托、零破坏）；CLI `render` / `validate` /
  `machine test`、服务端 validate/render 路由、core pipeline strict/lenient 全部传
  `Some(machine)`。动态值非法/缺失 → 回退静态上界 + 每规格一条 Warning（`IssueKind::Other`，
  不新增 JSON kind）；machine-less 调用方（编辑器、服务端校验、前端 Checks 页）有意保持原语义。
- **Q-12 前置**：`integer_range_warning` 单一来源接入 `validate_config_keys` 与机床
  preflight —— `max_spindle_rpm` = 0/负数/超 100000、位数键 <1 一律**警告不阻断**
  （阻断会误杀既有配置；parse 仍阻断）。指纹 `spec_fingerprint::canonical` 仅在
  `max_from=Some` 时追加列，历史指纹零失配。
- 测试 +6：边界 8 组、回退告警（0/-100/abc/缺失 → 静态 6000 + 回退警告含机床 id）、
  零/负机床值告警、预设 ≤ generic、preflight 非法机床值告警、e2e
  `cli_rejects_spindle_speed_above_machine_limit`（退出非 0 + stderr 含 3500 +
  stdout 无 `M3 S5000`）。

#### Fixed（本轮 P1 硬前置，先行完成）

- **P1-11 分类收敛**：`classify_write_error(e, not_found_kind, corrupt_kind)` 三参单表，
  六处手写映射合一 —— 不先收敛则 `LockBusy` 会静默落 `_ => io(3)` 兜底（正是本次要堵的
  「新变体靠 wildcard 蒙对」反模式）。
- **P0-3 / P1-9 路径外泄**：HTTP 写错误正文绝对路径脱敏（保留文件名供识别、目录段不回显），
  路径只进 stderr；`write_error_resp` 各变体 + `P1-17` 4xx 口径均有回归断言。
- **P1-13**：`variables.yaml` 8 键 min/max 守卫 + 测试。
- **P1-14 / P1-15**：`json_num` `#` 注释规则两处修复 + 测试。
- **P1-3 / P1-4**：`indent_of` 只认纯 ASCII（NBSP 不再被当缩进）+ 测试；`BuiltinWarning` /
  `install_builtins` 去掉 `expect`（panic 面收窄）+ health_json 覆盖。



本轮把 GUI 的 Tauri command 面接入契约门禁，并修正一处「度量在骗人」的口径问题。

#### Added

- **GUI 的 Tauri command 面纳入 parity 契约门禁**（新增 `scripts/check_gui_parity.mjs`）：
  把 `scripts/api_routes.json` 与 `gui/src/commands/*.rs` 里的 `run_route(...)` 调用点做
  **双向对拍** —— 每个被 GUI 封装的端点都要能定位到**生产**调用点，GUI 专有命令必须登记
  `reason`。为此给 `api_routes.json` 的端点补 `gui` / `gui_only` 字段，并在 CI 增加对应步骤。
  调用点校验只统计生产调用点（剔除 `#[cfg(test)]` 段与函数定义行），堵住「改了生产路径
  仍判绿」的盲区。

#### Changed

- **覆盖率口径修订 + 阈值 91% → 92%**（`scripts/check_coverage_caliber.py`、
  `.github/workflows/ci.yml`、`README.md`、`docs/CONTRIBUTING.md` 等）：原口径把 llvm-cov
  给注释 / 空行 / 纯分隔符写的 `DA:0` 也算进生产分母，等于在测「注释覆盖率」，且数值随
  llvm-cov / rustc 版本漂移。修订后分母只含**可执行**生产代码：本机 88.76% → **92.88%**
  （6600/7106）。按「**只上调、不下调**」政策同步把阈值由 91% 上调到 92%（余量 0.88pt）。
  脚本同时修好对 `#[cfg(test)]` **非 mod** 项（如 `pub(crate) fn for_test`）的剔除，
  避免其函数体漏进生产分母。
- **`--ignore-filename-regex` 改跨平台**（`.github/workflows/ci.yml`）：`(^|/)gui/` →
  `(^|[\\/])gui[\\/]`，使 Windows 反斜杠路径下 gui 的 9 个文件也能被排除（此前只写正斜杠，
  本机一个都排不掉，造成「本机能过 / CI 口径不一致」的隐患）。
- **临时目录 RAII 化**（`core/src/asset/machine.rs`、`cli/src/commands/machine.rs`、
  `cli/tests/cli_machine_e2e.rs`）：单测临时目录改用带 `Drop` 的守卫（`TmpDir` / `Env`），
  用例结束（含 panic 展开）即回收，消除 `%TEMP%\nctool_machine_*` 的跨用例堆积
  （`core::asset::machine` 实测由 +9/轮 降为 0）。

#### Fixed

- **`write_atomic` 对瞬时权限拒绝做有限重试**（`core/src/asset/atomic.rs`）：Windows 上杀毒
  软件等会瞬时占用目标文件、令写入以 `os error 5`（`PermissionDenied`）失败；现经 `with_retry`
  对**权限被拒**做有限次线性退避重试（上限 5 次 ≈ 100ms），其它 IO 错误不重试，真实只读
  目标重试耗尽后仍如实报错 —— **重试不掩盖问题**。

#### 测试

- 新增 11 项补测（`cli/src/server.rs`、`cli/src/context.rs`），`server.rs` 生产口径由
  65.98% 提升到 91.41%。
- workspace 全量通过；`cargo fmt --all --check`、`cargo clippy --workspace --all-targets -- -D warnings`、
  `cargo test --workspace --all-targets`、`cargo test --workspace --doc`、
  `RUSTDOCFLAGS="-D warnings" cargo doc --workspace --no-deps`、`cargo audit`、
  覆盖率门（**≥ 92%**）均通过。

### 批次一：堵住静默出错

#### Fixed

- **派生参数的链式依赖不再取错源值**（`core/src/derive.rs`）：`A.derive.from = B`
  且 `B` 自身也是派生参数时，A 的查表键此前取自 `with_defaults`（用户值 / 规格默认值），
  而 `out`（本轮已算出的派生值）只写不读。于是「用户传了 B」用旧值查表、「B 有默认值」
  用默认值查表 —— 两条路径都不报错，直接写出与型号不符的 G-code。
  现改为按依赖顺序（重复扫描到不动点）计算，源参数若也是派生参数则取**已算出的派生值**；
  互相依赖成环时返回新增的 `DeriveError::Circular`，不静默取任何值。

- **条件必选不再被模板内联兜底短路**（`core/src/validate.rs`）：`check_missing` 里
  `has_default`（含 `var.optional`）的判定早于 `required_if` 判定，导致模板写
  `{{ FS_Z_PLUS1 | default(0) }}` 时，清单里声明的 `required_if` **永久失效且无任何提示**
  —— 互斥分支参数被 `default(0)` 兜底后静默产出 `Z0`，正是 `undercut_fs.j2` 头部注释
  与 `templates.yaml:47-51` 明令禁止的场景。现改为：声明了 `required_if` 的参数，
  其必选性不受 `var.optional` 影响（规格显式声明的 `default` 仍算兜底）。

- **有限性检查递归进入列表**（`core/src/validate.rs`）：`check_finite` 此前只匹配顶层
  `Number`，`passes=[{z: NaN}]` 会「校验通过、渲染失败」（渲染期 `ensure_finite_context`
  是递归的），错误类型从 `Validation` 变成 `Render`，宽松模式「唯一硬失败项 = NonFinite」
  的承诺随之失真。现递归列表元素，消息带元素下标路径（如 `[1][0]`），
  并沿用与渲染期一致的 32 层深度上限。

- **规格默认值做有限性检查**（`core/src/validate.rs`）：`check_spec_defaults` 此前只查
  类型 / 白名单 / 区间，`default: .nan` 会经类型检查、绕过区间比较（NaN 的任何比较都是
  false）、且白名单通常未声明 —— 校验全绿，NaN 却在渲染前被静默注入上下文。

- **空前缀不再让整份程序静默不编号**（`core/src/pipeline.rs`、`core/src/machine.rs`）：
  机床配置 `line_number_prefix = ""` / `program_prefix = ""` 会让 `starts_with("")` 恒真，
  每一行都被判为「程序号行」或「已有行号」，`line_numbers: true` 下**一行都不编号且无告警**。
  键缺失与键为空串现在同等回退默认值（新增 `non_empty_config`）；
  `validate_config_keys` 对字符串类键补「非空」校验。

#### 测试

- 新增 10 项回归测试（derive 3 / validate 4 / pipeline 2 / machine 1），
  均已**反向验证**：临时回滚实现后全部 FAILED，恢复后通过。
- workspace 全量 **536 项**通过；`cargo fmt --all --check`、
  `cargo clippy --workspace --all-targets -- -D warnings`、
  `RUSTDOCFLAGS="-D warnings" cargo doc --workspace --no-deps` 均通过。

### 批次二：修好度量闭环

起因是一类不同于「代码错」的问题：**度量在骗人**。三处质量声明在当前仓库里都不成立 ——
覆盖率门禁的数字与它声称的口径对不上，退出码矩阵的用例删掉矩阵也照样绿，MSRV 写在
三处 `Cargo.toml` 却没有任何 CI 任务在 1.82 上编译过。本批次不修任何生产逻辑。

#### Changed

- **覆盖率门禁改用生产口径**（`.github/workflows/ci.yml`、新增
  `scripts/check_coverage_caliber.py`）：`cargo llvm-cov` 把 `src/*.rs` 内的
  `#[cfg(test)]` 段本身计入分母（`src/lib.rs` 1824 行里测试段从第 64 行起占 1760 行），
  于是「新增测试」会**推高**覆盖率数字、「新增未覆盖的生产代码」反被稀释：门禁显示
  92.99%，剔除测试段后的生产代码只有 88.65% —— **门禁绿 ≠ 生产代码达标**。
  `--ignore-filename-regex` 只能按文件路径排除，管不到 `src/` 内部的测试段，
  故改由脚本从 lcov 数据剔除测试段后重新统计。
  阈值 `--fail-under-lines 90`（llvm-cov 口径）随之废弃，改为脚本口径的
  `--min 88`（当前基线 88.65% / 本次实测 88.76%，余量约 32 行）。

- **退出码矩阵用例不再自证**（`cli/tests/cli_e2e.rs`）：原用例断言的是函数内硬编码的
  局部数组 `[(0, "成功"), (1, "校验未通过"), ...]`，与 `CliError::exit_code` 无任何
  链接 —— 删掉矩阵里任一码、或改坏 `exit_code()` 的映射，它都照样绿。
  现改为读 `README.md` 的退出码表格，断言其**连续覆盖 `0..=7`**（无缺号、无多余）。
  守的是文档侧契约（README 那张表是脚本作者判分支的依据）；`kind → 退出码` 的映射
  由 `cli/src/output.rs` 的 `exit_code_matrix` 单元测试逐个钉住，不在此重复。

- **CI 卫生**（`.github/workflows/ci.yml`）：
  - `Test` 步骤加 `--locked`：`Cargo.lock` 已提交，CI 必须与它一致，否则
    「本地能过、CI 红了」无解。
  - 新增 `Doc tests` 步骤（`cargo test --workspace --doc`）：实测
    `--all-targets` **不跑 doctest**（输出里没有 `Doc-tests` 段），而 README 声称
    「单元 + 集成 + 文档」全跑。
  - `cargo-audit` 改用 `taiki-e/install-action@cargo-audit`：此前
    `cargo install cargo-audit --locked` 要在三个 runner 上各从源码编译一遍
    （连续两次卡在本步骤 exit 101），且未固定版本 —— 上游换新版即整条 CI 红。
  - `cargo audit` 加 `--deny warnings`：默认只报 vulnerability，
    unmaintained / yanked 不失败。

- **新增 MSRV job**（`.github/workflows/ci.yml`）：`rust-version = "1.82"` 写在三个
  `Cargo.toml` 里、README 与 CONTRIBUTING 也对外承诺 1.82+，但此前**没有任何任务在
  1.82 上编译过** —— 依赖任一 minor 抬高 MSRV 都会让这个承诺静默失真。
  该 job 只 `check` 且**不带 `--all-targets`**：`rust-version` 承诺的是「下游能否编译
  本 crate」，而下游构建的是 lib + bin；带上 `--all-targets` 会把 criterion /
  assert_cmd 等 dev-dependencies 拉进来，它们的 MSRV 通常高于生产依赖，
  属于本仓库自己的开发工具链问题，不该让对外承诺失真。

- **golden 刷新加 CI 守卫**（`core/tests/integration.rs`）：`NCTOOL_UPDATE_GOLDEN`
  命中即写文件并 `return`，跳过该函数的**全部**断言 —— 21 组 golden 会静默退化成
  「跑得通即通过」。当前 workflow 没有设这个变量，但 `env:`、`.cargo/config.toml`
  或某个 runner 的默认环境都可能把它带进来，一旦带进来没有任何东西会报错。
  现加前置守卫：`CI` 存在时直接 panic；本地刷新路径不受影响。

- **覆盖率相关表述全面对齐**（`README.md`、`docs/CONTRIBUTING.md`、`docs/archive/legacy/RELEASE.md`、
  `docs/archive/legacy/ROADMAP.md`、`docs/PROJECT_STATUS.md`）：此前文档与 CI 对「覆盖率是否阻断」
  自相矛盾 —— `CONTRIBUTING.md:28` 写「非阻断」而**同一文件** `:74` 写「阻断」，
  `README.md:589`、`RELEASE.md:37` 也写「非阻断」，而 `ci.yml` 早已移除
  `continue-on-error`。按文档行事的人会把红的 coverage 当噪音合并，等于从语义上把
  门禁又拆掉。现统一为「阻断」，连同上面那条口径变更一起改：
  - 本地复现命令换成 `cargo llvm-cov ... --lcov` + `check_coverage_caliber.py` 两行；
    「上调阈值改哪里」由 `ci.yml` 的 `--fail-under-lines` 改为脚本的 `--min`
  - `CONTRIBUTING.md` §4 测试矩阵**去掉硬编码项数**（同一份文档曾同时存在
    344 / 516 / 492 三个数字），指向 CI job summary；补上此前漏列的
    `tests/extract_invariant.rs`，并标注 `--all-targets` 不跑 doctest
  - `ROADMAP.md` §0 TL;DR 与 `PROJECT_STATUS.md` §0/§4/§8 更新到最新实测，
    并在两处历史记录旁标注「09-18 口径更正」，避免旧数字被当现状读
  - README 与 CONTRIBUTING 的本地质量门命令块补 `cargo test --workspace --doc`，
    与 CI 的单列步骤一致

#### 测试

- 覆盖率脚本对重跑后的 `lcov.info` 实测：生产口径 **88.65%**（4319/4872），门禁通过；
  同时打印 llvm-cov 原始口径 92.99%（9538 行中 6908 行位于 `#[cfg(test)]` 段）
  与被剔除的行数，便于核对口径差异。
- golden 守卫**反向验证**：`CI=1 NCTOOL_UPDATE_GOLDEN=1 cargo test -p nctool-core
  --test integration` → FAILED（panic 于守卫，且在写文件之前）；去掉 `CI` 后本地
  刷新路径仍可用，21 组基线字节未变（`git status tests/golden/` 干净）。
- `exit_code_matrix_in_docs_is_complete` 改为读 README 断言后，对当前 README 通过；
  删改表格任一码即红。
- `cargo audit --deny warnings` 本机实测 exit 0（cargo-audit 0.22.2，112 个依赖）。
- CI 变更无法在本机验证，需下一次 push 后看 run 结果（尤其 MSRV job 与
  `install-action` 步骤）。

### 批次三：Web UI 加固

#### Fixed

- **UI 存储型 XSS**（`ui/index.html` + `cli/ui/index.html`，两份同步）：`esc()` 只转
  `&` `<` `>`，**不转引号**，而 `tplCardHtml` / `fieldHtml` / `renderMachineSel` 等处的
  插值点连 `esc()` 都没调。于是模板文件名、`{# PARAMS: #}` 里的参数名、机床 TOML 的
  vendor/model 中只要有一个 `"`，就能逃出属性边界加出事件处理器
  （`data-tpl="a"onerror=alert(1) x="`）—— 打开 `nctool ui` 即执行。
  `esc()` 补 `"` `'`，并逐点补全全部插值位置（属性值与文本两处都要）。
  另新增 `selEsc()`：`querySelector('[data-param="…"]')` 的转义规则与 HTML 不同
  （要转 `\` 和 `"`，不是转成 `&quot;`），写入侧用 `esc`、回读侧用 `selEsc`，
  两侧才指向同一个 DOM 属性值 —— 否则「名字带引号的参数」会静默收集不到。

- **目录符号链接的逃逸与成环**（`cli/src/context.rs`）：`Path::is_dir()` 跟随符号
  链接，而逃逸校验（`canonicalize` + `starts_with(root)`）此前**只在文件分支**执行，
  目录层既无校验也无 visited 集合。现目录分支同样校验，并用 `BTreeSet<PathBuf>`
  记录已进入的规范化目录以断开环。

- **server 模式数字选项发成字符串**（`ui/index.html`）：`input.value` 是字符串，
  `normalizeOpts` 此前只在 demo 分支被调用，server 分支直接 `JSON.stringify` 发出，
  而后端按 `as_u64()` 取值 → 在「步进」框里改一个数字就「渲染失败」。
  输入处理器改存 `Number`，`API.render` 出口再统一过一次 `normalizeOpts`。

- **清单未提及的模板被静默隐藏**（`core/src/manifest.rs`）：`TemplateMeta` 用
  `#[derive(Default)]`，给出 `visible = false` / `output_extension = ""`，而 serde
  路径（`default_true` / `default_extension`）给出 `true` / `".NC"` —— 同一个「缺省」
  两处含义不同。`resolve` 对清单未提及的模板走 `unwrap_or_default()`，拿到的正是
  派生那版：往 `templates/` 放一个新 `.j2` 而不加清单条目，用户列表里看不到它，
  输出文件名还丢扩展名，且全程不报错。改手写 `impl Default`，与 serde 对齐。
  （报告把它归在 P1-4、未指定批次；因与批次一「静默出错」同类，随本批次一起做。）

- **HTTP 分类过滤缺「切槽」**（`cli/src/server.rs`）：`parse_category` 只有五个分支，
  而 `cli/src/cli.rs::CategoryArg` 有 `Grooving` —— `?category=grooving` / `?category=切槽`
  被 **400 拒绝**，CLI 侧却正常；前端 `CATS` 也缺这一项，切槽模板只在「全部」里出现、
  分类计数永远对不上。补齐分支，并遍历 core 全部分类加测试防再漏。
  另：`?category=`（空值）此前同样 400 —— 前端清空分类筛选就会撞上，现视为「不筛选」。

- **`options.format` 类型错误静默回退**（`cli/src/server.rs`）：`and_then(as_str)` 把
  「键缺失」与「类型错误」混为一谈，`{"format": 1}` / `true` / `[]` 都落到 None 分支
  被**静默按 gcode 生成**，调用方以为选项生效。同函数的 `get_bool` / `get_u32` 早已
  对类型错误返回 400，此处是唯一漏网。现区分二者，类型错误 400。

- **API 响应与错误体泄露绝对路径**（`cli/src/context.rs`、`cli/src/server.rs`）：
  文件模板的兜底描述是 `format!("文件模板: {}", canonical.display())`，经
  `/api/templates` 原样返回给浏览器 —— `curl` 一次就拿到全部模板的绝对路径（含用户名
  与项目结构）。现改用**相对键**（也正是用户要传给 CLI 的那个名字，比路径更有用）。
  500 响应同样不再回显内部正文（`build_registry` 的失败消息含绝对路径），改为泛化
  文案 + 详情写 stderr；400 仍回显（那是调用方能据以修正的模板语法/行列号，且无路径）。

#### Changed

- **`cli/src/server.rs` 模块头与 CSP 注释同步**：模块头仍写「非回环由命令层打印警告
  （本模块不做判断）」，而 `listen_addr` 早已**直接拒绝**非回环地址 —— 照那句话改回去
  会把这个决定悄悄撤销，故更正并写明沿革。CSP 注释补上「`'unsafe-inline'` 这条取舍
  成立的前提是页面里没有可注入的插值点」，以及改前端插值时必须一并复核。

#### 未做（附理由，非遗漏）

- **CSP 去掉 `'unsafe-inline'`**：内联 `<script>`/`<style>` 需外置为同源文件
  （或每响应注入 nonce），属独立改造。本轮先消除注入点本身。
- **body 读超时 / 并发上限（P1-19）`、每请求全树 `stat`（P1-18）**：tiny_http 0.12
  不暴露底层 socket，`set_read_timeout` 无从下手；换独立线程读又要把 `Request` 移进
  线程才满足 `'static`，而响应必须由持有 `Request` 的一方发出 —— 得重做 `serve`
  的请求循环。两者同属服务层改造，宜单独排期，不夹在安全修复里。

#### 测试

- 新增 6 项测试：`core` 1（清单缺省与 serde 对齐）、`cli` 3（分类覆盖全 core 变体 /
  空分类不筛选 / format 类型错误）、`cli` 2 项 `#[cfg(unix)]`（目录链接成环被断开、
  逃逸目标被跳过）。
- **浏览器实测**（非仅单测）：起 `nctool ui` 后在真实页面验证 ——
  ① 参数名含 `x"onmouseover="window.__XSS_ATTR=1` 的模板：无注入元素、属性回读
  与原名一致、`querySelector` 能回找到该输入框并收走其值；同页面用**旧** `esc()` 拼
  同样的 HTML 则确实注入 → 证明漏洞真实且已修。② 「步进」改 25 → `N0025/N0050/N0075`，
  渲染成功（此前 400 渲染失败）。③ 32 个模板正常列出、参数表单与校验提示正常。
- `cargo fmt --all --check`、`cargo clippy --workspace --all-targets -- -D warnings`
  干净；workspace 全量通过：**540 项**（Windows，2 项 `#[cfg(unix)]` 不参与）/ 542 项（unix）。

### 批次四：一致性清理

#### Fixed

- **同名文件模板被静默替换为注册表模板**（`cli/src/commands/render.rs`）：模板目录里
  已有 `a.j2` 时，`nctool --template-dir templates render /tmp/other/a.j2` 会**渲染
  `templates/a.j2` 的 G-code** —— 用户以为渲染的是自己给的文件。原因：命中同名时
  直接 `return` 复用注册表条目，而注册表里那个是**另一个文件**。不报错、不告警，
  只是产出另一份程序。现改为：路径指向的就是注册表里那个文件时照旧复用；
  否则把用户给的文件注册进去，注册名退化为完整路径（不可能与目录模板名冲突）。
  反向验证：还原旧逻辑后新测试 FAILED。

- **`validate --format json` 遇断管道 panic**（`cli/src/commands/validate.rs`）：该分支
  用 `println!` 输出，是全仓**唯一**绕过 `write_stdout_quiet` 的地方。下游提前关管道
  （`nctool validate <大模板> --format json | :`）时 `println!` 以 panic 收场 ——
  实测退出码 **101**，而退出码矩阵承诺的是 1。现走 `write_stdout_quiet`
  （已改为 `pub(crate)`），实测退出码 **1**。

- **include 闭包的同名规格取了最远的那份**（`core/src/registry.rs`）：
  `collect_include_closure` 先递归进被引用模板、再并入它自己的规格，而合并策略是
  「先到先得」—— 于是 `main → child → grandchild` 且 child 与 grandchild 对同名参数
  声明了不同 `options` 时，采用 **grandchild** 的，与文档承诺的「更接近主模板的声明
  优先」相反。不报错，只是静默按另一套约束校验。现改为先入表、后递归。
  反向验证：还原旧顺序后新测试报 `left: [grandchild]`，确认复现报告所述。

- **清单孤儿条目零检测**（`core/src/manifest.rs`、`cli/src/context.rs`）：清单里写了、
  但没有对应模板文件的键，其 `params`（白名单/区间）、`visible`、`machine`、
  `output_extension` 全部**静默失效** —— 看起来约束齐全，实际一条都没上。写成
  `turning/undercut.j2`（实际是 `undercut_fs.j2`）这类笔误尤其容易发生。
  项目已为「规格写了个不存在的参数」设了 `SpecInert` 警告，此处是对称的补口：
  新增 `TemplateManifest::orphan_keys`，注册表加载时对未命中键打 `warning:`（不阻断）。
  本仓库自身的清单实测无告警。

- **稀疏覆盖只能设、不能清**（`core/src/manifest.rs`）：`ParamOverride` 的约束字段
  是 `Option<T>`，一旦从 `variables.yaml` 或头部继承到值就回不到 `None`——变量库给
  `U_Q` 声明 `min: 0` 后，**所有**模板都被套上，某模板确实需要负值也只能去改变量库，
  那会波及全部模板；继承来的 `derive` 同理，想关掉没有别的办法。
  现把 `default` / `min` / `max` / `unit` / `options` / `required_if` / `derive`
  改为 `Option<Option<T>>`（配 `double_option` 反序列化），三种写法语义区分开：
  **没写** = 沿用继承值、**写 `null`** = 清空该条继承、**写值** = 设值；
  `options: []` 与 `options: null` 等价。`templates/README.md` 与
  `docs/ARCHITECTURE.md` / `docs/SYSTEM_DESIGN.md` / `docs/ARCHITECTURE_REVIEW.md`
  同步更新（原先都写作「字段全为 `Option`，能区分没写与写成默认值」）。

- **数值过滤器的三处边界**（`src/filters.rs`）：
  - `nc_fixed` / `nc_strip` 不归一负零：`-0.0 | nc_fixed(3)` → `-0.000`、
    `-0.0 | nc_strip` → `-0`。`nc_signed` 早已归一，同一份逻辑换个过滤器就输出
    不同字节，而控制器对负零的处理并不一致。现三个过滤器统一归一。
  - `nc_signed` 的归一放在**舍入之前**：`-0.0001` 保留 3 位就是 `0.000`，
    判零漏掉它，仍输出 `-0.000`，与本节「-0.0 归一到 +0.000」的承诺相悖。
    改为按小数位定值后再判零（用字符串判零，不再做一次浮点运算 —— `-0.0005`
    这类值在「乘再除」里会抖到另一侧）。
  - `nc_pad` 上界检查差一：`i64::MAX as f64` 恰为 2^63（`i64::MAX` 本身在 f64
    里不可表示），用 `>` 会让 2^63 通过检查、被 `as i64` **饱和**成 `i64::MAX` ——
    静默输出一个错误的程序号，正是该检查要拦的东西。`>` 改 `>=`。
  - `nc_pad` 的文档说「输入为浮点数时截断小数部分取整」，实现却是**拒绝**小数
    （截断会让 `n=1.7` 静默产出 `N0001`）。改文档，并在 `nc_fixed` 上写明
    **舍入模式是就近取偶**、与 minijinja `round` 的「半远离零」在 .5 附近相反 ——
    前者是对齐源项目 Python `f"{v:.2f}"` 的有意选择，要统一语义请改模板而非改这里。

#### Changed

- **`BUILTIN_GLOBALS` 只列 minijinja 真正提供的全局**（`src/extract.rs`）：名单里此前
  有 `lipsum` / `cycler` / `joiner` —— 那是 Jinja2（Python）侧的东西，minijinja
  不提供，本库也没有 `add_global` 注册它们。后果不是「多排除几个名字」，而是
  **恰好叫这些名字的模板参数**被静默排除出未声明集合，必选与类型校验一起失效；
  而真去写 `{{ lipsum() }}` 的模板在渲染期照样报未定义，名单一点忙没帮上。
  新增测试用 `minijinja::Environment` 实证这三个名字渲染即报错。

- **`{type: integer}` 的超范围值不再静默饱和**（`core/src/model.rs`）：`as i64` 对
  超范围值返回 `i64::MAX` 而不是报错，于是 `{type: integer, value: 1e20}` 被换成
  9223372036854775807 —— 一个完全不同的数，而 `is_finite() && fract() == 0.0`
  两道检查都放行。现过界报错；`ParamValue::as_integer` 对超界 `Number` 返回 `None`
  而不是饱和值。（`i64::MAX as f64` 恰为 2^63，合法区间是 `[-2^63, 2^63)`。）

- **NaN 不再额外刷一条 `NotInteger`**（`core/src/validate.rs`）：`NaN.fract()` 仍是
  NaN，而 `NaN != 0.0` 为真，整数约束照样命中 —— 同一个值报两条错
  （NonFinite + NotInteger）。既是噪声，也把宽松模式「唯一硬失败项 = NonFinite」
  这个承诺搅浑。区间检查不需要这层保护（NaN 与任何数比较都是 false）。

- **`{# PARAMS: #}` 块超限不再静默截断**（`core/src/manifest.rs`）：块在第 200 行
  仍未闭合时，其后的参数声明被**静默丢弃** —— 类型/白名单/条件必选全不生效，
  而用户只当模板本来就没写。现产出一条告警。

- **`ManifestFile` 补 `deny_unknown_fields`**（`core/src/manifest.rs`）：带 `templates:`
  的形式只有这一个合法顶层键，此前多写/拼错会被静默忽略 —— 用户以为改的是清单、
  实际什么也没改。`from_yaml` 的注释一直声称有这条保护，但结构体上没有。

- **`check_docs_links.py` 接入 CI**（`.github/workflows/ci.yml`）：`CONTRIBUTING` §3
  早已文档化其用法，却始终没有调用点 ——「工具闲置」等于这道门不存在。脚本对坏链接
  exit 1（已实测），可直接当门禁；与对拍脚本一样只在 ubuntu 跑一次。

- **两处与实现不符的注释**（`src/extract.rs`、`cli/tests/cli_e2e.rs`）：前者断言
  「minijinja 内部自带 JIT 编译缓存」，与 `render` 每次都走一遍
  `template_from_named_str` 的实际调用形式对不上，属无据的说法，改为陈述本项目
  自己的不变量；后者写「本仓库根目录下唯一的临时目录」而实现用 `std::env::temp_dir()`，
  且同一段注释的下一句就在说「不污染仓库」。

#### 测试

- 新增 5 项：`explicit_path_that_collides_with_registered_name_wins`（含反向用例：
  同一文件不该改名）、`include_closure_spec_precedence_is_nearest_to_main`、
  `orphan_keys_reports_unmatched_entries`、`manifest_null_clears_inherited_field`、
  `template_refs_traverse_every_nested_body`（11 个分支的表驱动用例，见下）。
- 新增 4 项数值过滤器用例（`src/filters.rs` 此前**没有测试模块**）。
- 新增 5 项：`builtin_globals_are_exactly_what_minijinja_provides`（含 minijinja 实证）、
  `oversized_integer_is_rejected_not_saturated`、`nan_does_not_also_report_not_integer`、
  `manifest_rejects_unknown_top_level_key`、`params_block_beyond_scan_limit_warns`。
- **反向验证**：上述各项均临时还原实现后确认 FAILED 再恢复。数值过滤器三项的失败
  输出分别是 `left: "-0.000"` / `right: "0.000"`、`left: "-0.000"` /
  `right: "+0.000"`、以及 2^63 未报错。
- **P1-20 覆盖缺口**：`collect_template_refs_stmt` 的嵌套语句体分支此前零覆盖
  （lcov 显示 for-else、if 的 else 体、with / set-block、autoescape / filter-block /
  block / macro / call-block 全部 `DA:...,0`）。该函数是**组合模板必选参数不漏检**
  的入口，漏一个分支 = 用那种语法写的子模板参数完全不校验。补齐后 `src/extract.rs`
  第 158–202 行已全部覆盖，生产口径从 88.65% 升至 **89.49%**。
  实现在补齐前即为正确，本项是纯覆盖缺口。
- 孤儿键告警用真实 CLI 验证（临时模板目录 + 清单里一条拼错的键）：
  `templates list` 打出一条 `warning: 清单条目 turning/undercut.j2 未匹配到任何模板文件…`，
  且只报未命中的那条。
- workspace 全量 **554 项**通过（含 golden 逐字节比对 —— 无模板依赖旧的负零输出）。

### 批次五：打通扩展接缝（第四轮审查 P0-1）

> 依据 `docs/CODE_REVIEW_2026-09-19.md`。本批**不改变任何运行时行为**，只把
> 「新增枚举变体时编译器是否会提醒你漏改」从事后排查变成编译期错误。

#### Changed

- **`ParamKind` 的类型名解析收敛到唯一入口**（`core/src/model.rs`）：新增
  `impl FromStr for ParamKind`（接受 `aliases()` 的英文别名与 `label()` 的中文名），
  清单解析处的那份字符串表（`core/src/manifest.rs::parse_kind_name`）改为转发。
  原先同一套中英文类型名在两处各写一遍，新增类型漏改一处即「模板头部写了但报未知类型」。
- **`ParamKind::matches` 去掉 `_ => false` 兜底**（`core/src/model.rs`）：原写法是
  `match (self, value)` + 通配兜底，新增变体会**静默把新类型变成"拒绝一切取值"**，
  编译器一声不响。现按 `self` 穷尽展开，新增变体必须逐类表态。语义与原先逐值一致。
- **`OutputFormat` 后处理分支改 `match`**（`core/src/pipeline.rs`）：原先是
  `if opts.format == OutputFormat::Text { return }`，新增第三种格式会静默落到
  G-code 后处理（加行号 / 清 ASCII）里。现为穷尽 `match`。
- **宽松模式的保留集合改由 `IssueKind::is_hard_fail()` 决定**（`core/src/validate.rs`）：
  新增穷尽匹配的 `is_hard_fail()` 与 `ValidationReport::downgrade_soft_errors()`，
  管线改走新路径。原 `downgrade_errors_except(&[NonFinite])` 是**白名单反向**，
  新增问题类别会被默认降级；该方法保留但文档指向新入口。
- **分类表收敛到 core**（`core/src/registry.rs`、`cli/src/server.rs`、`cli/src/cli.rs`）：
  新增 `TemplateCategory::ALL` / `aliases()` / `dir_names()` / `from_dir_name()` /
  `FromStr`。HTTP 的 `parse_category` 与清单的 `classify_by_path` 均改为转发，
  `CategoryArg::from_core` 改为直接取 `TemplateCategory::label()`（原先是第三份中文副本）。
  `classify_by_path` 的文档表补上此前遗漏的 `grooving` / `groove`。

#### Fixed

- **golden 刷新命令漏 `--workspace`**（`README.md`、`docs/CONTRIBUTING.md`）：文档写
  `NCTOOL_UPDATE_GOLDEN=1 cargo test`，而 golden 测试在 `core` 包 —— 裸 `cargo test`
  只跑根 crate，命令成功、**零文件变更、且不报错**，正好踩中本项目反复警告的
  workspace 陷阱。现补 `--workspace`。

#### 测试

- 新增 3 项守卫：`param_kind_registry_is_complete`（`ALL` 长度与穷尽匹配的变体数对拍
  + 中文名/全部别名可解析回自身 + 别名表非空）、
  `downgrade_soft_errors_keeps_hard_fail_only`（`is_hard_fail` 逐类断言 + 与旧白名单
  路径行为等价）、`category_arg_covers_every_core_category`（`CategoryArg::value_variants()`
  与 `TemplateCategory::ALL` 对拍）。
- **反向验证**（临时改坏实现 → 确认 FAILED → 恢复）：把 `NonFinite` 的 `is_hard_fail`
  改成 `false` → 守卫测试报「NaN/Inf…也必须阻断」；删掉 `enum` 别名 → 既有解析测试报
  `'enum' 既不是已知类型`；`ALL` 少登记一个变体 → 分类守卫报 `left: 6 / right: 5`。
- workspace 全量 **557 项**通过，`cargo fmt --all -- --check` 与
  `cargo clippy --workspace --all-targets -- -D warnings` 均通过。

### 批次六：前后端接口集合对拍（第四轮审查 P0-2）

> 依据 `docs/CODE_REVIEW_2026-09-19.md` §4 批次 B 第 1、2 项。

#### Changed

- **`runBatch` 不再直接调 `API.mock`**（`ui/index.html`、`cli/ui/index.html`）：改为走
  `API.partGenerate` 出口。此前服务模式下会绕过后端、用前端 JS 复刻的引擎产出 G-code，
  而后端 `/api/part/generate` 并不存在。demo 模式（`file://`）仍落到 mock，行为不变。
  > 复核更正：该入口在服务模式本就被 `API.mode` 守卫挡住（不可达），故实际风险是
  > 「潜伏的契约漂移」而非「静默产出假程序」；报告已相应降级为 P1。

#### Added

- **`scripts/api_routes.json`**：前后端接口集合的**单一来源**（7 条后端路由 + 1 条
  `frontend_only` 显式豁免）。新增端点必须同时改三处：后端 `route()` 路由臂、本文件、
  前端 API 封装，漏改任一处即红。
- **`scripts/check_api_parity.mjs`**：提取两份 HTML 里所有 `/api/...` 字符串字面量，
  断言每一个都在 fixture 中登记；`frontend_only` 豁免项必须写明 `reason`（防无限期豁免）。
  已接入 `.github/workflows/ci.yml`，与 param 对拍并列（仅 ubuntu 跑一次）。
- **Rust 侧守卫 `api_routes_are_routable`**（`cli/src/server.rs`）：`include_str!` 消费
  同一份 fixture，逐条断言 `route()` 不返回「未知接口」。只看是否未知，不校验状态码
  —— fixture 用最小请求体，400（参数不全）是正常的，404 + 未知接口才是契约漂移。

#### 测试

- **双向反向验证**：删掉 fixture 里的 `/api/part/generate` 豁免 → 前端门禁报
  「前端使用了 /api/part/generate，但未登记」×2；往 fixture 加一条后端没有的接口 →
  Rust 测试报 `route #7: GET /api/nonexistent_probe 未登记到 route()`。
- workspace 全量 **558 项**通过；`node scripts/check_api_parity.mjs` 通过；
  `ci.yml` YAML 解析校验通过。

### 批次七：三处静默正确性（第四轮审查批次 C）

> 依据 `docs/CODE_REVIEW_2026-09-19.md` §3.2 的 P1-1 / P1-2 / P1-3 / P1-11。

#### Fixed

- **`ParamKind::Integer` 补 i64 范围检查**（`core/src/model.rs`）：`matches` 此前只判
  `is_finite() && fract() == 0.0`，而 `1e20` 两条都满足 —— 校验放行，但 `as_integer`
  会把它**饱和**成 `i64::MAX`。同一文件的 `coerce_tagged` 与 `as_integer` 早已有
  `[I64_MIN, I64_MAX)` 守卫（第三轮 P2-6 修的），唯独类型检查漏掉。现与它们同口径。
- **宽松模式的派生失败并入硬失败**（`core/src/validate.rs`、`core/src/pipeline.rs`）：
  `DeriveFailed` 是 Error 级，但宽松模式此前把它降级成 Warning，报告说"可以出程序"，
  紧接着 `derive::apply` 又返回 `Err` —— 报告被丢弃、调用方一个字都拿不到，而文档
  声称"唯一硬失败是 NaN/Inf"。现：
  - `IssueKind::is_hard_fail()` 把 `DeriveFailed` 并入（与它自己的级别说明一致）；
  - 新增 `ValidationReport::has_hard_fail()`，管线据此判定，不再写死 `NonFinite`
    —— 将来新增硬失败类别不必改调用点；
  - `generate_lenient*` 的文档承诺同步改为"两类"。
- **清单键规范化碰撞不再静默覆盖**（`core/src/manifest.rs`、`cli/src/context.rs`）：
  `./turning/a.j2` 与 `turning/a.j2` 归一后同键，后者覆盖前者且不报错 —— 用户以为
  两个条目都在生效。`TemplateManifest` 现记录冲突对（`duplicate_keys()`），
  CLI 加载时与孤儿键一并打出 warning。对照变量库对重复变量是直接报错的。
- **有限性闸门改为 fail-closed**（`core/src/registry.rs`）：`find_non_finite` 里的
  `try_iter().ok()?` 会把"遍历失败"折叠成"没找到非有限数"，即**防 NaN 的最后一道
  闸门在异常路径上静默放行**。现返回 `Result<Option<String>, String>`，
  `ensure_finite_context` 对扫描失败同样拒绝渲染。

#### 测试

- 新增 3 项：`integer_kind_rejects_out_of_i64_range`、
  `generate_lenient_treats_derive_failure_as_hard_fail`、
  `normalized_key_collision_is_reported`；并强化
  `downgrade_soft_errors_keeps_hard_fail_only`（补 `has_hard_fail` 与
  `is_hard_fail` 同口径断言）。
- **反向验证**：临时还原四处实现 → 4 项测试全部 FAILED（`integer_kind_…`、
  `downgrade_soft_errors_…`、`generate_lenient_treats_…`、`normalized_key_…`）→
  恢复后全绿。
- **顺带修掉一个此前潜伏的 CI 红**：`RUSTDOCFLAGS="-D warnings" cargo doc` 报
  「links to private item」（`ParamKind::aliases`、`TemplateCategory::dir_names`、
  `Self::aliases`）与 CLI 侧未解析链接 —— 批次五引入的文档链接问题，
  当时只跑了 fmt/clippy/test，没跑 doc。现已修正。
- workspace 全量 **561 项**通过；`cargo fmt --all -- --check`、
  `cargo clippy --workspace --all-targets -- -D warnings`、
  `RUSTDOCFLAGS="-D warnings" cargo doc --workspace --no-deps` 均通过。

### 批次八：让 golden 基线重新有信息量（第四轮审查批次 B 第 3 项）

> 依据 `docs/CODE_REVIEW_2026-09-19.md` §3.1 的 P0-3。

#### Added

- **3 组负向 golden**（`tests/golden/neg_*.report.txt`）：`neg_missing_required`
  （drill_cycle 只给 x）、`neg_type_mismatch`（tool_num 传字符串）、
  `neg_out_of_range`（prog = 99999 越界），由新用例
  `negative_cases_freeze_failure_reports` 冻结。此前 21 份报告恒为
  「校验通过：无问题」，**报告维度只有 1 份信息量**，把 `Missing` 误标成警告或
  把消息里的参数名写错不会有任何测试发现。现在失败路径的级别、参数名、
  行号定位与文案全部纳入基线。
- **`machine_dimension_is_currently_flat`**：显式守住"机床维度当前不产生差异"。

#### 说明：为什么没有去"制造"机床差异

复核后确认 21 份 `.nc` 只有 7 份不同内容**不是测试写错**：三个预设只在
`max_spindle_rpm` / `machine_type` / `axes` / `vendor` / `model` 上不同，而这些键
**没有任何内置模板引用**；模板真正用到的 `program_prefix` / `units` /
`coordinate_system` / `feed_mode` 等全部来自共享的 `generic_config()`。
要让输出分化只能凭空发明机床编程约定 —— 那不是测试修复，是伪造数据。

故改为把这份偶然的重复变成**受守的断言**：任一预设改动模板可见的键，该用例即红
并提示"机床维度开始分化，请改成真正分维并复核 `_wfl` / `_index` 基线"；
它同时拦住"为了消重而删掉重复基线"——删了就没有东西能拦住预设的模板可见改动。

#### Changed

- 修正 `core/tests/integration.rs` 的过期注释（"6 内置模板 × 3 = 18 组"实为
  7 × 3 = 21）与 `golden_files_are_lf_only` 的文件计数（42 → 45）。
- 同步 `README.md` / `docs/PROJECT_STATUS.md` / `docs/archive/legacy/ROADMAP.md` 的 golden 数量。

#### 测试

- **反向验证**：临时改掉校验报告里 `Missing` 的文案 → `negative_cases_freeze_failure_reports`
  FAILED；临时把 `IndexMs40` 的 `coordinate_system` 改成 `G55` →
  `machine_dimension_is_currently_flat` FAILED。恢复后全绿。
- 用刷新模式重建基线后 `git status tests/golden/` 只显示 3 个**新增**文件，
  既有 42 份**逐字节未变** —— 反向证明提交的基线是可复现的。
- workspace 全量 **563 项**通过；fmt / clippy / doc 门禁均通过。

### 批次九：去重与测试诚实性（第四轮审查批次 D 的一部分）

> 依据 `docs/CODE_REVIEW_2026-09-19.md` §3.2 的 P1-7 与 §3.3 的 P2-10 / P2-14 / P2-33。

#### Changed

- **校验报告的 JSON 形状收敛到 core**（`core/src/validate.rs`、`cli/src/output.rs`）：
  新增 `ValidationReportJson` / `ValidationIssueJson` 与 `ValidationLevel::as_str()`，
  CLI 侧只保留 `output::report_json` 一个薄封装。此前
  `cli/src/server.rs::validation_json` 与 `cli/src/commands/validate.rs::report_json`
  **逐字段各写一遍**（连 `level` 的三分支映射都各写一份），两份漂移会让 Web UI 与
  CLI 对同一份报告给出不同形状，而两边都没有测试能发现对方变了。
- **机床清单枚举收敛到 core**（`core/src/machine.rs`）：新增 `MachineEntry` 与
  `MachinePreset::entries()`，把「预设 + 配置文件自定义、按预设 id 去重」的规则
  从 HTTP（`server.rs::machines_list`）与 CLI（`commands/machine.rs::list`）两处
  合并为一处；展示字段仍由调用方决定（HTTP 带完整 `config`，CLI 走
  `MachineEntry::display_line`）。
- **删掉两处死代码**（`src/extract.rs`）：`c.declare("loop")` —— `record` 对
  `RESERVED_NAMES`（含 `loop`）在入口即 return，早于任何 `is_local` 查询，
  该调用可证明无任何可观察效果；以及 `Collector::new` 从未使用的 `_src` 参数。

#### 测试

- **`all_math_filters_render` 由弱断言改为精确断言**（`tests/parsing.rs`）：原实现把
  9 个过滤器拼成一行再 `assert!(out.contains("2"))`，`"2"` 可由 `sqrt(4)` /
  `log10(100)` / `ceil(1.5)` 任一个满足，最后两条还重复检查同一个 `"2"`。
  改为逐个按数值比较后**立刻抓到 `sqrt(4)` 渲染成 `"2.0"` 而非 `"2"`** ——
  旧断言之所以"通过"，正因为它只看子串。
- **fuzz 补返回值不变量**（`src/lib.rs`）：`fuzz_random_parse_extract_no_panic` 此前是
  `let _ = extract_variables(&ast);`，只验证"不 panic"，易造成"提取器已被 fuzz 验证"
  的错觉。现补：变量名非空、`extract_variables` 按名去重、行列从 1 起、span 有序、
  `undeclared ⊆ all`。
- 新增 2 项守卫：`json_view_freezes_contract_fields`（冻结报告 JSON 的字段名与
  `level` 取值，属对外契约）、`entries_lists_presets_then_custom_without_duplicates`
  （重名的自定义机床必须被忽略，否则列表出现两个 `generic`）。
- workspace 全量 **565 项**通过；fmt / clippy / doc / 接口对拍门禁均通过。

#### 未做（附理由，不是遗漏）

- **服务层读超时 + 并发上限**：tiny_http 0.12 不暴露底层 socket，根治需重做 `serve`
  的请求循环，宜独立排期。
- **每请求全树 `stat`**：简单改成"只 stat 目录"会**漏掉就地编辑文件内容**
  （父目录 mtime 不变），缓存将返回过期模板；需 TTL 或显式刷新入口的设计取舍。
- **`extract.rs` 两套并行遍历合并**：**有意不做**。该文件最安全敏感（必选参数漏检
  = 撞刀级静默错误），合并属"改对了没收益、改错了很难发现"的重构。
- **`derived_names` / `invalidate_analysis` 可见性收窄**：`nctool-core` 已发布到
  crates.io，收窄 `pub` 是破坏性变更，并入下一个 minor 版本一起做。

### 零件级批量生成 `nctool part generate`（Backlog F4 #2 落地）

> 输入是 E5 真实零件走查（`docs/archive/legacy/REAL_PART_WALKTHROUGH.md` §5）暴露的三处局限。
> 该走查用 5 个内置模板手工串简化法兰盘，结论是「能拼出来，但手工串不可持续」：
> 行号每段重来、错误修一个报一个、公共参数每段重传。
> 本次把「串多道工序」这件事故化为一个命令。

#### Added

- **`nctool part generate`**（CLI）：读一份零件定义 JSON，按顺序渲染其中的全部工序，
  拼接为一份程序写出。新参数 `--out` / `--line-numbers` / `--header` / `--ascii` /
  `--strip-blank` / `--lenient`（与 `render` 同名同义）。定义形状：

  ```json
  {
    "name": "法兰盘",
    "default_machine": "generic",
    "params": { "part_name": "FLANGE" },
    "ops": [
      { "template": "program_header", "params": { "prog": 1001 } },
      { "template": "drill_cycle", "params": { "x": 21 }, "machine": "wfl_m65",
        "options": { "line_numbers": true } }
    ]
  }
  ```

  退出码：定义形状不合法 → 2；工序参数校验失败 → 1；定义文件读不到 → 3。

- **`core::part` 模块**（`core/src/part.rs`，新）：`PartSpec` / `PartOp` / `PartOpOptions` /
  `PartOptions` / `PartOutcome` / `OpOutcome` / `PartError` / `OpFailure`，
  以及 `resolve_machine`。编排逻辑（参数合并、选项合并、游标传递、失败聚合）
  全在 core，CLI 与 HTTP 共用同一份。

- **`POST /api/part/generate`**（`cli/src/server.rs`）：Web UI 的批量入口。
  请求体 `{"part": {...}}` + 顶层可选 `lineNumbers` / `addHeader` / `stripBlank` /
  `ascii` / `lenient`；响应 `data.results` 逐工序对齐（失败项带 `error`，
  整体未交付时成功项带 `skipped: true` 且不带 `output`）。

- **`GenerationOptions.line_number_start`** 与 **`GCodeGenerator::generate_with_cursor`**
  （`core/src/pipeline.rs`）：让「上一段用到哪个行号」可被调用方接续。
  `postprocess` 的返回值由 `String` 改为 `(String, u32)`（后者是续编游标）。

- **`ParameterSet` 的扁平/包裹双形态反序列化**（`core/src/model.rs`）。见下 Fixed。

#### Fixed

- **`ParameterSet` 把扁平 JSON 静默解析成空参数集**（`core/src/model.rs`）。
  `ParameterSet` 序列化为 `{"values": {...}}`，但**所有面向用户的入口**
  （`--params-file`、HTTP 的 `params`、前端表单、零件定义）用的都是扁平形式
  `{"x": 21}`。派生 `Deserialize` 只认前者，于是后者被解析成一个**空集**，
  不报错、不求救 —— 表现为「明明传了参数，却报必选参数缺失」。
  改为手写 `visit_map` 访问器接受两种形态（同名冲突时扁平键优先），
  序列化保持包裹形式不变（预设文件与 `--format json` 的形状不受影响）。

#### Changed

- **`/api/part/generate` 从 `scripts/api_routes.json` 的 `frontend_only` 豁免区移入
  `routes`**，并删除豁免说明 —— 契约口子按 T02 的约定收回。
- **解除 Web UI 批量弹窗的服务模式守卫**（`ui/src/32_script_ui.part.html`）：
  原先 server 模式下点「批量生成」直接 toast「服务模式暂不支持」，现在发真实请求。
- `README.md` 退出码表：删去「7 = `part generate`」这条现已无触发路径的说明。
- `docs/archive/legacy/ROADMAP.md`（D4 消项、F4 排期、新增 §F4.1）、`docs/PROJECT_STATUS.md`
  （存量记账、Backlog 表、D4 债务）、`docs/archive/legacy/REAL_PART_WALKTHROUGH.md`（新增 §6.1 收口）
  同步更新。

#### 一处刻意的语义分歧：CLI 与 HTTP 的失败呈现不同

CLI **全有或全无**：任一工序失败即退出 1 且**不写出任何文件**。
HTTP 则回 **200 + `data.results`**，逐工序给出结果。

理由是通道用途不同：CLI 直接落盘，半截程序上机床就是撞刀，因此宁可不产出；
HTTP 是给 Web UI 的 `runBatch` 用的，它需要按工序高亮错误，若只回一个整体错误
就无法告诉用户是哪一道坏了。为不违背事务语义，HTTP 侧成功但因整体失败而未交付的
工序标记 `skipped: true` 且**不带 `output`** —— 同样不吐半成品文本。
两端共用 core 的同一个编排器，差异只在错误如何呈现。

#### 测试

- `core/src/part.rs` **37 项**：参数继承与工序级覆盖、行号跨工序续编
  （含「程序号行不编号也不占游标」「整段无编号行则游标不动」两个边界）、
  失败聚合（两道全报）、事务性（`PartError` 无 `outcome` 字段，类型上就拿不到半成品）、
  机床解析（未知标识必须报错而非静默降级）、宽松模式下 NaN 仍硬拦且因继承而对每道工序都拦。
- `core/src/model.rs` **9 项**：锁定扁平/包裹两种反序列化形态、类型保真
  （扁平 `8` 仍是整数而非浮点）、冲突时扁平优先、序列化形状未变。
- `cli/src/server.rs` **8 项**：端点逐条覆盖，含「部分失败回 200 带 results」
  「`ops` 为空回 400 无 data」「`operations` 不是契约字段、应被拒」。
- `cli/tests/cli_e2e.rs` **7 项**（替换原先断言「exit 7 / not_implemented」的 2 项
  占位测试）：产物内容、行号严格递增、失败不落盘、一次报出全部失败工序、
  文件缺失退 3、JSON 通道两种形态。
- `cli/tests/cli.rs` 1 项：`part generate` 必须能解析 `--template-dir` 里的模板
  （证明它走的是读配置的 `Ctx` 路径，而非 completion 那种免配置快路径）。
- **反向验证**：`ParameterSet` 的扁平解析在修复前实测得到 0 个键；
  实测 `part generate` 在修复前把 `{"x":1.0}` 解析为空集。
- workspace 全量 **963 项**通过；fmt / clippy `-D warnings` / rustdoc `-D warnings` /
  `build_ui.mjs --check` / 接口对拍 / 参数对拍 / 文档链接锚点 / doc tests / `cargo audit`
  九道门禁均通过。
- **覆盖率实测 91.55%**（7418/8103，生产口径；门禁 89%，余量 2.55pt）——
  较 `part` 落地前的 91.29% **上升 0.26pt**，且新增的 `core/src/part.rs` 与
  `cli/src/commands/part.rs` **均未进入覆盖最低 10 文件**（最低者仍是
  `cli/src/commands/ui.rs` 18.75%，其生产本体为子进程启动路径）。
- **实跑验证**（不只单测）：三工位法兰程序带 `--line-numbers` 生成，行号
  `N0010`–`N0150` 严格递增无重复、`O1001` 正确不编号；坏定义退出 1 且产物文件不存在；
  HTTP 端点实测 200/400 两种失败形态与逐工序对齐。

### 发布包瘦身与发版流程定性（梳理 U-12 / U-22）

#### Changed

- **`nctool-tpl` 发布包收窄 59%**（`Cargo.toml` 的 `exclude`）：129 文件 / 553.2 KiB
  → **83 文件 / 229.1 KiB**（压缩后）。新增排除 `output/`（原型截图与参数样本，401 KB，
  本包最大冗余）、`scripts/`（CI 与 UI 构建脚本）、`templates/machines/`（CLI 侧配置数据）、
  `CODE_REVIEW_AND_DEV_PLAN.md` / `overview.md` / `gcm-diagnose.log` / `lcov.info` /
  `启动UI.bat`。

  选 `exclude` 而非 `include`：排除法在新增目录时不会误删必需文件 ——
  漏排是「包变大」，漏 `include` 是「包坏了」。**唯一必须随行的是 `templates/`**：
  `examples/demo.rs` 用 `CARGO_MANIFEST_DIR` 在**运行时**读
  `templates/turning/demo_gcode.j2`；根 crate 内没有任何 `include_str!`/`include_bytes!`。

  验证方式：`cargo package -p nctool-tpl --list` 复核收录，再解包 `.crate`
  跑 `cargo build` 与 `cargo test --no-run`（4 个测试二进制全部生成）均通过。

#### 记录（发版流程的两项实测结论，**未改代码**）

- **`release.yml` 一次 tag 只发布一个 crate**（三条 `Publish` 步骤各自带
  `startsWith(github.ref_name, ...)` 守卫，无串联）。因此 `tpl → core → cli`
  必须按序各推一次 tag，且 **core 必须早于 cli**：`cli` 依赖的
  `MachinePreset::entries` 加入于 2026-09-19 15:33，晚于 `nctool-core 0.3.0`
  的发布时刻（2026-09-18 05:01）。若跳发 core，`cargo publish -p nctool-cli`
  会解析到 crates.io 上的旧 core 并**编译失败**（实测 28 个错误）。

- **`nctool-cli` 发布包的 `cargo test` 必然失败，但 `cargo install` 不受影响。**
  `cli/src/args.rs` 与 `cli/src/server.rs` 的两个测试用
  `include_str!("../../scripts/*.json")` 跨出 crate 目录两级；cargo 只打包
  crate 目录内的文件，故解包后跑测试报
  `couldn't read src\../../scripts/param_parity_cases.json (os error 3)`。
  但两处调用都在 `#[cfg(test)]` 内，不参与 `cargo build`／`cargo install`
  —— `docs/PROJECT_STATUS.md` 关于「`cargo install nctool-cli` 验证通过」的
  记录与此并不矛盾。是否把 fixture 复制进 `cli/tests/fixtures/`（代价是破坏
  「单一来源」）留待决策。

### 批次十：收尾小项（第四轮批次 E 的一部分）

#### Fixed

- **`ui --open` 不再先于绑定**（`cli/src/commands/ui.rs`、`cli/src/server.rs`）：
  `serve` 拆成 `bind` + `serve` 两步，先绑定、失败即返回 `Err`，再打印横幅与开浏览器。
  此前端口被占用时会先弹出一个指向死页的浏览器标签页。
  同时 `bind` 回读 `server.server_addr()` 拿**实际**端口 —— `--port 0` 时内核分配端口，
  旧代码的横幅与浏览器 URL 都指向 `:0`。
  实测：`--port 0` 显示真实端口；端口占用时退出码 3 且不弹浏览器。
- **错误链截断留痕**（`src/error.rs`）：超过 `MAX_ERROR_CHAIN`（8 层）时追加
  `…（错误链超过 8 层，已截断）`。静默丢弃根因会让"最后一层"看起来就是原因，
  而它其实只是第 8 层。
- **`RegistryError::Io` 带上路径**（`core/src/registry.rs`）：该变体只装 `io::Error`，
  用户此前只看到「文件读取失败: 系统找不到指定的文件」，不知道是哪个文件。
  变体形状是已发布 API 不能改，故在构造处把路径并进 `io::Error` 的消息。
- **`release.yml` 补 `--locked` / `--all-targets`**：与 `ci.yml` 对齐。
- **文档残留的"15 组 golden"**（`PROCESS_CHECKLIST` / `ROADMAP` 共 3 处）改为 21 组正向；
  `DEV_PLAN_CLI_UI` 的 `cargo clippy` 补 `--workspace`。

#### Changed

- **CLI 的 golden 测试改为读共享基线**（`cli/tests/cli.rs`）：3 个测试此前各自硬编码
  一份期望输出，测试名却声称"与 nctool-core 管线逐字节一致"—— 模板一改要手工同步
  两处，且没有任何测试能发现两份已经不一致。现新增 `read_golden()` 直读
  `tests/golden/*.nc`；`program_header` 的参数对齐 fixture（补 `part_name=DEMO`），
  另保留一条"省略可选参数走规格默认值"的断言。
  **反向验证**：改动 golden 基线后 CLI 侧与 core 侧**同时变红**；此前 CLI 侧照样绿。

#### 测试

- 新增 3 项：`bind_with_port_zero_reports_actual_port`、
  `bind_reports_error_instead_of_panicking`、`add_file_io_error_includes_the_path`。
- workspace 全量 **568 项**通过；fmt / clippy / doc 门禁均通过。

#### 仍开放

- UI 的 P2-25（Bool 参数恒提交 `false`）与 P2-26（缺 `AbortController`）：两者都需
  浏览器验证，而本机不支持 agent-browser（Windows），盲改不符合本项目"改动须实测"的标准。
- `src/lib.rs` 1760 行内联测试迁移：需先确认它们是否只用公共 API，收益不明确。

### 批次十四：覆盖率阈值 88% → 89%（用 Ubuntu 实测数据结掉悬置决策）

#### 背景

第三轮把阈值定在 88% 时留了一句话：「89.49% 是本机 Windows 实测，CI 在 Ubuntu 上跑，
余量 1.49pt 未必能跨平台兑现 —— 建议先看一次 Ubuntu 的实测数字再定」。
CI 转绿后从 run 的 `rust-coverage-lcov` 产物里取到 lcov，用项目自己的脚本按生产口径重算：

| 口径 | 数值 |
| --- | ---: |
| **Ubuntu CI 生产口径**（门禁用的那个） | **4553/5040 = 90.34%** |
| Ubuntu CI 原始口径（含 `#[cfg(test)]` 段） | 9727/10343 = 94.04% |
| 本机 Windows 生产口径 | 4696/5214 = 90.07% |

**跨平台差异只有 0.27pt** —— 第三轮担心的"余量未必兑现"不成立，Ubuntu 上反而更高。

#### Changed

- **阈值 88% → 89%**（`.github/workflows/ci.yml`，脚本默认值同步）：余量 1.34pt
  ≈ 68 行未覆盖生产代码，是实测跨平台差异的约 5 倍。
  **刻意不设 90%**：余量只剩 0.34pt ≈ 17 行，任何一次小改动都可能误触 ——
  而"经常误报的门禁会被当成噪音忽略"，本批次刚诊断的 `msrv` job 长期红着没人看
  就是这个失效模式的实例。一个总是误报的 90% 门禁，比一个可靠的 89% 门禁价值更低。
- **`scripts/check_coverage_caliber.py` 新增 `--strip-prefix`**：此前只对**相对路径**
  套用 `--root`，绝对路径直接使用，导致 CI 产物（runner 上是
  `/home/runner/work/<repo>/<repo>/cli/src/args.rs`）在本地**无法分析** ——
  报"源码文件不存在，无法判定生产口径"。现剥掉前缀即可映射到本仓库。
  此前只能手工改写 lcov 的 SF 路径（本次就是先这么做的），属"有数据但拿不到"的隐性障碍。
- 文档同步：`README` / `CONTRIBUTING` / `PROJECT_STATUS` / `RELEASE` / `ROADMAP` 的
  阈值与基线数字更新；`CONTRIBUTING` 补上"如何分析 CI 覆盖率产物"的用法。

#### 验证

- `check_coverage_caliber.py` 两种调用方式（带/不带 `--strip-prefix`）均正常；
  对 Ubuntu 产物重算得 90.34% ≥ 89% 通过
- 文档链接与锚点检查通过；fmt 通过；两个对拍脚本通过

### 批次十三：修正 MSRV 声明 1.82 → 1.85（CI 长期红着的根因）

#### 背景

推送后核对 GitHub Actions，发现**推送前两次提交（`343d264` / `de64e32`）的 CI 都是 failure**。
逐 job 排查：失败的只有 `MSRV (1.82)` 的 `Check on 1.82`，其余全绿
（三平台质量矩阵、coverage、doc、audit 均通过）。也就是说 CI 的红灯已经持续了一段时间，
而本机门禁（Windows + stable 1.98）永远看不到它。

#### Fixed

- **`rust-version` 由 `1.82` 改为 `1.85`**（三个 `Cargo.toml`）：本地复现后确认
  `clap_derive 4.6.4` 的清单声明 `edition = "2024"` + `rust-version = "1.85"`，
  是整个依赖树的最高值；Cargo 1.82 连解析它的清单都做不到：

  ```
  error: failed to download `clap_derive v4.6.4`
  Caused by: feature `edition2024` is required
  ```

  实测 `cargo +1.85 check --workspace --locked` **通过**，故 1.85 是真实 MSRV。
- **CI 的 `msrv` job 同步**（`.github/workflows/ci.yml`）：toolchain `@1.82` → `@1.85`，
  job 名与步骤名一并更新；并在注释里写清"为什么是 1.85"与
  **"抬 MSRV 前先看本 job 的红绿，别只看本机 stable"**，避免后人以为是随手抬的。
- **对外表述全面对齐**：`README.md`、`docs/CONTRIBUTING.md`、`docs/archive/legacy/RELEASE.md`、
  `docs/archive/legacy/ROADMAP.md`、`docs/TEMPLATE_INTEGRATION_PLAN.md` 的 1.82 表述全部改为 1.85。

#### 说明

第三轮 P1-16 指出「MSRV 1.82 是无效承诺，CI 无任何任务在 1.82 上编译」，
当时的修复是**加上这个 job**。但 job 一上线就是红的，而没人核对它的运行结果 ——
**job 存在 ≠ 承诺成立**。本次把声明改成了事实，并让 CI 注释承担"下次抬 MSRV 时提醒"的职责。

> 另一条路是反向锁 `clap` 到 4.5.x（MSRV 1.74）以保住 1.82。本次未选：那会引入一个
> 需要长期维护的版本锁，而 1.85（2025-02）距今已一年半，作为 MSRV 并不苛刻。

#### 验证

- `cargo +1.85 check --workspace --locked` 通过（独立 target 目录，未污染主缓存）
- workspace 全量 **571 项**通过；fmt / clippy 门禁通过
- `ci.yml` YAML 解析校验通过

### 批次十二：服务层两项的实测定性（第四轮批次 G，纯测量，无代码改动）

第三轮 P1-18 / P1-19 长期以「读码推断」的形式挂在未决项里。本轮改用原始 socket 探针实测，
**一项被证实、一项被证伪，两项都不需要改代码** —— 但结论必须固定下来，否则下次审查还会重复调研。

#### 实测：单连接即可挂死服务（P1-19 → 第四轮 P1-4）—— **缺陷真实**

| 步骤 | 结果 |
| --- | --- |
| 基线 `/health` | 1.0 ms |
| 一条连接只发 `Content-Length: 1048576` 头、不发体 | — |
| 此时另一次 `/health` | **4006 ms 超时**（客户端 4s 上限） |
| 恶意连接关闭后 | 13 ms 恢复 |

即**任意本地进程一条连接就能让整个 UI 失去响应**，不是纸面推断。

**为什么没有顺手修**（直觉修法是"把 `Request` 移进工作线程"）：

1. `tiny_http::Request` 确实无生命周期参数（内部 `Box<dyn Read + Send + 'static>`），
   这一半可行；
2. 但 `Ctx` 含 `RefCell` + `Rc`，**不是 `Send`**；
3. 把 `Rc` 换成 `Arc` 只解决一半 —— 编译期探针实测 `GCodeGenerator: Send + Sync`
   **不成立**，报错点是 core 的 `OnceCell<Result<Renderer, TplError>>` 与
   `OnceCell<Result<Analysis, TplError>>`（`std::cell::OnceCell` 不是 `Sync`）；
4. 故改动必须进入 core（`OnceCell` → `OnceLock`/`Mutex`），并进一步验证
   `Renderer`（minijinja `Environment` + `path_loader` 闭包）是否 `Sync` ——
   这是对**已发布 crate 并发模型**的改造，不是服务层补丁；
5. 且 tiny_http 0.12 **完全没有读超时 API**（已 grep 整个 crate 源码），即使上了多线程
   也只能把"主循环永久阻塞"降级为"有限个工作线程被占满"。

风险面受限：`listen_addr` 硬拒非回环，攻击者需已是本机进程。**独立排期，范围与阻塞点已量清。**

#### 实测：每请求全树 `stat`（P1-18 → 第四轮 P1-5）—— **不值得改**

200 次取样、预热后交错采样：

| 端点 | 中位 | p95 |
| --- | ---: | ---: |
| `/health`（不建注册表） | 1.04 ms | 18.1 ms |
| `/api/templates`（建注册表，含全树 stat） | 1.16 ms | 17.0 ms |
| **净成本** | **0.12 ms** | — |

当前规模下可以忽略；按线性外推要到模板数增加两个数量级才会到 ~12 ms。

⚠️ 原报告建议的修法（"指纹只取根目录 + 顶层子目录 mtime"）**是错的**：目录 mtime 只在
增删/改名时变化，**就地编辑文件内容不改父目录 mtime** —— 只看目录会让缓存返回过期模板，
把一个性能问题换成正确性问题。判定为不修。

### 批次十一：错误诊断准确性（第四轮批次 F）

#### Fixed

- **过滤器名不再被当成缺失变量名**（`src/error.rs::extract_undefined_var_name`）：
  `{{ missing | upper }}` 的 `UndefinedError` span **只覆盖过滤器名** `upper`
  （minijinja 把错误定位到过滤器上），于是消息报「未定义变量 'upper'」——把用户
  指向一个过滤器名。现在 span 之前（跳过空白）的最后一个字符是 `|` 时不采纳该标识符。

  **原报告对这一条的描述是错的**：它称 `{{ a + missing }}` 会报首个标识符 `a`。
  实测该形态走 `InvalidOperation` → `TplError::Render`，**根本不提取变量名**。
  真正可复现的是过滤器形态，由探针跑 16 种写法逐一定位：

  | 模板 | 类别 | variable |
  | --- | --- | --- |
  | `{{ missing }}` | `UndefinedVariable` | `missing` ✅ |
  | `{{ missing \| upper }}` / `{{ x \| f \| g }}` / `{% if x \| f %}` | `UndefinedVariable` | 过滤器名 ❌ |
  | `{{ missing.attr }}` / `{{ missing[0] }}` | `UndefinedVariable` | `""` ✅ |
  | `{{ a + missing }}` / `{{ missing + 1 }}` | `InvalidOperation` → `Render` | —（不提取） |
  | `{{ missing ~ "x" }}` | `UndefinedVariable` | `missing` ✅ |

  ⚠️ 第三轮建议的修法（"要求标识符覆盖 trim 后整个 range"）**是错的**：它挡不住
  过滤器名（span 恰好就只有 `upper` 一个标识符），却会**误伤** `{{ missing ~ "x" }}`
  （span 覆盖整条表达式，但首个标识符确实是变量）。这是坚持先实测、再动手的直接价值。

#### 判定不修

- **嵌套 include 的错误类别不细分**（第三轮 P2-12）：根因已由 ` ← ` 链修复补进消息
  （含子模板名与行号）；`src` 之外匹配 `TplError` 细分变体的地方只有 `registry.rs`
  的 `TemplateNotFound`，其余全部构造/透传 `Render`——改细不会让任何调用点受益；
  且细化后要决定"用哪个模板名"，而现有测试正是把"不跨模板错位恢复变量名"写成
  期望值的。保留现状，理由已写入报告与代码注释。

#### 测试

- 新增 `filter_name_is_not_reported_as_undefined_variable`：覆盖 3 种过滤器形态，
  并显式守住两种**不属于**本缺陷、必须保持原样的情形（`InvalidOperation` 归 `Render`；
  `{{ missing ~ "x" }}` 必须继续恢复出 `missing`）。
- **反向验证**：移除 `|` 判据 → 报 `应留空而不是报 "upper"` → FAILED → 恢复。
- workspace 全量 **571 项**通过；fmt / clippy 门禁均通过。

#### 一处更正

第四轮报告 §3.3 引用的「`src/renderer.rs:185` 多克隆一次源码」经复核**不成立**：
`name` 与 `source` 在紧随其后的 `.map_err(|err| from_minijinja_error(err, &name, Some(&source)))`
里仍被借用，而 `add_template_owned` 按值接管两者，两个 `clone()` 都必需。
报告已同步更正，**不要按原文去"修"**。

### 批次十五：本地文件读取上限 + 错误链补全（第四轮批次 D）

第四轮审查（`docs/CODE_REVIEW_2026-09-19.md`）批次 D 的剩余项。核实后其中
两项（`registry.rs` 的 `try_iter().ok()?` 静默吞错、`RegistryError::Io` 丢路径）
**已于前批次修复**，本批次处理真正开放的 P1-10 与 P1-11 的 `source()` 缺口。

#### Fixed

- **CLI 侧本地文件读取加上限**（第四轮 P1-10）：此前 HTTP 侧有 1 MiB 请求体上限，
  而 CLI 侧的 `nctool.toml`、`--params-file`、模板目录下的 `*.j2` 三处
  `read_to_string` **全部无上限**——`--template-dir` 指向网络盘或大文件时会把
  内容整体读进内存。新增 `cli/src/limits.rs`（`MAX_LOCAL_TEXT_BYTES = 1 MiB`）
  与 `read_text_limited`，先用 `metadata` 在读取前拒绝超大文件（避免先读进内存
  再判断），三处入口统一走它。超限时报 `io` 类错误并**同时给出路径、实际大小
  与上限**，不静默截断（截断会产出语法不完整的内容，更难排查）。
- **`PipelineError::source()` 补上 `Derive` 变体**（第四轮 P1-11）：`DeriveError`
  已 `impl Error`，但 `source()` 的 `match` 漏了该变体，导致派生失败时错误链分叉、
  调用方无法沿 `source()` 拿到根因。`Validation` 仍为 `None`（`ValidationReport`
  是聚合报告，不 `impl Error`），保留现状。

#### Added

- `cli/src/limits.rs` 4 项单元测试：小文件可读 / 超限拒绝（带路径与上限文案）/ 
  **恰好等于上限则通过**（边界包含）/ 文件缺失报 `io`。
- `cli/tests/cli_e2e.rs` 1 项 E2E：`--params-file` 指向超限文件时真实二进制
  退出码 3 且 stderr 含「过大」「上限」。
- `core/src/pipeline.rs` 1 项回归：构造派生成环的规格，断言
  `PipelineError::Derive` 的 `source()` 能 `downcast_ref` 回 `DeriveError::Circular`。

#### 验证

- workspace 全量 **577 项**通过；`cargo fmt --all -- --check`、
  `cargo clippy --workspace --all-targets -- -D warnings`、
  `cargo test --workspace --doc` 均通过。

### 批次十六：消除 CLI ↔ Web UI 生成选项隐患

审计（手动走查 CLI 与 UI 功能覆盖）发现两类「同一份参数在两个入口产出不同结果」
的隐患，均与「静默不一致」同族：

#### Fixed

- **CLI 补充 `--line-step` / `--max-line`**：`GenerationOptions` 的
  `line_number_step` / `max_line_number` 此前**只能由 Web UI 设置**（API 已接受
  `lineStep` / `maxLine`），CLI 无法复现同一份带自定义步进的输出 —— UI 上设
  步进 100 生成的程序，用 CLI 默认步进 10 重跑得到不同 G-code。现
  `render` / `generate` 均支持 `--line-step <N>`（默认 10）与 `--max-line <N>`
  （默认 9999），与 UI 映射到同一份结构体（`cli/src/commands/render.rs`）。
  ⚠️ 此修复后 `..Default::default()` 不再需要，clippy `needless_update` 会报错，
  已一并去除。

#### Added

- **生成选项对拍门禁**（新 fixture + 双向消费点）：
  `scripts/option_parity_cases.json` 是 CLI 选项与 Web API `options` 映射的单一来源。
  Rust 侧由 `cli/src/server.rs::option_mapping_matches_shared_fixture` 消费（断言
  JSON 侧 `generation_options` 与 CLI 字段构造出同一份 `GenerationOptions`）；
  前端侧由新增的 `scripts/check_option_parity.mjs` 消费（从两份 UI 抠出
  `normalizeOpts` 对拍）。CI 新增 `Option parity (CLI <-> UI)` 步骤。
  两侧均做反向验证：故意改 fixture / 改 UI 默认值 → 立刻红。
- `cli/tests/cli_e2e.rs` 1 项：`--line-step 100 --max-line 250` 实测行号步进为
  100、且不超过上限。

#### 说明（非缺陷，保留现状）

- **自定义机床的两处入口**：Web UI 的 localStorage 自定义机床**只在演示模式生效**，
  服务模式已明确 toast「服务模式使用服务端机床配置」（服务端机床来自 `nctool.toml`
  经 `/api/machines` 下发）—— 属有意设计（浏览器无法写服务器文件），非静默失效。

#### 验证

- workspace 全量 **579 项**通过；fmt / clippy / doc / 三项对拍脚本 / 文档链接均通过。

### 批次十七：覆盖率洼地补齐（A3）

三处「全项目最低」的覆盖洼地在 2026-09-22 集中补齐；均为**纯增测试/可测性重构**，
不改运行时行为（`serve` 的拆分是等价重构）。

#### 覆盖率变化（生产口径）

| 文件 | 之前 | 之后 | 做法 |
|---|---|---|---|
| `cli/src/commands/ui.rs` | 20.00% | **98%** | 把 `run` 拆成 `prepare` + 注入式 `run_with_serve`，阻塞的 `serve` 成为参数；新增 9 项单测 |
| `cli/src/commands/inspect.rs` | 80.79% | **93%** | 新增 4 项单测（`render_line`/`constraint_summary`/`options_summary`/Bucket）+ 2 项 E2E（include 穿透 / 无变量） |
| `core/src/variables.rs` | 83.70% | **97%** | 新增 5 项错误路径测试（非法 YAML / 序列坏元素 / 缺文件 / IO 错误 / 正常加载） |
| 全项目 | 90.47% | **92.19%** | +18 项测试（579 → 597） |

#### Changed

- **`server::serve` 拆出借用版 `serve_requests`**（等份重构）：`serve` 按值接管后，
  测试进程无法再持有句柄调 `Server::unblock()` 让循环**干净退出** —— 而 llvm-cov
  只在干净退出时才落盘覆盖数据，被 kill 的子进程（现有 spawn-and-kill E2E）
  覆盖**全部丢失**（实测 `serve()` 循环体 0 覆盖）。拆分后新增
  `serve_handles_real_request_then_unblocks_cleanly`：进程内跑真服务、发真请求、
  `unblock()` 干净关停。
- **`ui::run` 拆出 `run_with_serve`**：把阻塞的 `serve` 作为参数注入，
  从而在单测里覆盖「prepare → 横幅 → `--open` 分支 → 移交 serve」完整启动序列。
- **覆盖率门禁 89% → 91%**（`.github/workflows/ci.yml`）：补齐洼地后本机 92.19%，
  余量 1.19pt ≈ 60 行。沿用「不贴着实测值设阈值」的原则。

#### 验证

- workspace 全量 **597 项**通过；fmt / clippy / doc / 三项对拍 / 文档链接均通过；
  覆盖率门 91% 通过（实测 92.19%）。

### 批次十八：收窄发布包（A5）

`nctool-tpl` 是**库**，但仓库里同时住着 CLI / Web UI / 开发脚本 / 原型产物，
此前 `Cargo.toml` 的 `exclude` 只挡了 `.github/` `docs/` `target/`，其余全部
被打进 `.crate`：**120 个文件 / 498 KiB**（原型 PNG、验收脚本、模型交接 HTML…）。

#### Changed

- **扩充 `nctool-tpl` 的 `package.exclude`**：新增 `output/`、`scripts/`、`ui/`、
  `examples/multi_op_demo.sh`、`启动UI.bat`、`overview.md`、`CODE_REVIEW_AND_DEV_PLAN.md`
  以及 `templates/` 下除演示模板外的内容。
  效果：**120 → 63 个文件，498 KiB → 126 KiB（−75%）**。
- **保留 `templates/turning/demo_gcode.j2`**：`examples/demo.rs` 运行时会读它，
  整目录排除会让发布物的 `cargo run --example demo` 运行时报错。该模板自包含
  （无 include），保留成本极小。

#### Added

- **发布包内容守卫**（`scripts/check_package_contents.py` + CI 步骤
  `Package contents`）：对 `cargo package --list --offline` 做**黑名单断言**
  （而非白名单——白名单会在库合法新增文件时误报），另加正向断言确保
  `src/lib.rs` / `Cargo.toml` / `LICENSE` / `README.md` 仍在包里（防 exclude 写过头）。
  正反向均实测：把 `output/` 从 exclude 移除 → 守卫立即报错列出 16 个文件。

#### Fixed（CI 首次运行的回归）

- **守卫步骤的两个环境假设不成立，导致 CI 红**（`no matching package named
  'minijinja' found`）：
  1. 步骤被插在 `Install Rust` **之前**，而 `--offline` 要求注册表已 populate
     → 已移到 `Test` 之后（依赖已拉取），并给脚本加**联网回退**（`--offline`
     失败则重试不带 `--offline`），无论置于何处都能工作；
  2. 脚本 subprocess 用只含 `PATH` 的**干净环境**调用 cargo，丢掉
     `HOME`/`CARGO_HOME`/`RUSTUP_HOME` → 改为**继承**当前环境，仅覆盖
     `CARGO_INCREMENTAL`。

#### 验证

- workspace 全量 **597 项**通过；fmt / clippy / doc / 四项对拍与守卫 / 文档链接均通过。
- `cargo package` 验证通过（发布物可独立编译）。

### 批次十九：golden 基线变更保护步骤化（A6 / B4.2）

刷新机制（`NCTOOL_UPDATE_GOLDEN=1`）与 Rust 侧的「CI 拒刷」assert 早已存在（P2-30），
但**人工流程未成步骤** —— 直接敲环境变量命令存在三个风险：误在 CI 触发、在脏工作区
刷新导致 diff 混杂、误删基线而不自知。

#### Added

- **`scripts/refresh_golden.sh`**：把刷新包成带守卫的步骤。
  1. **拒绝 CI**（检测 `CI`/`CI_NAME`/`GITHUB_ACTIONS`）——与 Rust 侧 `assert!` 双重兑底；
  2. golden 之外的改动未提交时提示先处理（避免 diff 混杂）；
  3. 刷新前展示当前基线 diff 概览；刷新后展示变化概览（含新增/删除文件）；
  4. 刷新后校验基线文件数 **≥ 45**，防误删导致防线缩水；
  5. 支持 `--yes` 非交互与 `--help`。
- **CI 步骤 `Golden refresh script guards`**：`bash -n` 语法检查 + 带 `CI=1`
  运行必须退出非 0（自测「CI 拒刷」这条最关键的行为）。

#### Fixed

- **文档数据漂移**：`CONTRIBUTING.md` 的 golden 一节记「42 个基线文件」（实为 **45**），
  且刷新命令未提「必须 `--workspace`」。已改为 45 并重写为完整流程。

#### 验证

- 脚本正反向均实测：`CI=1` → 退出 1；删一个基线文件 → 测试阶段（`golden_files_are_lf_only`
  的 ≥ 45 断言）与 shell 守卫均报错；正常（no-op）刷新 ✓。
- workspace 全量 **597 项**通过；fmt / clippy / doc / 守卫 / 文档链接均通过。

### 批次二十：弱断言补强（A8）

第四轮审查（`CODE_REVIEW_2026-09-19.md` §3.3）列出的三处「测试质量」问题，
其中两处已在早前批次修复（`all_math_filters_render` 的精确断言、CLI golden 读基线），
本轮处理剩余的 fuzz 弱断言。

#### Changed

- **fuzz 测试从「不 panic」提升到「不 panic 且产出自洽」**：
  - `fuzz_random_templates_no_panic`：把内联的不变量检查抽为共享的
    `assert_extract_invariants`（名字非空 / 按名去重 / 行列 1 起 / span 有序 /
    未声明 ⊆ 全集）。
  - `deeply_nested_100_levels_no_stack_overflow`：此前 `let _ = extract_*(&ast)`
    丢弃返回值；现同样跑 `assert_extract_invariants`。
  - `fuzz_random_render_no_panic`：此前 `let _ = renderer.render(...)`；现断言返回
    形状恒定 —— 失败（`Err`）必须携带**非空**可读消息。

#### 验证

- **反向验证**：把 `extract.rs` 的 `Variable { start, end }` 写反（模拟 span 回归）
  → `fuzz_random_templates_no_panic` 立即 FAILED 并报「span 应有序」；
  而旧的 `let _ =` 版本不会发现。恢复后转绿。
- workspace 全量 **597 项**通过；fmt / clippy / 覆盖率门 91% 均通过。

### 批次二十一：新增 `nctool lint`（三角函数度制风险检查）

Backlog 里唯一带**安全性质**的未实现功能：模板里写 `{{ 30 | sin }}` 时，
minijinja 的 `sin` 按**弧度**解释（项目另有度制变体 `sin_d`）。写错**不会报错**，
只会静默产出错误坐标（撞刀级）。`lint` 在渲染前把这类用法拦下。

#### Added

- **`nctool lint <模板>`**：静态检查模板。首个检查项：标准三角函数
  `sin`/`cos`/`tan`/`asin`/`acos`/`atan`（弧度制）给出警告并建议改用
  `sin_d` 等度制变体。支持内置/目录模板名与文件路径、`--format json`。
  退出码：无发现 0；有发现 1；语法错误 6。
- **`nctool_tpl::lint` / `LintFinding`**（`src/lint.rs`）：遍历 minijinja AST
  的**全部**语句 / 表达式形态收集过滤器用法；公开供其他前端复用。
- 测试：`src/lint.rs` 11 项单测（含“把 | sin 放进每一种 AST 形态”的遍历完整性用例
  + raw 块不误报）、`cli/tests/cli.rs` 4 项、`cli/tests/cli_e2e.rs` 2 项。

#### 说明

- 遍历完整性用例暴露了一个 parser 细节：minijinja **只为链式比较（2+ 运算符）
  构造 `Expr::Compare`**，单次 `>` 走 `Expr::BinOp` —— walker 必须两个分支都覆盖。
- 弧度可能是刻意的，故为**警告**而非错误。`nctool-tpl` 的 `src/lint.rs` 生产口径
  覆盖率 **100%**。

#### 验证

- workspace 全量 **614 项**通过；fmt / clippy / doc / 四项对拍与守卫 / 文档链接均通过；
  覆盖率门 91% 通过（实测 92.35%）。

### 批次二十二：注释/文档与实现对齐（收尾）

第四轮审查 §3.3「注释与实现矛盾」的最后几条，逐条核实后处理：

#### Fixed

- **`core/src/pipeline.rs` 行号规则注释**：原注释写「程序号行（`O` 开头）…已有 `N`
  前缀」，未反映两个前缀均可由机床配置（`program_prefix` / `line_number_prefix`），也未提及小写 `o`/`n` 的特判与空串回退。已改写为完整描述。
- **`src/filters.rs` i64 上界注释**：补上边界说明 —— 入参已是 `f64`，
  `(2^53, 2^63)` 的精度损失本函数管不到，只守「饱和到 `i64::MAX`」这条前沿
  （NC 量级不可及），去除“过度承诺”。
- **文档过时项**：`docs/PROJECT_STATUS.md` 的 Backlog 表挂上“参数集命名预设”
  （实际 Web UI 早已用 `localStorage` 实现）、`check_docs_links.py` “未接入 CI”
  （实际已在 CI）；`docs/CODE_REVIEW_2026-09-19.md` §3.3 的几项标记为已修
  （`classify_by_path` 已在批次 A 改为穷尽匹配、`integration.rs` 已是 7 内置模板）。

#### 验证

- workspace 全量 **614 项**通过；fmt / clippy / doc / 覆盖率门 91% 均通过。

---

### 批次十五：参数预设编辑（编辑模块三，T03）

「三个编辑模块」的第三个：把一组参数落成**命名预设**，可跨会话复用、可导出导入、
并在模板规格变化后给出**陈旧提示**。三处入口共用同一份数据（`presets.yaml`）：
CLI `nctool preset ...`、HTTP `/api/presets`、Web UI 预设面板。

走的是与 `templates.yaml` 相反的编辑策略：预设文件是**工具自有**的新建文件，
没有人工注释需要保全，因此直接 serde 全量往返，不做定点文本编辑。

#### Added

- **`core::asset::preset`**：预设存储内核。模型（`Preset` / `PresetFile`）、
  后端（`PresetStore::{load,save,upsert,rename,remove}`，全部经 `WriteKernel`
  的原子写 + 乐观锁）、导出导入（`export_preset` / `import_presets`）、
  陈旧检测（`StaleReport`）与跨模板交集报告（`CrossTemplateReport`）。
  schema `version: 1`；文件默认落配置目录（`%APPDATA%\nctool\presets.yaml`）。

- **`nctool preset` 子命令族**：`save` / `list` / `show` / `rename` / `rm` /
  `export` / `import` / `apply`。`apply` 支持跨模板并强制显式确认（`--confirm`）。

- **`/api/presets`（GET / POST）与 `/api/presets/delete`（POST）**：
  与 CLI 逐条同规的校验链。`GET` 返回**结构化**陈旧字段
  （`resolvable` / `stale` / `staleParams` / `missingRequired`），
  消费方无需解析文本（D7）。

- **Web UI 预设面板**：顶部 chips 带陈旧角标（失效参数 / 缺失必选逐项列出），
  弹窗内可见陈旧详情。**替换**了原先只落 `localStorage` 的本机实现 —— 那套实现
  与 CLI/HTTP 的 `presets.yaml` 是两个互不相干的仓库（UI 存的 `nctool preset list`
  看不见，反之亦然）。现在 demo 模式由 API 层仍落 `localStorage`，服务模式落
  `presets.yaml`，但**接口与语义完全一致**。

- **退出码 5 的语义扩展**：`preset_not_found` 归入 5（原 5 只含模板/机床未找到），
  退出码冻结区间 `0..=7` 不变。

#### Fixed

修掉四个**静默错误**（值合法、不报错、只是错），均带回归测试：

- **红线 R-9 的条件性失效**：预设文件"不得落在模板根内"的校验此前写成
  `if let Some(root) = &ctx.template_dir { ... }`，未配置模板目录时**整条红线被跳过**。
  实测把 `./templates/presets.yaml` 写进了模板根（会被注册表当模板扫描）。
  现改为**无条件**取全部候选模板根（显式配置的 + 默认 `./templates` + 注册表发现的）
  逐个比对；且 `normalize()` 先绝对化再比较，修掉"相对路径 vs 绝对路径恒不相等"
  的第二个缺口。

- **新鲜预设被误报为陈旧**：`stale_report` 只拿 `specs` 判"参数还在不在模板里"，
  对**没有声明规格**的模板（`specs` 为空表）会把**每个**参数都判成失效 ——
  狼来了，真正的失效反而被淹没。现引入 `stale_report_full`，判定改为
  "参数既不在规格中、**也不被模板引用**"才算失效；"新增必选"在规格表为空时
  回退到模板的必选变量（`!Variable::optional`）。

- **删除被报成更新**：`PresetStore::remove` 内部是"改完内容再落盘"，
  直接透传了 `save` 的动作 → `action` 返回 `updated`。消费方按 `action` 分支时
  **永远走不到删除分支**。新增 `WriteAction::Deleted` 并让 `remove` 显式置位。

- **"不存在"靠匹配消息文本分类**（D7 禁止）：预设不存在被塞进 `WriteError::Corrupt`，
  下游只能靠 `msg.contains("不存在")` 分流，文案一改就静默归错 ——
  HTTP 侧把"删一个不存在的预设"报成 **500 内部错误**。新增
  `WriteError::NotFound` 结构化变体；CLI 归 `preset_not_found`(5)，
  HTTP 归 404。

- **`/api/presets` 的 `template_not_found` 状态码与其它端点不一致**：
  经 `cli_error` 一律给 400，而 `template_detail` / `registered_template` /
  `inspect` 三处都是 404。同一 kind 因端点不同给出两种状态码，前端按状态码
  分支必然错判。新增 `cli_error_mapped` 按 kind 校正。

#### 测试

- `core` 新增 21 项单元测试（往返 / 陈旧 / 跨模板 / 导入导出 / 降级 / 红线）。
- `cli/tests/cli_preset_e2e.rs`：22 项 E2E，覆盖 PRD AC-3.1 ~ AC-3.10。
- `cli/src/server.rs` 新增 9 项端点测试（含退化行为与红线守卫）；
  因 `default_preset_path()` 读**进程级** `APPDATA`，这批测试用全局互斥锁**串行**，
  否则并行测试会互相覆盖 env、把文件写进彼此的临时目录。

### 批次十六：共用写盘底座与模板编辑（编辑模块一，T01 + T02）

把资产（模板 / 清单）从"只能手改文件"变成"工具内可创建、可修改、可复用"，
且所有写入都受与渲染**同源的校验**保护。

#### Added

- **`core::asset`（新模块，T01）**：领域层**唯一写内核** ——
  `WriteKernel::{write_atomic, write_guarded, read_fingerprint}`、`SafePath`、
  `validate_asset_name`。三条保证：**原子写**（同目录 `.nctool-tmp-` 临时文件 →
  `fsync` → `rename`，失败清理）、**乐观锁**（`hash + len + mtime` 三者比对，
  **禁用纯 mtime** —— Windows 时间分辨率粗会漏检）、**路径防护**
  （`SafePath::resolve` 对候选路径断言根包含，拒符号链接逃逸）。
- **`core::asset::template` 与三种编辑策略（T02）**：`TemplateWriter` 对
  `templates.yaml` 做**定点文本编辑**（YAML 无成熟注释保全写库，serde 往返会删注释）；
  另两种格式各按其性 —— `nctool.toml` 用 `toml_edit`、预设文件用 serde 全量往返。
- **`nctool templates edit / derive / rename`（T02）**；`templates new` 迁移到写内核
  并落清单。**保存前校验分级 L1/L2/L3**：语法（总是）→ 规格自洽（总是，不依赖参数值）
  → 参数值校验（提供 `--param` 时；只查已提供的值，不查缺失）。
- **`core::validate::{check_spec_consistency, check_param_values}`**：把上述 L2/L3
  下沉为可复用的公共入口。

#### Fixed

- **路径逃逸（QA 击穿）**：`SafePath::resolve("Z:")` 曾返回**根外路径** ——
  `validate_asset_name` 的注释写着"恰为一个**普通**组件"，实现却只数
  `components().count() == 1`，而 Windows 上 `"Z:"` 恰好是 1 个 `Prefix` 组件；
  `root.join("Z:")` 因 RHS 带前缀而**整体替换**根，随后根包含校验查的是 `anchor`
  而非 `candidate`，等于没校验。两层一起修：名称校验要求唯一 `Component::Normal`，
  `resolve` 对 `candidate` 断言根包含。
- **指纹歧义（QA 击穿）**：`specFingerprint` 的 `None` 记 `-`，与真实值 `"-"` 撞车。
  改为全字段长度前缀编码（`None`→`-1:`、`Some(s)`→`<字节长>:<s>`），使 `|`/`\n`/`;`
  均无法注入。**这是改编码的最后窗口** —— 预设落盘后再改会让既有预设全部被误判为陈旧。
- **清单定点编辑吞并兄弟条目（QA 击穿）**：`manifest_entry_body` 只在空行/顶格行停、
  **不在同级键行停** → `derive` 会吞并相邻兄弟条目 → 重复键 → `serde_yaml` 拒收
  **整份清单** → 全部模板元数据静默丢失。仓库自带清单用空行分隔故 CI 永不触发，
  **只有用户手写清单会中招**。
- **`default` 自洽判定被写两遍**（P4 单一来源违规）：`validate.rs::check_spec_defaults`
  与 `asset/template.rs` 各一份 → 同一模板在 `nctool validate` 与 `templates edit`
  下可能结论不同。

### 批次十七：机床配置编辑 + UI 构建期拆分（编辑模块二，T04）

机床此前只能手写 `nctool.toml`，而**键错一个就是撞刀** —— 本批把写入做成
"校验先于落盘"的 CLI 命令，并把 Web UI 里那套只写 `localStorage` 的机床编辑界面
（与 CLI/HTTP 读的 `nctool.toml` 是两个互不相干的仓库）换成**只读助手**。

#### Added

- **`core::asset::machine`**：`MachineWriter::{load, upsert, remove,
  check_completeness, preflight}`，全部经 `WriteKernel`。`upsert` 用 `toml_edit`
  **合并式写入**：只改 `[machine.<id>]`，其余段与注释**逐字节不变**；追加新段时以
  原文为字节前缀（避免 `toml_edit` 把文档尾注释挤到新段之后）。
- **`nctool machine add / edit / rm / test`**：`add` 默认以 `generic` 为基线预填
  19 键（`axes` 为可选扩展键、不预填）；内置预设只读；`rm` 须显式 `--yes`；
  `--expect-hash fnv1a64:<16hex>` 提供乐观锁。`preflight` **阻断** Choice 越界 /
  整数不可解析 / 缺被模板引用的键（退出码 1 且不落盘）；扩展键与超大
  `line_number_digits` 仅告警（夹紧仍在 `pipeline`，写层不复制）。
- **`GET /api/machines` 增 `schema` 字段**：机床键规格（键 / 类型 / 默认值 / 候选 /
  含义），取自 core 的 `KNOWN_CONFIG_KEYS`（单一来源）。**机床仍无任何 HTTP 写端点**。
- **UI 只读「机床配置」弹窗**：当前键值 + 键规格 + 可复制的
  `nctool machine edit <id> --set …` 命令 + 「用该机床试渲染」（复用既有 `/api/render`）。

#### Changed

- **UI 改为构建期拼接（T04-c）**：前端源码上移到 `ui/src/*.part.html` 7 个片段，
  由 `scripts/build_ui.mjs` 按文件名升序**逐字节**拼接，**同一份 Buffer** 写出
  `ui/index.html` 与 `cli/ui/index.html`。`ui/index.html` 从"唯一真值"降级为
  **生成物** —— **改前端请改片段并重新生成，不要手改生成物**。
  行数约束从"单文件 ≤ 3000"迁移为"每个片段 ≤ 3000"（最大片段 1160 行）。
  防线两条：CI 的 `build_ui.mjs --check`（对提交物）+ `cli/tests/cli.rs` 的
  重拼接断言（本机 `cargo test` 即可拦住"改了片段忘生成"，不依赖 node）。
- 退出码 0–7、`cli_e2e.rs` 44 用例、golden 45 文件**均未变动**。

#### Fixed

- **失败的命令会留下文件**：`machine add` 的 id 合法性与 `preflight` 都排在
  "首次创建写 `EXAMPLE_CONFIG`"之后 → `machine add "../evil"` 或 `--set units=inch`
  在空项目目录里会先建出一份 `nctool.toml` 再报错，与"校验失败不落盘"相悖。
  改为全部校验前置。
- **`machine edit` 静默删除注释块**：`toml_edit` 把紧邻表头的注释存为该表的 `decor`，
  而 `Table::insert` 换入新表时会连同旧 decor 一起丢弃 —— `add` 写入的
  `EXAMPLE_CONFIG` 示例头（19 行）恰是文件第一个表的前缀，一次 `edit` 就**全数消失**
  （实测 43 行 → 25 行）且无任何提示。改为替换前保留旧表（含 `config` 子表）的 decor。
- **`config` 写成行内表时被当成不存在**（QA 击穿）：`config = { linear = "G1" }` 与
  `[machine.<id>.config]` 语义等价，读路径（serde）两种都认、写路径只认子表 →
  `load` 静默返回空配置，`machine edit` 在注册表降级放行时会**静默丢掉**这些键。
- **非字符串值带装饰空白**（QA 击穿）：`toml_edit` 把 `key = value` 里 `=` 之后的空白
  存进该值的 decor，`max_spindle_rpm = 4200` 读成 `" 4200"`（行内表末值还带尾随空格）。
  值经 `machine.<key>` 注入渲染 —— 多一个空格就进了 G-code。

#### 测试

- `cli/tests/cli_machine_e2e.rs`（38 例）、`core/tests/machine_write.rs`（11 例，
  含 AC-2.10 golden）、`core/tests/machine_adversarial.rs`（8 例，其中两条带
  **变异判别** —— 用缺陷变体重放同一输入，证明用例不是空洞的）、
  `cli/tests/cli.rs` 新增片段行数护栏。合计 **868 passed / 0 failed**。

### 批次十八：堵住 JSON/YAML 数值下溢静默归零（`ERR-NUM-UNDERFLOW`）

第五轮代码审查（`docs/CODE_REVIEW_2026-09-23.md`）提出的 P1：**极小十进制字面量被解析器
静默归零，而 `0.0` 作为合法参数一路写进 G-code，全程无任何报错**。

```
{"x":1e-400}  ->  ParamValue::Number(0.0)  ->  "G0 X0.000"   无报错
```

对机床而言这不是「数据不准」，而是**错误的坐标**。设计见
`docs/err-num-underflow-design.md`，判据经四次否决后收敛为「**实测解析器行为**」而非
任何预测阈值（详见该文档附录 D7 的流程教训）。

#### Fixed

- **`serde_json` 通道**（`--params-file`、`/api/render`、`/api/validate`、
  `/api/inspect`、`/api/part/generate`、`/api/presets`）：解析前先在文本层提取候选，
  再用 `serde_json` **实测确认**得 `0.0`，命中即 **exit 2（kind `args`）/ HTTP 400
  （kind `num_underflow`）** 硬失败，**不受 `--lenient` 豁免**。
- **`serde_yaml` 通道**（模板清单 `params[].default`、变量库、预设文件
  `load` / `import`）：同一两段式，但**确认必须用 `serde_yaml`** ——
  两个解析器的舍入行为**不同**（`2.4703282292062328e-324` 在 `serde_json` 归零、
  在 `serde_yaml` 得 `5e-324`），复用确认结果会误判。
- **`--param` 通道**：确认用 `str::parse::<f64>`（与上述二者的阈值均不同）。
  `k:s=` 显式字符串通道不解释数值，故不触发（`x:s=1e-400` 合法保留）。
- **`cli/src/context.rs`：清单/变量库的下溢不再被降级为 warning**。「清单是可选文件、
  损坏时降级」的既有策略保留，但**下溢单独拎出硬失败** —— 被归零的默认值会直接
  写进 G-code，与「清单损坏」不是一类问题。

#### Added

- **`core::json_num`**（纯 `std`，**零新增 crate**）：`scan_underflow_candidates` /
  `scan_underflow_candidates_yaml` / `confirm_underflow_yaml` / `UnderflowCandidate`。
  预筛阈值取 `2^-1000`（仅作**宽松粗筛**，绝不漏报；裁决权在确认环节）。
  扫描器跳过 JSON 字符串内容与键名、YAML 注释 / 引号串 / 块标量。
- **`WriteError::NumUnderflow`**（`core::asset`，枚举本已 `#[non_exhaustive]`）。
- **`ManifestError::Underflow`**。

#### 关键行为（已有测试断言）

- **真下溢必拒**：`1e-400`、`1e-324`、`1e-0350`、`100000e-405`、无指数长串。
- **合法次正规数必放过**：`5e-324`（`2^-1074`）、`1e-323`、`2.5e-324`、`4.9e-324` ——
  它们是**预筛候选**但经确认放过。此点曾是本修复最大的误伤风险：项目有 `nc_strip`
  过滤器用 Rust `Display` 输出**完整 326 字符真值**（非 `0.000`），被真实模板
  `machines/index_g420/dg_cal_ir9.j2` 使用，误拒会把本可正确渲染的合法值变成硬失败。
- **字符串/注释不是数值**：`{"note":"1e-400"}`、`# note: 1e-400` → 零候选。

#### 测试

`core/src/json_num.rs` 22 例 + `cli/src/output.rs` 7 例 + `cli/src/args.rs` 8 例 +
`cli/src/server.rs` 4 例 + `cli/src/context.rs` 4 例 + `core/src/manifest.rs` /
`variables.rs` / `asset/preset.rs` 各若干。合计 **1020 passed / 0 failed**，
生产口径行覆盖 **91.69%**。

> **曾标记为另开 issue，已在「批次二十三」修复**

### 批次二十三：`nc_fixed` / `nc_signed` 精度不足即报错（`ERR-NUM-PRECISION`）

`src/filters.rs` 的 `nc_fixed(N)` 会把**真值非零**的量渲染成**全零串**且不报错：

```
1e-4 | nc_fixed(3)  ->  "0.000"          无报错
U_RC=0.04 经 nc_fixed(1) ->  "Z-0.0"     无报错
```

坐标静默变 `0` 在机床上是**撞刀**，正落在「宁可渲染失败，也不要静默产出错误 G-code」红线上。
这是「批次十八」刻意留下的 `ERR-NUM-PRECISION`（下溢解决后，格式化精度不足成为同一失效模式的第二条路径）。

#### Fixed

- **判据**：真值非零且**舍入后的输出串全为零** → 返回 `minijinja::Error`，渲染中断。
  改动仅 `src/filters.rs`（+249 行），`Cargo.lock` 零变化。
- **负零归一后置**：`nc_fixed` 的负零归一从「舍入前浮点判零」改为「**舍入后字符串判零**」，
  与 `nc_signed` 在 P2-3 的做法同源 —— 上一轮漏同步正是本次缺陷的一个成因。
- **模板/YAML 治理本次仍不做**（设计稿 §13 裁定 3）：给 `U_RC` 加 `min` 会误挡工艺合理的
  `0.04mm` 首刀深度 —— 机制修复后落带即报错，无需治理关节。

#### 关键行为（已有测试钉住）

- **必报错**：`1e-4|3`、`5e-324|3`、`U_RC=0.04` 的真实路径、负值。
- **不误伤**：真零 / 负零逐字节相等；舍入向上（`0.0005|3` → `"0.001"`）不报错。
- **三个 tie 钉子**：`0.5|0`、`5e-7|6`、`5e-8|7` **必须 Err** —— 它们是银行家舍入
  恰好取到零串的点（N=0 时 `format!("{:.0}", 0.5)` 取偶得 `"0"`）。
  **这不是回归**，单测注释与设计稿 §1.5.1 双处标注为「有意行为」。
- **判据同源**：`nc_fixed` 与 `nc_signed` 对 16 组输入的 `is_err` 必须一致。

#### 判据唯一性（设计稿 v2.1 §3.1.0）

判据 **`value != 0.0 && 舍入后输出串全为零`（字符串判零，FORM_A）**；
**禁止**量级式 `|v| < 0.5 * 10^(-N)`（FORM_B）。二者在 `N=0/6/7` 的 tie 点结论相反：
FORM_B 在实测中 `<` 恒为假（f64 真值与十进制字面量在 tie 上错位），会放过本应报错的输入。
**代码中出现 `powi` / `10f64.powi` 量级比较即视为 P0 回归。**

#### 证据

- **golden**：46 个文件逐字节不变（设计稿 §2.4 用真 golden 值逐 case 复算，弃用手造样本）。
- **反向验证**：注入 FORM_B 变异体后，两个 tie 钉子测试**如期变红**（钉子有效）。
- 设计稿：`docs/err-num-precision-design.md`（v2.1）+ 类图/时序图两张 mermaid。

---

### 批次二十四：派生参数未命中表项不再静默取 `fallback`（第五轮 P1-2）

`docs/CODE_REVIEW_2026-09-23.md` P1-2。`core/src/derive.rs` 的 `compute()` 此前对
**「源参数提供了取值但未命中表项」** 也走 `fallback`：

| 源参数状态 | 修复前 | 修复后 |
| --- | --- | --- |
| **未提供**（`None`） | 取 `fallback` | **不变** —— 取 `fallback`，没有则 `MissingSource` |
| **提供了但未命中表项** | 取 `fallback`（静默） | **一定报错** `NoMatch`，**不看** `fallback` |

危害路径：纯派生链里 `tip_model` **不出现在模板正文**，`check_var_values` 不遍历它，
于是白名单 / 类型 / 区间**一个都不跑**。用户把型号拼成 `DM99_UNDEFINED`，
拿到的是 DM24 的深度（`fallback: 29.61`）且**无报错** ——
中心孔深度错 = `I_R9[80]` 顶紧位置错 = 机床顶着工件走错位置。

区分点不是数值、而是**调用方是否给过这个值**：「用户没选型号，按 DM24 处理」是工艺意图，
必须保留；「给了一个表里没有的值」是输入有误，不能拿看似合理的默认值掩盖。

#### Changed

- `fallback` 语义收窄为**仅用于「源参数未提供」**；`DeriveError::NoMatch` 的文档
  同步改为「提供了但未命中表项」（此前写的是"且规则没有 `fallback`"）。
- 真实配置 `templates/variables.yaml` 的 `tip_depth` 规则**不受影响**：它有 `fallback`
  且 `options` 即白名单，「未提供 → fallback」仍成立；「提供了未命中」此前无合法用途。

#### 证据

- **反向验证**（既有约定）：临时把 `None` 分支还原成 `rule.fallback.clone().ok_or_else(...)`
  后，新用例 `provided_source_outside_whitelist_errors_instead_of_fallback` **如期变红**
  （实得 `Ok(29.61)`，正是被修掉的静默兜底），恢复实现后转绿。
- 边界钉子 `falls_back_when_source_is_not_provided`：**「未提供」仍走 fallback**，
  防止修复顺手把工艺意图一起改成报错。
- 夹具修订：`chained_derive_uses_derived_value_not_spec_default` 原给 `tip_model` 的
  默认值是 `"未知型号"`（一个不在表项里的值），靠被修掉的兜底才得到 29.61；
  改为合法型号 `DM24`，测试意图（派生值 vs 规格默认值）不变。
- 全套 11 道门禁绿：测试 **1063 passed / 0 failed**（+2）、生产口径覆盖率
  **92.62%**（阈值 91%）、`Cargo.lock` 零变化。

---

### 批次二十五：零件定义未知字段一律拒绝（第五轮 P2-3）

`docs/CODE_REVIEW_2026-09-23.md` P2-3。`PartSpec` / `PartOp` / `PartOpOptions`
**都没有 `deny_unknown_fields`**，而 `ParamSpec` / `ParamOverride` 有 —— 同一套规格类型
里收紧口径不一致。字段名写错的后果分三档，逐档比「解析失败」更危险：

| 写错位置 | 写错前的后果 | 危害 |
| --- | --- | --- |
| 顶层（`params` → `parameters`） | 静默忽略 | 整份定义的程序级参数全丢，仍照常生成 |
| `ops[]`（`template` → `tpl`） | 静默忽略 | **该工序「少一道」却照常成功**，产出缺工序的零件程序 |
| `ops[].options`（`line_numbers` → `lineNumber`） | 静默变成"不覆盖" | 以为开了行号，实际没有 |

#### Changed

- 三个 struct 均加 `#[serde(deny_unknown_fields)]`；旧键名 `operations`
  **不是别名**，写它现在直接解析失败并列出可用字段（`LEGACY_OPS_FIELD` 的文档
  同步改为明确"不被接受"）。
- **接受字段清单**：顶层 `name` / `default_machine` / `params` / `ops`；
  工序级 `template` / `params` / `machine` / `options`；
  `options` 内 `line_numbers` / `add_header_comment` / `strip_blank_lines` / `ascii_only`。
- 既有测试 `part_generate_legacy_operations_key_is_not_silently_accepted`
  （`cli/src/server.rs`）断言改写：失败原因从「解析成功但 `ops` 为空 → 缺少工序」
  变为**解析阶段点名未知字段** —— 后者才是对的，用户写错的是**字段名**，
  说"你没给工序"会把人引到错误方向。

#### 证据

- **反向验证**：临时移除三处 `deny_unknown_fields`，新增的 4 条拒绝用例
  **全部如期变红**（`unknown field` 判定失效），对照组
  `known_fields_still_parse_after_unknown_field_lockdown` 仍绿；恢复后转绿。
- 端到端新增 `part_generate_rejects_unknown_field_in_part_file`
  （`cli/tests/cli_e2e.rs`）：CLI **非零退出**且**不写出任何产物**。
- **全仓扫描对拍**：既有的零件 JSON 夹具（`cli/tests/cli.rs`、`cli_e2e.rs`）、
  前端契约与示例（`ui/src/31_script_api.part.html`、`32_script_ui.part.html`
  的 `BATCH_EXAMPLE`）都只用已知字段，无一处需改。
- 文档订正：`docs/archive/legacy/REAL_PART_WALKTHROUGH.md` §5.3 的 JSON 样例顶层还写着
  `part_name`（§6.1 已说明它已被规整进 `params`）—— 收紧后照抄该样例会直接报错，
  已改为正确形状并加注。
- 全套门禁绿：测试 **1069 passed / 0 failed**（+6）、生产口径覆盖率
  **92.66%**（阈值 91%，较上一批 +0.04pt）、`Cargo.lock` 零变化。

---

### 批次二十六：行号撞上限不再静默（第五轮 P2-1）

`docs/CODE_REVIEW_2026-09-23.md` P2-1。`postprocess` 在 `line_no + step` 超过
`max_line_number`（或 `checked_add` 溢出）时**直接跳过编号**，程序照常生成 ——
产物每行都还在、看起来完全正常，只是**后半段没有行号**。用户没有任何渠道察觉。

#### Added

- **`GenerationOutcome`**（`core/src/pipeline.rs`）：`{ text, end_line_number, warnings }`。
  告警**不进正文**（正文是 G-code，塞提示会产出非法程序）、**也不是硬错误**
  （程序本身完整可用，阻断渲染的代价大于收益），只能由调用方呈现。
- 两个新的公开入口：`generate_outcome` / `generate_lenient_outcome`。
  `generate` / `generate_with_cursor` / `generate_lenient_with_report` **签名不变**
  —— 四十余处调用点不必为一个新增字段集体改签名。
- **呈现落点**：`nctool render`（stderr `warning: …` + JSON `warnings`）、
  `nctool part generate`（逐工序汇总，带「工序N（模板名）」前缀）、
  `POST /api/render` 与 `/api/part/generate`（响应 `warnings` 数组）。
  后处理告警**无条件打印**，不受 `--verbose` 控制 —— 静默正是本条缺陷的成因。

#### Fixed

- 派生未命中的错误文案去掉了「且规则未声明 fallback」（那是 P1-2 之前的行为）：
  带上它会误导用户以为"声明个 fallback 就能放行"，把拼写错误重新变回静默兜底。

#### 行为不变（有测试钉住）

- 撞上限后**内容照常写出**、游标停在最后写入的行号、告警**只报一次**
  （第 3 行撞上限后第 4、5…行都会撞，逐行报会刷爆报告）。
- 未开行号 / 未撞上限 / 溢出以外的情形**一律无告警**（对照组测试）。

#### 证据

- **反向验证**：临时清空告警后，4 条新用例（`hitting_line_number_cap_warns_…`、
  `cap_warning_is_emitted_once_…`、`line_number_overflow_warns_…`、
  `part::line_number_cap_warning_names_the_operation`）**全部如期变红**。
- 端到端新增 `render_warns_when_line_number_cap_is_hit` +
  对照 `render_stays_silent_when_line_numbers_are_under_cap`
  （`cli/tests/cli_e2e.rs`）：CLI 退出码 0、stderr 含 `warning:` 且回显上限值。
- 全套门禁绿：测试 **1079 passed / 0 failed**（+10）、生产口径覆盖率
  **92.55%**（阈值 91%，较上一批 −0.11pt，仍高于阈值 1.55pt）、`Cargo.lock` 零变化。

---

### 批次二十七：两项裁定（校验覆盖面缺口 / 覆盖率阈值）

阶段二任务 ②⑤ 的收口，**均不含运行时行为改动**。

#### 裁定一：校验覆盖面缺口 —— **不改遍历口径**，记为后续项

`docs/CODE_REVIEW_2026-09-23.md` §6 提出"`check_var_values` 只查被引用的变量，
导致只参与派生的参数约束全部失效"。结论是**原文举证不成立**，三条实测依据：

1. `templates/machines/index_g420/dg_cal_ir9.j2:28` **确实引用了** `tip_model`，
   白名单本来就拦（实测报 `取值 "DM99_UNDEFINED" 不在候选项内 …（第 28 行第 14 列引用）`）；
   P1-2 之后派生又加了一道硬失败，两条路径都已覆盖。
2. 覆盖面**传递解析 `{% include %}`**：漏传 `Z_START`（只在
   `turning/_undercut_common.j2:17` 出现）时，`undercut_fs.j2` 照常报
   `必选参数缺失（…）（第 17 行第 7 列引用）` —— 行号指向子模板。
3. 剩下未覆盖的只有**全链路都未引用**的参数，其取值**不进入产物**；把它们的值级
   错误升级为阻断渲染的 Error 是纯噪声，且与 `SpecInert` 现有的"只警告"口径冲突。

裁定写入 `docs/CODE_REVIEW_2026-09-23.md` §6.1，含重开条件
（出现"影响产物但静态提取看不到"的新形态时重开）。

#### 裁定二：覆盖率阈值 —— **维持 `--min 91`**，本轮不上调

实测 92.55%（8198/8858），余量 1.55pt ≈ 137 行。上调到 92% 会把余量压到 ~49 行，
一次中等改动就红 —— "经常误报的门禁会被当成噪音忽略"，质量信号反而丢失。
最低文件仍是 `cli/src/commands/lint.rs` 83.61%：单点洼地靠补测试解决，不靠抬门槛。
下次评估触发条件：连续两个发布周期实测 ≥ 93%。
裁定写入 `docs/CONTRIBUTING.md` 覆盖率一节。

---

### 批次二十八：发版可重复性（U-22 / U-24 / U-23 / U-25 / U-16）

**无运行时行为改动**。全部落点在 `docs/archive/legacy/RELEASE.md` 新增的「发版清单（Runbook）」
（§2.5）与「破坏性变更归档」（§4.5）。

| 项 | 处置 |
| --- | --- |
| **U-22** 发版入口 | 唯一入口 = **推 tag 交 CI**；本地手工发布路径废止。原因：上一轮「推 tag + 本地 publish」让 CI 重复发布同版本 → `crate version already uploaded`（发布物不受影响，但流程要消除这种"靠人分辨真假失败"） |
| **U-24** 发版顺序 | `tpl → core → cli` 为**硬顺序**，前一个 Publish 绿了再推下一个；附三处**版本同步点**表（改 `Cargo.toml` 时必看的联动位） |
| **U-23 / U-25** 发布包 | **显式声明发布包不含可运行测试资源**；`cargo install` 与下游库消费**不受影响**。给出**严重度前置检查**：先看该测试是否在 `#[cfg(test)]` 内跨 crate 目录读资源 → 是则降级为整洁项。迁移测试资源进各 crate 的方案**不做**（违反单一来源硬约束） |
| **U-16** 破坏性变更 | 归档至 `nctool-core 0.4.0`：B-1 `derived_names` / `invalidate_analysis` 收窄（含迁移说明要点）；B-2 候选 `TemplateEntry::source_text` 私有化（B-1 的根因项，同窗口做） |

#### 发版演练结果（2026-09-24，不真实发布）

| crate | 结果 |
| --- | --- |
| `nctool-tpl` 0.4.0 | ✅ 66 files / 459.5KiB，验证编译通过 |
| `nctool-core` 0.3.0 | ✅ 32 files / 824.8KiB，验证编译通过 |
| `nctool-cli` 0.3.0 | ❌ **RC=101，46 个编译错误** |

`cli` 失败**不是包内容问题**，而是 `cargo publish` 的验证步骤剥掉 `path` 依赖、
改用 crates.io 上的已发布版本编译 —— 本地 HEAD 新增的 `asset` / `part` /
`json_num` 模块与 `GenerationOptions::line_number_start` 在已发布的
`nctool-core 0.3.0` 里都不存在。

**这条把 U-24 的顺序约束从"经验"变成"实测"**：core / tpl 没发之前，cli **一定**
发不出去，且失败形态是 46 条看似代码坏了的编译错误，而不是一句"依赖版本未发布"。
故发版硬门槛定为：§2.6 三条 dry-run 全绿才允许推 cli 的 tag。

---

### 批次二十九：文档类整洁项（U-17 精度上限标注 / U-15 死代码复核 / U-19 硬编码清理）

#### U-17：`as_f64()` 在 `>2^53` 上丢精度 —— **文档化标注上限收口**

`ParamValue::as_f64`（`core/src/model.rs`）把 `Integer` 转 `f64`，
`|v| > 2^53`（9 007 199 254 740 992）时按 IEEE754 就近取偶，
`min` / `max` 区间比较最多**差 1**。

**不修，改为标注**：CNC 参数的实际量级（坐标 mm、转速 rpm、进给 mm/min、
程序号 ≤ 9999、行号 ≤ u32）离 2^53 有 **12 个数量级**；为一条到不了的路径
引入 i64/f64 双比较分支，反而给真正会走的区间比较增加分叉。
文档写明**精确比较请直接对 `ParamValue::Integer` 做 i64 比较**。
边界行为由新增测试 `as_f64_precision_limit_is_documented` 钉住
（断言**舍入方向**，而非"会不会丢"—— 后者是 IEEE754 必然结果，前者才是
实现被改写时可能悄悄变化的东西）。

#### U-15：死代码复核 —— **两项都关闭**

- **`extract_both`**：它只是"合并两套遍历"的**手段**，而合并本身已由 **U-14 裁定
  "有意不做"**（`extract.rs` 最安全敏感，合并属"改对了没收益、改错了很难发现"）。
  手段随目的一起取消，不再单独挂账。
- **死代码**：`clippy --workspace --all-targets -- -D warnings` 是**阻断门禁**，
  未使用的私有项直接编译失败；全仓 grep `#[allow(dead_code)]` / `#[allow(unused…)]`
  **零命中**，说明没有被豁免的已知死代码。公共 API 里"无生产调用点"的
  （`derived_names` / `invalidate_analysis`）不是死代码而是可见性问题，
  已归入 §批次二十八 / `docs/archive/legacy/RELEASE.md` §4.5 B-1。

结论记入 `docs/CODE_REVIEW_2026-09-18.md` 的"仍开放"段落（原位标注，不新开文件）。

#### U-19：剩余硬编码清理 —— 项数与覆盖率改为"不硬编码"

`CONTRIBUTING` §4 与 README 早已改为不硬编码项数（本文档曾因此同时出现过
344 / 516 / 492 三个互相矛盾的版本）。本批把**其余散落处**一并清掉：

| 文件 | 处置 |
| --- | --- |
| `overview.md` | 质量基线表加"快照 + 以 CI job summary 为准"声明；数字标为 2026-09-24 阶段二收口时快照 |
| `docs/PROJECT_STATUS.md` §0 | 测试基线与覆盖率同上；**门禁阈值 ≥ 91% 作为常量保留**（它不是会漂移的实测值） |
| `docs/CONTRIBUTING.md` | 覆盖率一节去掉写死的基线，只留阈值与"以 CI coverage job 为准" |
| `docs/SYSTEM_DESIGN.md` | 测试/覆盖率同上；顺带订正两处陈旧事实（`part` 早已不是占位、CLI 子命令缺 `lint`/`preset`/`part`） |

**区分「常量」与「实测值」**：门禁阈值、MSRV、模板数这类**由代码或 CI 固定**的
可以写死；测试项数与覆盖率**每次提交都会变**，一律指向 CI。

---

## [nctool-tpl 0.4.0] · [nctool-core 0.3.0] · [nctool-cli 0.3.0] - 2026-09-18

「NCTool_V3 模板资产整合 + 参数规格系统 + 架构评估 P0/P1 收口」

三个 crate 同步发版（tpl 0.3.2 → 0.4.0、core 0.2.2 → 0.3.0、cli 0.2.2 → 0.3.0）。

**关于本节的分节方式**：本轮改动在 crate 之间高度交织——「文件模板的参数规格外部化」
同时改 `core/src/manifest.rs` 与 `cli/src/context.rs`，「渲染入口的有限性闸门」同时改
`core/src/registry.rs` 与 `nctool-tpl` 的再导出，覆盖率门禁/CI 则不属于任何单个 crate。
强行按 crate 切分会让同一条改动被拆到两处或被迫归错。故本节**沿用按主题分节**，
每条条目内均标注涉及的文件路径，便于按 crate 检索。三个 crate 的 tag 分别是
`nctool-tpl-v0.4.0` / `nctool-core-v0.3.0` / `nctool-cli-v0.3.0`。

### Added

- **`inspect` 展示参数规格**（`cli/src/commands/inspect.rs`）：规格（类型 / 候选值 /
  区间 / 整数 / 条件必选 / 派生）在 `validate` / `render` 时是**真的会拦人**的，
  此前却只能靠"触发一次报错"来发现。现在 `inspect` 直接列出来，并按
  **必选 / 条件必选 / 派生 / 可选**四桶分组——规格引入后必选性不再只有两态，
  混在两桶里会误导用户去填一个不该填的参数：
  - 每行：`名字  行 L 列 C  类型  约束摘要  描述`；候选值超过 6 个折叠为 `…（共 N 项）`
  - 末尾提示"未标注类型（`ParamKind::Any`）"的参数——这类参数不做类型检查，
    写错要到渲染期才暴露
  - JSON 输出的规格字段**复用 HTTP API 的 `spec_json`**，避免两处形状各自漂移

- **`--param k=v` 按规格归一取值**（`cli/src/args.rs`）：argv 里没有类型信息，此前
  只按"像不像数字"推断（`5010` → 数值）。字符串型参数若值恰好形如数字
  （`U_CTB` 的 `1631`、`U_ID` 的 `[42]`）会被推断成数值 → 类型不匹配，用户只能改用
  `--params-file` 传 JSON 字符串或加 `k:s=` 后缀。现在按规格归一，
  规则是**先白名单、后类型**：候选值命中哪种解释就用哪种（`U_CTB` 的 `1631` 与
  `"DECKEL"` 各命中一半），都没命中则按声明的类型（`String` 保持字符串）。
  **显式后缀 `k:s=` / `k:n=` / `k:b=` 仍优先**——那是用户明确表达意图的通道。

- **Web UI 参数表单消费规格**（`ui/index.html` + `cli/ui/index.html`）：
  - **候选值参数渲染为下拉框**（此前是文本框，非法值要等校验才报错）
  - **派生参数移出表单**，改为底部一行"由系统派生（无需填写）：tip_depth（…）"——
    此前它以普通输入框出现，填了会被派生值覆盖
  - **条件必选参数标注触发条件**（`条件必选：side = "Right" 时必填`）
  - 表单取值按规格归一，规则与 CLI 的 `--param` 一致（前端 `coerceParamValue`）

- **`ui/index.html` 与 `cli/ui/index.html` 一致性测试**（`cli/tests/cli.rs`）：
  前者是 `file://` 演示版、后者被 `include_str!` 嵌进二进制（`nctool ui` 提供的那份），
  是同一份页面的两份拷贝。手工同步迟早漂移，届时"改了页面却看不到变化"很难查——
  加断言把漂移变成测试失败。

- **派生参数 `derive`**（`core/src/derive.rs`）：把**查表型换算**从模板搬到规格，落实
  「模板只做变量替换，计算在 Rust 侧完成」这条核心原则。首个用例是
  `machines/index_g420/dg_cal_ir9.j2` 的 `tip_model → tip_depth`（12 项表，回退 29.61 = DM24）——
  此前这张表写在模板里（`{% set tip_depth_map = {...} %}` + `map[k] | default(v)`，
  为绕开 minijinja 的 map 无方法限制，即约定 R6），现在数据表**只此一份**（`variables.yaml`），
  改表只改 YAML：
  - 声明：`ParamSpec.derive: DeriveRule { from, table, fallback }`；YAML 侧与 `options` 一样
    走稀疏覆盖（`ParamOverride.derive`），因此变量库与清单 `params` 都能声明
  - **系统注入语义**：派生参数不要求调用方提供（与 `machine` 同类）；调用方提供了则
    **派生值恒胜**并报 `ShadowedSystemVar` 警告（派生值必须与源参数一致——表里说
    `DM24 → 29.61`、用户填 `10`，允许覆盖就等于允许"型号与深度对不上"的 G-code）
  - **失败不静默**：源参数缺失/未命中表项且无 `fallback` → 新 `IssueKind::DeriveFailed`
    （Error），**不取 0**（中心孔深度取 0 会让 `I_R9[80]` 顶紧位置算错）；且不再对同一
    参数叠报"缺失"
  - 求值时机：**校验前**（`check_vars`，两个校验入口共用）与**渲染前**（`pipeline` 两条路径），
    口径一致；顺序为**先派生、再规格默认值兜底**（源参数可能靠默认值才存在）
  - **派生值照常过类型/白名单/区间检查**——派生不是绕过校验的后门
  - 表键比较走 `ParamValue::matches_option`（数值/整数跨变体按数值相等），
    表键写 `8` 也能命中调用方传来的 `8.0`
  - 源参数为列表类型时明确报错（`UnusableSource`），而不是静默落到 `fallback` 把
    "传错类型"掩盖成"用了个看似合理的默认值"
  - `PipelineError::Derive` 兜底渲染路径（校验阶段已拦截，正常不可达）

- **变量库 `templates/variables.yaml`**（`core/src/variables.rs`）：**按变量名**生效的全局参数规格。
  同一变量在多台机床/多个模板上含义一致时只写一次，不必在 12 个模板里重复声明 `U_Q` 的候选值。
  内容从源项目 NCTool_V3 的 `configs/variable_repo.json`（62 个变量）导入：
  - **三级优先级**：清单 `templates.yaml` 的 `params`（本模板覆盖）> `variables.yaml`（全局）
    > 头部 `{# PARAMS: #}`（模板局部）。三者复用同一套稀疏覆盖机制（`ParamOverride` +
    `merge_params`），"只写要改的字段"这一约定在三个层级完全一致
  - **生效范围**：只对**模板确实引用了**的变量生效（头部声明的 + 源码里引用到的），
    因此库里可以放心放全局变量——没被引用的不会注入规格，也不会触发
    "规格声明了未引用参数"告警
  - 支持 `variables:` 键与顶层列表两种写法；**同名重复定义直接报错**（静默覆盖会让
    "改了定义却不生效"变成难查的问题）
  - **三条刻意的不导入**（都为了不产出"跑得通但错误"的 G-code）：
    ① **不导入默认值**——源库默认值是针对特定样件的预填值（`U_A = 141.25` 是那根轴的
    长度），规格默认值会让**缺参静默通过**，用户少填一个零件尺寸就会拿到另一根轴的程序；
    ② **不导入描述**——头部描述是写给这个模板的，源库描述以 YAML 注释保留；
    ③ **`read_only` 变量只导入类型、不导入候选值**——源库的 `read_only` 意为"由机床设置/
    派生计算决定"，其 `options` 是某次装夹的**取值快照**（`U_ANG: [20]`、`R1: [4000]`），
    当作用户可选集会禁掉合法的换刀/换料调整；真正由用户选择的变量（键槽宽度系列、
    槽宽系列、刀号、开口方向、顶尖型号）才导入 `options`
  - 导入后 19 个 INDEX G420 模板**无需改动头部**即获得类型与白名单（头部只写
    `name 必选 描述` 的形态由 `ParamKind::Any` 兜住）
  - 混有字母与数字的刀具标识（`U_CTB: 1631 / DECKEL`、`U_RTB: CT1017 / 5010`）
    用 `kind: any` + 混合候选项——数值与文本各自按值语义比较，使 CLI 的
    `--param U_CTB=DECKEL` 与 `--param U_FT=5010`（推断为数值）都能命中

- **`IssueKind::SpecInert`**：规格中存在**永不生效**的声明时报**警告**。两类成因：
  ① 规格声明了模板未引用的参数（参数名拼错，或模板改名后头部/变量库/清单未同步）；
  ② **约束与声明的类型不匹配**——`min`/`max`/`integer` 只对数值生效，
  `check_value_constraints` 对非数值类型在 `as_f64()` 处提前返回，声明在
  `String`/`Bool`/`List` 上时永不执行（`Any` 不算：它的值可能恰好是数值，约束按值生效）。
  与 `Unused`（用户多传了参数，无副作用）**必须区分**——混用会让两者都失去意义

- **`ParamKind::Any`**：表达"已声明但未标注类型"——不做类型检查，但 `options` /
  `required_if` / `default` 照常生效。存在的意义是让"只知道有这个参数、还不知道类型"的
  迁移模板也能参与白名单与条件必选；若强行猜类型会让合法输入被误拒，若不生成规格则连
  白名单都声明不了。**这是过渡态**，类型应从图纸/源变量库补齐

- **条件必选参数**（`ParamSpec::required_if` + `IssueKind::ConditionalSkipped`）：互斥分支参数
  （同一时刻只有一个分支可达）在静态变量提取下会被判为"全部必选"。实测 `undercut_fs.j2`
  只做右侧槽的用户被要求再填一个左侧专用 Z 值，历史规避手段是 `| default(0)`——而那会
  **静默产出 `Z0`**。现在把"哪个分支用到哪个参数"显式声明出来：
  - 判定：控制参数生效取值（用户提供值 > 规格 `default`）命中触发值 → 必选；
    未命中 → 可缺失，并报**提示级** `ConditionalSkipped`（与 `Missing` 严格区分——
    混用会让"缺参"统计虚高）
  - 不可判定（控制参数未提供且无规格默认值）→ **保守判必选**：分支可能被走到，
    宁可多要一个参数，也不能放过缺失
  - 已知边界：控制参数若靠模板内联 `| default(...)` 兜底，取值无法静态求得，同样落到保守判必选

- **`ParamValue` 反序列化接受裸标量**：手写 YAML 里 `options: ["闭口", 8, 12.5]`、
  `values: ["Right"]` 才是自然写法，强制带标签（`{type, value}`）会把配置文件变成机器码。
  两种形式混用亦可；**序列化恒为带标签形式**（无歧义），且标签统一为小写
  （`{type: integer, value: 8}`，与 `ParamKind` 一致），读取时大小写不敏感以兼容历史载荷。
  带标签形式仍做**类型自洽校验**：`{type: integer, value: 8.5}` 报错而不是静默截断成 `8`

- **文件模板的参数规格外部化**（`core/src/manifest.rs` + `cli/src/context.rs`）：目录模板此前
  **恒为空规格**（`vec![]`），于是 `validate` 对 `Z_START=abc` 这类错误直接放行
  （实测"校验通过：无问题"），`min`/`max`/`integer`/`options`/`required_if` 对用户模板全部失效——
  模板头部写着的参数表只是注释。现在两份来源合成规格：
  - **模板头部 `{# PARAMS: #}`** 解析为 `ParamSpec`（`name`/类型/必选性/描述）。
    兼容两种现存写法：`name 必选 描述` 与 `name type required 描述`，可混用；
    必选标记接受 `必选`/`可选`/`条件必选`/`required`/`optional` 及**分支限定词**
    `可选(ES)`/`必选(FS)`（限定词保留到描述里）。类型可省（记为 `ParamKind::Any`）。
    参数表另用 200 行为界（`NAME`/`DESCRIPTION` 仍限前 10 行）——机床模板十余个参数，
    收尾 `#}` 会落到第 10 行之后
  - **清单 `templates.yaml` 的 `params` 稀疏覆盖层**：补头部表达不了的**约束**
    （`min`/`max`/`integer`/`options`/`required_if`/`default`）。`ParamOverride`
    字段全为 `Option`，因此能区分"没写"与"写成默认值"，只覆盖写了的字段；
    拼错字段名直接报错（`deny_unknown_fields`）
  - 参数表里**无法解析的行会告警**（`warning: <模板>: 第 N 行无法解析…`）而非静默跳过——
    静默丢一行等于静默少一条参数约束

- **模板清单与移植模板**：`templates/templates.yaml`；`turning/undercut.j2`（ES/FS 越程槽，
  完整版）、`turning/undercut_es.j2` / `undercut_fs.j2`（单分支精简版）、
  `turning/_undercut_common.j2`（公共起始段片段）、`grooving/circlip_groove.j2`（卡簧槽）、
  `machines/index_g420/dg_cal_ir9.j2`（INDEX G420 的 R 参数表初始化段）

- **模板整合方案文档**：`docs/TEMPLATE_INTEGRATION_PLAN.md` —— 对源项目 NCTool_V3 的
  结构与配置分析、模板四类分级（原子子程序 / 通用参数化 / 计算密集 / 机床专有）、
  可复用资产逐项判定（直接移植 / 改写后移植 / 不可移植）、五阶段落地路线、风险表；
  §4.4 记录实施中实测发现的三个能力缺口

### Fixed

- **规格默认值的类型从不校验**（`core/src/validate.rs`）：`check_value_constraints` 对非数值类型
  在 `as_f64()` 处提前返回，因此 `Number` 规格配 `String` 默认值会一路静默通过，
  直到渲染时把字符串塞进 `nc_fixed` 才炸——而 ARCHITECTURE 文档声称会查类型。
  现在类型不符报 `TypeMismatch`（且不再叠区间/白名单噪声）

- **渲染错误丢失根因**（`src/error.rs`）：嵌套 `{% include %}` 失败时只报外层包装
  `渲染错误: could not render include: error in "turning/_undercut_common.j2" (in turning/undercut_fs.j2:24)`，
  既不知错在子模板哪一行、也不知错的是什么——实测完全无法定位。现在沿
  `std::error::Error::source()` 链把各层描述以 ` ← ` 追加，末段即根本原因

- **无 `detail` 的渲染错误不可诊断**：minijinja 对部分运行期错误（如对字符串取负）不设 `detail`，
  消息退化成 `invalid operation (in uz_dj_x.j2:83)`。现在 `detail` 为空且错误发生在所传源码
  对应模板时，用 `range()` 取出**出错表达式片段**补进消息
  （实测 `invalid operation (in …:83)（出错表达式：-U_A）`）

- **`render` 的校验失败输出自相矛盾**（`cli/src/commands/render.rs`）：整份报告被塞进
  `CliError::message`，而统一错误输出只给**首行**加 `error: ` 前缀——多行报告的首行会被
  当成错误摘要，提示行排在最前时更会输出 `error: 提示 …`。现在报告走 **stderr**
  （stdout 留给 G-code），错误行只给一句"参数校验未通过（详见上方报告）"

- **`{# PARAMS: #}` 的第三种标记写法未被识别**：`undercut.j2` 用 `可选(ES)`/`可选(FS)`
  标注分支专用参数，此前会为每行刷一条解析告警（且每次 CLI 调用都打印）。

- **模板清单与目录递归**（`core/src/manifest.rs` + `cli/src/context.rs`）：模板元数据
  （名称 / 描述 / 可见性 / 输出文件名与后缀 / 分类 / 机床 / 评审状态）从 Rust 源码外部化到
  `templates/templates.yaml`，新增模板只需放文件 + 加清单条目，**不必改代码重编译**。
  目录模板改为**递归发现**（`templates/` 下任意深度的 `*.j2`），以相对路径为模板名
  （如 `turning/undercut.j2`），支持分类子目录与机床方案包。元数据按
  **清单 > 模板头部注释（`{# NAME: #}` 等）> 文件名/目录名**三级回退解析。
  安全性：跳过隐藏项（`.` 开头）、清单文件自身、符号链接逃逸路径（`canonicalize` 后
  必须仍在模板根内）

- **模板可见性与机床方案包过滤**：`templates list` 新增 `--all`（含隐藏模板，以 `·` 标记）
  与 `--machine <id>`（仅暴露该机床的专用模板）。`visible: false` 用于「完整可用但不出现在
  选择列表」的模板（功能模块、机床初始化段）；机床专用模板须声明 `machine`，未选中该机床时不可见。
  JSON 输出补齐 `visible` / `output_filename` / `output_extension` / `machine` / `status` / `source`

- **列表参数类型**（`ParamValue::List` + `ParamKind::List`）：批量工序模板（如遍历
  `z_offsets` 的卡簧槽）需要列表入参，此前只有数值/字符串/布尔四种类型无法表达。
  `--params-file` 的 JSON 数组递归解析（支持嵌套），`ParamKind::List` 只校验"是不是列表"、
  不校验元素类型（元素约定由模板自身表达，避免静态声明与模板漂移）。对象类型仍被拒绝
  （`ParamValue` 是扁平值模型），需要结构时建模为平行列表

- **枚举参数与候选项白名单**（`ParamKind::Choice` + `ParamSpec.options` +
  `IssueKind::NotInOptions`）：源项目变量库里的 `options` 白名单此前只能写在模板注释中，
  非法工艺选项（`U_FX` 闭口/左开口/右开口、`U_Q` 0/8/10/12.5、`tip_model` B4/DM24）
  会一路渲染成与图纸不符的 G-code。现在在校验阶段硬拦：
  - `ParamSpec::options: Option<Vec<ParamValue>>` + `with_options()` builder，
    `None`/空列表 = 不约束，**旧 YAML/JSON 规格无需改动**（`skip_serializing_if` 保证
    未声明时不写出该字段）
  - 白名单对**所有类型**生效而不只 `Choice`：`Number + options` 表达数值枚举，
    `String + options` 表达文本枚举
  - `ParamKind::Choice` 的**类型匹配有意放宽为"任意标量"**——真正的约束是白名单而非类型，
    否则数值枚举（`0 / 8 / 10 / 12.5`）会先被类型检查挡掉、永远走不到白名单比较。
    `List` 不在其列（列表不可能是扁平白名单的成员）
  - 成员比较 `ParamValue::matches_option`：同变体同值；数值/整数**跨变体按数值相等**
    （`Integer(8)` ≡ `Number(8.0)`，避免 CLI/JSON 把 `8` 解析成 `8.0` 造成假拒绝）；
    文本 `"8"` 与数值 `8` 仍是**不同**候选项，不做隐式归一化
  - 非法值报 `Error` 且**不降级、不替换为默认值或首个候选项**——静默改成默认值同样会产出
    错误 G-code，违背"宁可渲染失败"的项目原则
  - 白名单检查拆为独立的 `check_value_options()`，**排在区间/整数检查之前**：
    `check_value_constraints()` 对非数值类型在 `as_f64()` 处提前返回，字符串枚举
    （白名单的主要用途）若塞进去等于永不执行
  - 规格默认值同样过白名单（写错的 `default` 会在渲染前被静默注入，用户提供的合法值反而
    用不上）；类型不匹配时不再叠报白名单错误，避免同一参数刷出噪声
  - `options_display()` 提供候选值的统一可读渲染，保证"报错里列出的候选值"与
    "实际参与比较的候选值"是同一份数据
  - HTTP API 的 `spec_json` 输出 `options` 字段，供前端渲染下拉选择

- **角度制三角函数过滤器**：`sin_d` / `cos_d` / `tan_d` / `asin_d` / `acos_d` / `atan_d`
  （`_d` = degrees）。裸 `sin`/`cos`/`tan` 保持**弧度制**（与 Rust 标准库一致）。
  动机是「度/弧度静默错坐标」风险：`sin(30)` = -0.988（把 30° 当 30 弧度）而
  `sin_d(30)` = 0.5，错误坐标会直接写进 G-code 导致撞刀。迁移 Python/Jinja2 模板时尤其危险
  ——源项目常把 `math.sin(math.radians(x))` 暴露为 `sin`（度制），与本库的 `sin` 同名不同义

- **`nc_signed(N)` 过滤器**：强制正号 + 固定小数位，`21.0` → `+21.000`、`-4.5` → `-4.500`、
  `0.0` → `+0.000`。对应源项目 Jinja2 的 `fmt_coord`（`f"{v:+.3f}"`），用于**增量坐标/
  旋转量**——部分控制器要求显式正号，省略号会被误判为绝对值。`-0.0` 归一到 `+0.000`
  （控制器对负零处理不一致）。不要用它格式化直径/进给等本无符号语义的值

- **`TemplateRegistry::extract_params(name)`**：提取模板的完整参数闭包（穿透
  `{% include %}` / `{% extends %}`）并剔除系统注入变量（`machine`）。
  此前该逻辑是私有方法、仅服务 `validate`，`inspect` 因此只能看到主模板自身的变量

### Changed

- **INDEX G420 机床方案包全部就位**：源项目 `templates/INDEX G420/` 的 **19 个模板**
  （约 2800 行）全部移植到 `templates/machines/index_g420/`，文件名统一小写化，
  并在 `templates.yaml` 中声明 `machine: index_g420` / `output_extension` / `status: unreviewed`。
  含 6 个主程序（`.MPF`）、1 个 R 参数初始化、1 个键槽倒角、4 个精铣、7 个粗铣（`.SPF`）。
  移植手法与验证见 `docs/TEMPLATE_INTEGRATION_PLAN.md` §5.5

- **`inspect` 穿透 `{% include %}`**：原先只列主模板自身的变量，组合模板的参数表会**漏项**
  （拆分越程槽后实测只显示 6 个参数，而实际需要 11 个），用户按表填参会直到渲染才报错。
  现改用 `extract_params`，并在输出末尾提示引用了哪些片段、行列号指向片段文件自身
- **`templates` 目录结构**：按类型分子目录（`general/` `milling/` `turning/` `grooving/`
  `machines/<id>/`），`demo_gcode.j2` 移至 `turning/`
- **文档同步**：`docs/archive/legacy/TEMPLATE_WRITING_GUIDE.md` 过滤器章节重写（新增 §3.1 `nc_signed`
  使用边界、§4「角度制 vs 弧度制」、§4.1「字典查表用下标不用 `.get()`」）；
  README / 模板写作指南 / 机床配置指南中的示例模板路径同步为新结构

### Fixed

- **`{% set x = x | default(v) %}` 被判为「必选参数缺失」**（`src/extract.rs`）：
  静态提取器把「模板局部变量的引用」也记进了必选集合，于是紧随其后的
  `{{ x }}`（读的是上一行 set 出的局部量）把已判定的「可选」整体翻回「必选」。
  源项目大量使用这一兜底惯用法，不修则机床模板无法渲染。现只有**外部参数引用**
  参与必选判定；`{% set total = total + x %}` 这类 RHS 自引用仍正确判为必选
  （`Stmt::Set` 的 RHS 先于目标声明求值）
- **模板头部注释不认空白控制标记**（`core/src/manifest.rs`）：`{# NAME: xxx -#}`
  的显示名会带上尾随 `-`（`templates list` 里肉眼可见）。现取值前剥离 `#}` 前的 `-`

- **`turning/undercut.j2` 互斥分支参数报"必选缺失"**：静态变量提取器不看分支条件的
  运行期取值，把 ES 与 FS 两个互斥分支引用的变量全部视为必选——用户只做 ES 型却被迫
  填 4 个 FS 专用参数。解决方案为**拆分模板**（`undercut_es.j2` / `undercut_fs.j2`
  各只含单一分支，公共段 `include` 抽取），完整版 `undercut.j2` 保留供批量场景。
  验证：拆分版在 Right/Left 共 4 种组合下输出 G-code 与完整版**逐字节一致**。
  未采用 `| default(0)` 兜底方案——那会静默产出 `Z0` 错误坐标，与本项目
  「宁可渲染失败也不静默出错」的红线相悖
- **`templates list` / `inspect` 的示例模板路径**：`demo_gcode.j2` 移动后
  E2E 测试与文档中的旧路径一并更新

### 新增的测试

- 模板清单解析（两种 YAML 形式、默认值、未知字段拒绝、反斜杠规范化、头部注释提取、
  三级回退优先级、目录→分类推断）16 项
- 头部注释空白控制容忍 2 项（带 `-#}` / 不带 `-#}`）
- 自赋值兜底的可选性 2 项（`{% set x = x|default(v) %}` 保持可选；
  无兜底的 `{% set x = x + 1 %}` 仍为必选）
- 角度制三角函数 4 项（含「度制与弧度制结果必须可区分」的撞刀回归守护）
- `nc_signed` 5 项（正号/负号/零、负零归一、与 `nc_fixed` 仅差正号、NaN 拒绝、小数位上限）
- `extract_params` 4 项（穿透 include、剔除系统变量、未找到报错、环引用不栈溢出）
- 列表参数解析 2 项（数组→列表、嵌套数组的错误定位）
- **Web UI v2 落地实现**（`ui/index.html` + `cli/ui/index.html`，两份字节一致）：按
  [docs/archive/legacy/UI_DESIGN_PROPOSAL.html](docs/archive/legacy/UI_DESIGN_PROPOSAL.html) 重构界面 ——
  结果区动作条（复制 / 下载并入结果区，紧邻其作用对象）、机床 chip 移入结果区头部并带
  「已按 &lt;id&gt; 重新生成」反馈、参数区必填进度与分组、**字段级就地校验**、
  可选参数折叠、模板卡挂载命名预设 chips、侧栏「最近使用」、长程序**工序索引**（≥40 行，
  可点击跳转高亮）、结果区状态 pill（可点击跳到校验列表）、命令面板（⌘/Ctrl+K）、
  ⌘/Ctrl+⏎ 立即生成、⌘/Ctrl+S 存为预设、&lt;768px「模板 / 参数 / 结果」分段视图、
  模态改为右侧抽屉（保留上下文）。设计令牌补齐：亮色升级为对等主题、`--text-dim` /
  `--text-faint` 提亮以达正文对比度 ≥ 4.5:1、字号/间距/圆角/动效统一
- **`output/ui-v2-acceptance.py`**：无头 Chrome 验收套件（67 项断言），覆盖全链路、
  就地校验、输出选项、工序索引、机床切换、主题、最近使用、命令面板、抽屉、分段视图
- **`docs/archive/legacy/UI_ACCEPTANCE_CHECKLIST.md` §10**：v2 走查记录（演示模式 67/67、服务模式 14/14、
  D-04 逐字节一致 2/2）与新增验收项 N-01…N-12

### Changed（Web UI v2）

- **Web UI 模式自动判定**：`API.mode` 由硬编码 `"server"` 改为按协议判定 ——
  `file://` 打开走演示模式（离线完整可用；此前双击本地文件会因 fetch 失败显示空列表），
  `http(s)://` 走服务模式。`nctool ui` 的行为不变
- **错误信息主次分层**：后端技术口径（如「必选参数缺失（模板引用且无默认值兜底…）（第 1 行第 24 列引用）」）
  的主信息改为可照做的说法（「必填，未填写」），模板行列定位降为次级信息，
  完整原文保留在 `title` 中 —— 信息不丢、主次分明
- **localStorage 访问加保护**：`file://` 与隐私模式下持久化失败不再中断界面初始化
- **E2E 契约断言同步**（`cli/tests/cli.rs::ui_http_contracts_and_frontend_mode`）：
  原先断言页面含硬编码 `mode: "server"`，改为断言按协议判定的两条分支
  （`location.protocol === "file:"` → `? "demo" : "server"`），语义等价且覆盖新行为

### Added（文档与工程化）

- **README 安装章节**：新增环境要求（Rust 1.82+、三平台）与三种安装方式——GitHub Release
  预编译二进制（含三平台产物名）、`cargo install --path cli --locked`、作为库引入
  （`nctool-tpl` / `nctool-core`，另附 git 依赖写法）；新增安装验证步骤与顶部目录导航
- **README 使用示例章节**：5 个端到端示例（内置模板浏览→查参→校验→生成、自定义模板文件、
  参数文件 `--params-file` + `--format json` 脚本集成、目录模板与 `template_dir` 配置、
  Web UI / 库调用），命令与输出均为 `nctool 0.2.2` 实测；补充「目录模板需显式指定
  `--template-dir` 或配置、模板名含 `.j2` 后缀」这一易踩点
- **贡献指南**：README 新增速览（前置阅读、环境搭建、与 CI 一致的质量门、改动同步要求、
  提交与分支约定、问题反馈渠道），完整版见新增的 `docs/CONTRIBUTING.md`
  （仓库结构、344 项测试分布矩阵、golden 刷新与复核流程、对外稳定契约、发版流程、
  Reviewer 检查清单）；新增 `.github/PULL_REQUEST_TEMPLATE.md`（PR 描述含质量门 /
  文档同步 / 工艺安全核对项）
- **文档自检脚本**：`scripts/check_docs_links.py` —— 校验 Markdown 相对链接与 heading 锚点
  是否存在（README、`docs/` 全部文档已通过检查）
- **Web UI 设计方案 v2**（设计交付物，未改动任何代码）：`docs/archive/legacy/UI_DESIGN_PROPOSAL.html` ——
  基于现有 `ui/index.html` 通读的 9 项现状诊断、信息架构（模态降级为侧抽屉、机床 chip 移至结果区
  头部、下载/复制并入结果区动作条）、设计系统（亮色对等主题与对比度修正、字号/间距/动效令牌）、
  四档响应式断点、组件规格、状态矩阵与键盘映射、可访问性目标、37 项既有验收的保留映射
  + 12 项新增验收建议、P0–P3 分阶段实施路径
- **高保真可交互原型**：`output/ui-prototype-v2.html`（单文件零依赖，可直接双击打开）——
  已实现就地校验、必填进度、预设回填、机床 chip 联动、工序索引跳转、命令面板 ⌘K、
  亮/暗主题、移动端分段视图；配套 `output/proto-smoke-check.py`（无头 Chrome 冒烟测试，
  51 项断言全过）与桌面/移动端截图

---

### 性能与质量门禁（架构评估 P0 项）

架构评估（`docs/ARCHITECTURE_REVIEW.md`）标出的三项 P0 已修复。
共同点是"同一份工作被反复重做"：注册表每次请求重建、模板每次校验重复解析、
覆盖率门禁形同虚设。

#### Performance

- **模板注册表按目录指纹缓存**（`cli/src/context.rs`）：`build_registry` 此前
  每个 HTTP 请求都执行一遍「canonicalize → 读 `templates.yaml` → 读
  `variables.yaml` → 递归遍历目录 → `read_to_string` 全部模板 → 逐模板解析
  `{# PARAMS: #}` 头部」，成本与模板数成正比。改为按
  「模板目录 + 目录树最新 mtime」缓存并共享（`Rc`）。
  **指纹不可省**：无条件长期缓存会让用户改完模板仍拿到旧注册表，
  渲染出与图纸不符的 G-code——属于本项目零容忍的"静默产出错误程序"。
  指纹取不到（IO 异常）时放弃缓存，宁可重算。
  需要可变注册表的调用方走新增的 `build_registry_fresh`（`render` 注册临时
  文件模板的路径），避免临时模板泄漏进共享缓存。

- **模板静态分析只做一次**（`core/src/registry.rs`）：新增
  `TemplateEntry::analysis()`，惰性缓存「未声明变量 + 模板引用」。
  此前 `extract_params` 解析一次、`validate` 又解析一次（`validate_template`
  内部还会再解析），`include` 闭包里的每个子模板同样重复解析。
  现改为共用一份缓存，`Ast` 借用源码无法自引用存入条目，故缓存的是解析产物。
  `collect_include_closure` 相应改为接收条目而非 AST。
  配套：`TplError` 加 `Clone`（缓存失败态需要留存带行列定位的原始错误）。

- **宽松渲染器惰性构建**（`core/src/registry.rs`）：`render_template_lenient`
  此前**每次调用**都新建 `Renderer` 并把全部模板重新注册、重新编译一遍
  （宽松是建环境时的标志，无法在同一渲染器上切换）。改为惰性构建一次并缓存，
  注册新模板时失效；构建失败原因一并缓存，返回语义不变。

#### Fixed

- **覆盖率门禁恢复为真门禁**（`.github/workflows/ci.yml`）：`coverage` job 的
  `continue-on-error: true` 已移除。该 job 自引入起持续失败，而失败被
  `continue-on-error` 掩盖成"非阻断项"，结果是**覆盖率从未被真正度量**——
  CI 全绿并不代表覆盖达标。安装方式最终改用
  `taiki-e/install-action@cargo-llvm-cov`（预编译二进制）：`cargo install --locked`
  会在 runner 上编译整套依赖并撞上 crates.io 索引漂移，连续两次 exit 101，
  改固定版本后耗时 <1s 即失败（说明压根没进入构建）。另加一步 `cargo llvm-cov --version`
  把"没装上"与"装上了但跑不起来"分开，并把覆盖率数字打进 job summary
  （没有数字的门禁等于没有门禁，后续设阈值也需要先有真实基线）。

#### 新增的测试

- `registry_is_reused_while_directory_is_unchanged`：目录未变必须复用同一份
  注册表（`Rc::ptr_eq`）。
- `registry_is_rebuilt_after_template_edit` / `registry_is_rebuilt_when_template_added`：
  改内容、加文件都必须重建，且新内容真正生效（用旧注册表会渲染出错误的 G-code）。
- `fresh_registry_does_not_pollute_shared_cache`：`build_registry_fresh` 注册的
  临时模板不得泄漏进共享缓存。
- `analysis_is_computed_once_and_matches_direct_extraction`：缓存结论必须与
  直接 `parse` + `extract_undeclared` 逐项一致，且重复取用命中同一份。
- `lenient_renderer_cache_sees_templates_registered_later`：宽松渲染器缓存
  必须随模板注册失效，否则新模板在宽松模式下报 `TemplateNotFound`。

---

### 双输入面一致性与 CI 有效性（架构评估 P1 项）

#### Fixed

- **CI 的 clippy / test / doc 只覆盖了根 crate**（`.github/workflows/ci.yml`）：
  根目录**既是 workspace 根又是一个 package**，而 cargo 在没有 `default-members`
  时默认只选根 package。三条命令都漏了 `--workspace`，于是只对 `nctool-tpl` 生效，
  `nctool-core` / `nctool-cli`（代码主体、绝大多数测试）**从未被 CI 真正检查过**，
  却一直显示全绿——与覆盖率门禁是同一类"假绿"。现补齐 `--workspace`，
  README / CONTRIBUTING / PR 模板里的同款命令一并订正。
  随之暴露并修掉 8 处 rustdoc 告警（`core/src/derive.rs`、`core/src/manifest.rs`：
  指向私有项的链接改为代码 span，`[Q16]` 标记转义）。CI 实测用例数由
  155（仅根 crate）变为 **492**。

- **`--param` 归一规则的 Rust / 前端分歧**（`cli/src/args.rs` + `ui/index.html`
  与 `cli/ui/index.html`）：前端 `coerceParamValue` 与后端 `coerce_param_value`
  有 4 处真实分歧——`01.5`（Rust 取数值、JS 取文本）、`0x10` 与 `Infinity`
  （JS `Number()` 能解析而 Rust `f64::from_str` 不能）、`true` 配数值型规格
  （Rust 取布尔、JS 取文本）。两侧不一致意味着 CLI 与 Web UI 对同一输入会产出
  不同的 G-code，属本项目零容忍的静默错误。现前端补齐布尔字面量推断、
  把数值判定收紧到 Rust `f64::from_str` 的语法（十进制 + 可选指数，且必须有限）、
  白名单比较改为严格同类型（不再出现 `String(true) === "true"` 匹配布尔候选项）。

#### Added

- **`--param` 归一规则对拍门禁**：用例与期望值集中在
  `scripts/param_parity_cases.json`（40 例，覆盖前导零、指数溢出、十六进制、
  混型白名单、布尔与声明类型的优先级），后端 `args.rs` 的
  `param_coercion_matches_shared_fixture` 与前端 `scripts/check_param_parity.mjs`
  **消费同一份**。脚本从 HTML 里抠出真实函数再跑，不在脚本内重写一份
  （重写就等于第三份实现），并额外比对两份 UI 是否互为镜像。
  改任一侧而不同步 fixture，另一侧立刻失败；CI 在 ubuntu 上跑该脚本。

---

### 渲染入口的有限性闸门（架构评估 P1-3）

#### Fixed

- **公开渲染入口不再绕过有限性检查**（`core/src/registry.rs`）：
  `TemplateRegistry::render` / `render_with_machine` / `render_template` /
  `render_template_lenient` 此前完全不走校验，而 NaN/Inf 的拦截只存在于
  `validate` 与管线 `generate*`——直接调用这些入口的调用方（库使用者、
  自定义上下文场景）会拿到含 `"NaN"` / `"inf"` 的输出，机床走到非法坐标。
  现在在 `render_template*` 这一层加了闸门 `ensure_finite_context`：
  深度优先扫描上下文，命中非有限数即返回 `TplError::Render`，报错带路径
  （如 `passes[1].z`）。放在这一层而非各参数入口，是为了**同时覆盖参数集、
  机床系统变量与自定义上下文**；宽松渲染同样不放宽非法数值
  （参数可以缺省，NaN/Inf 不行）。

#### Added

- `nctool_tpl` 再导出 `ValueKind`（`Value::kind()` 的返回类型）：下游判断
  "是数值还是容器"需要它，此前只能靠 `try_iter()` 试探。
  注意它在 `minijinja::value` 下，不在 crate 根。

---

### 本地 UI 的跨站防护与安全响应头（架构评估 P1-4）

#### Added

- **`/api/` 请求的跨站防护**（`cli/src/server.rs::cross_site_guard`）：
  只绑回环并不足以挡住浏览器侧攻击——任意网页都能向 `127.0.0.1:<port>` 发请求
  （DNS rebinding / CSRF）。现在按两个头判定：`Origin` 不在同源白名单内 → 403；
  `Sec-Fetch-Site` 不是 `same-origin` / `none` → 403。
  **两个头都不存在时放行**（curl 等非浏览器客户端）：本服务是命令行工具，
  刻意保留"直接调 API"的用法，而浏览器的 `fetch` / 表单提交**必然**带
  `Origin`，伪造不了。判定放在路由之前，被拒的请求不必再读请求体、不必建注册表。
- **所有响应统一附加安全头**（`SECURITY_HEADERS`）：CSP（含
  `object-src 'none'`、`base-uri 'none'`、`frame-ancestors 'none'`、
  `form-action 'none'`）、`X-Content-Type-Options: nosniff`、
  `Referrer-Policy: no-referrer`。错误响应同样带，避免 403 / 500 成为绕过 CSP 的口子。

#### 已知取舍

- CSP 的 `script-src` / `style-src` 仍保留 `'unsafe-inline'`：前端是单文件内嵌
  页面，脚本与样式都是内联的。它挡不住"页面内被注入 `<script>`"，但能挡住
  外链加载与嵌入。彻底去掉需要给 `<script>` / `<style>` 注入每响应 nonce，
  列为后续加固项。
- 未实现评审建议的"启动一次性 token 拼进 URL"：它要求前端每个请求都带 token
  （要改 HTML 与 JS），而生成不可预测的 token 需要引入随机源依赖——本项目的
  依赖策略是尽量少加传递依赖。现有判定已覆盖同一威胁模型（跨站驱动本地服务），
  故暂缓。

---

### 覆盖率阈值门（架构评估 P0-2 收尾）

#### Changed

- **`coverage` job 由"报数字"变成"报数字 + 卡阈值"**（`.github/workflows/ci.yml`）：
  新增 `--fail-under-lines 89`。引入时实测基线 **90.81% 行覆盖**（502 项测试，
  区域 90.07% / 函数 90.64%）。
  余量是刻意留的：卡在当前值会让"新增少量未覆盖代码"也变红，门禁随即被绕过；
  1.8pt 约等于 165 行新代码，真掉这么多就是覆盖在退化。**覆盖率提升后应上调此值。**
- 阈值与生成**放在同一步**：`cargo llvm-cov report` 不接受 `--all-features`
  （只读已有数据），拆两步会引入"读回的数据与生成时不一致"的风险。
- `Coverage summary` 与 `Upload coverage artifact` 加 `if: always()`：
  门禁失败时摘要与 lcov 产物**仍要产出**——排查"覆盖为什么掉下去"正需要它们。

#### 已知覆盖洼地（下一步补测的优先级）

`cli/src/server.rs` 74.01%、`src/extract.rs` 80.53%、`cli/src/context.rs` 88.09%
是当前拉低总体的主要来源（`cli/src/output.rs` 已于同日补测，见下）。

---

### 补测 CLI 输出层

#### Changed

- **`cli/src/output.rs` 由 0 测试补到 14 项**：行覆盖 **65.22% → 98.41%**、
  函数覆盖 **61.43% → 100%**（此前是全项目最低）。该文件承载两项**对外契约**
  ——退出码矩阵（README 有完整表）与 `--format json` 的包络形状，
  此前只被 `cli_e2e` 间接覆盖到一部分。
- 为可测性把三段逻辑提成纯函数（行为不变）：`text_ok_buf`（保证恰好一个结尾
  换行）、`json_error_text`（`silent` 时返回 `None`）、`json_ok_text`；
  `print_error` / `print_ok` 退化为"构造文本 + 写出"。
- 覆盖率阈值随之由 **89% 上调到 90%**（基线 91.30%，余量 1.3pt ≈ 120 行）。

#### Added

- 退出码矩阵逐项钉住（13 个分类）+ 未知分类兜底归 1；
- 四个 `From` 转换的分类映射：`io::Error`、`RegistryError`（5 个变体）、
  `PipelineError`（5 个变体，含兜底 `pipeline`）、`TplError`；
- `silent` 语义：JSON 通道**一条都不发**（消费方不该收到两条错误对象）；
- JSON 包络形状（`ok` / `error.kind` / `error.message` / `data`）与结尾换行；
- `text_ok_buf` 边界：已带换行时不得再补（否则 `$(nctool ...)` 会多出空行）。

---

### extract 的属性测试（架构评估 P1-2 补完）

#### Added

- **`tests/extract_invariant.rs`：可选判定的单侧不变量**（300 个生成用例）。
  断言"被判为可选的变量，缺省后严格模式必须渲染成功"——判错就意味着用户拿到
  渲染失败、却查不出缺哪个参数（`extract.rs` 修过的真实缺陷正是这一类）。
  反方向（判为必选 ⇒ 缺省必然失败）**刻意不断言**：本项目"宁多勿漏"，
  `{% if a is defined %}{{ a }}{% endif %}` 中 a 缺省时其实能渲染，仍记为必选。
- 用例由确定性 LCG 生成（**零依赖**，不引入 proptest：失败可复现，也不给依赖树
  加负担）；片段库覆盖兜底 / `defined` / `set` 惯用法 / `with` / `for` / `macro` /
  注释 / 无变量模板等形态，并带**生成器退化保护**：样本必须同时出现"无未声明
  变量""含可选""含必选"三种形态，否则片段库被改坏后测试会退化成空断言。
  该保护首次运行即生效（当时片段库全含变量，被拦下后补了无变量片段）。
  已验证测试真有牙齿：临时把提取结果全判为可选 → case 0 立刻失败并打印模板。

---

### 校验核心拆分（架构评估 P2-1）

#### Changed

- **`check_vars` 由 245 行拆为 55 行编排 + 7 个专职函数**（`core/src/validate.rs`）：
  `check_derive_shadowed`（20）/ `check_spec_defaults`（24）/
  `check_spec_declarations`（44）/ `check_var_values`（41）/ `check_finite`（20）/
  `check_missing`（57）/ `check_unused`（24）。
  纯重构，**行为零变更**——由 `validate.rs` 现有的 62 项测试守住。
  拆分原则：派生那段只能留在编排函数里（派生集合要么新建、要么退回入参，
  返回的引用可能指向二者之一，借用关系无法封装进函数返回值），已在代码里注明；
  白名单与区间/整数本来就有专职函数（`check_value_options` /
  `check_value_constraints`），故不再往下拆，只保留"类型不匹配即短路"的顺序逻辑。
  另：`referenced`（模板引用集合）原先在两处各建一次，现由编排函数算一次传下去。

---

## [nctool-core 0.2.2] - 2026-09-10

「facing 面铣模板 + Web UI 真实浏览器验收修复 + 三平台 Release 准备」（CLI 配套改动见 [nctool-cli 0.2.2]；`nctool-tpl` 本轮无改动，保持 0.3.2）

### Added

- **`facing` 面铣模板**（Backlog「内置模板库扩充」首项）：矩形区域 zigzag 往复行切，
  参数 `x0/y0/length/width/depth/feed`（必选）+ `stepover/safe_z/plunge_feed`（可选，
  `stepover` 默认 10、`plunge_feed` 缺省取切削进给）；行数 = ceil(width/stepover)，
  步进与切削分块（非同块斜线），三机床 golden 基线 + 工艺核对清单 §6 同步（18 组
  基线，原 15 组）
- **`.github/workflows/release.yml` 三平台二进制 job**（F1.3）：tag 推送时构建
  Windows / Linux / macOS（arm64）release 二进制并上传为 GitHub Release assets
  （文件名带 target 后缀，`x86_64-pc-windows-msvc` / `x86_64-unknown-linux-gnu` /
  `aarch64-apple-darwin`）；crates.io publish 流程保持不变

### Fixed

- **参数规格必选/默认值解析**（server 模式）：API 返回 `default: null`（必选参数）
  与带标签默认值 `{type,value}`（可选参数），前端此前用 `p.default === undefined`
  判断，导致必选参数被误判为可选（表单显示「必选 0」）、默认值对象被直填入输入框
  （`[object Object]`）。新增 `paramDefault()` 统一取值，必选判定/默认预填/
  placeholder/侧栏统计全部走该函数（`ui/index.html` 与 `cli/ui/index.html` 字节一致）
- **数据源文本**：server 模式下页脚不再停留在静态「演示数据（本地渲染）」，
  成功/失败分别显示「数据源：服务端 API」/「（加载失败）」
- **移动端输入框字号**：`@media (max-width: 480px)` 的 16px 规则被更高特异性的
  `.param-input-wrap input[type=...]` 13px 规则覆盖，iOS Safari 聚焦时仍会放大整页；
  在媒体查询内追加同特异性后定义规则，实测 375px 视口输入框渲染 16px

### 验收

- **Web UI 人工验收 37/37 通过**（`docs/archive/legacy/UI_ACCEPTANCE_CHECKLIST.md`，E1.2 + D4.3）：
  §1 全链路 8/8、§2 移动端 11/11（375px iframe 模拟视口）、§3 校验定位 5/5、
  §4 前后端逐字节一致 5/5、§5 机床切换 4/4（含自定义机床 hero_x9）、§6 主题 2/2、
  §7 已知 UX 2/2。清单按实测修订 4 处与实现不符的描述（D-01-01 参数口径、
  D-03-03 类型不匹配 UI 层不可达、D-03-05 校验内联于 `/api/render`、
  D4.3-04 CLI 与 UI 读同一层叠配置）

### 文档

- `docs/archive/legacy/MACHINE_CONFIG_GUIDE.md`：明确自定义机床须提供模板引用的全部 `machine.xxx`
  键（缺失键严格模式渲染失败，属防御行为），并建议以 generic 为基线复制
- `docs/archive/legacy/PROCESS_CHECKLIST.md`：新增 §6 facing 工艺核对（含 golden 输出逐行说明），
  原 §7/§8/§9 顺延

---

## [nctool-tpl 0.3.2] - 2026-09-03

"第三轮彻底代码审查修复"（核心/CLI 配套改动见 [nctool-core 0.2.1] / [nctool-cli 0.2.1]）。

### Fixed

- **`{% from %}` 别名语义修复**：`{% from "m" import a as b %}` 此前把导入名与别名的
  角色弄反——别名被误报为外部必选参数（上层校验要求用户提供根本不需要的参数）、
  导入名被误判为模板局部（漏报真实引用）。现对齐 minijinja 绑定语义（有别名绑定
  别名，无别名绑定导入名），两者均不再进入未声明集合
- **`{% block %}` 作用域修复**：块体按 minijinja VM 帧语义视为独立作用域，块内
  `set` 不再外泄。修复"块内 `set` + 块外引用"时校验放行、宽松模式静默输出不完整
  G-code（如 `G1 F`）的漏报
- **未定义变量名恢复防错位**：include/extends 期间子模板报错时，不再用主模板源码
  恢复变量名（子模板字节范围套在主模板上会得到同偏移处的无关标识符）；仅当错误
  确属所传源码对应模板时才恢复
- **`Parse.col` 列口径统一为字符**（与 `Variable.col` 的 minijinja span 口径一致）：
  错误行内含多字节字符（如中文注释）时列号不再虚高
- **`set_path_loader` 安全加固**：模板名自加校验，拒绝空名、Windows 盘符前缀
  （`C:`——`PathBuf::push` 会整体替换 base，可逃出根目录）、绝对路径；安全文档
  改写为与引擎实际行为一致（`..`/`.`/`\` 段本就被 minijinja `safe_join` 拦截，
  原文档示例方向反了）
- `nc_pad` 超范围值（如 `1e300`）不再饱和截断为 `i64::MAX`，直接报错
- `nc_fixed(小数位)` / `nc_pad(宽度)` 设上限（32 / 1024），消除巨量分配导致的进程 abort

### Changed

- **模块拆分**：`lib.rs`（约 2500 行 → 文档 + 再导出 + 测试）拆为
  `error.rs` / `extract.rs` / `filters.rs` / `renderer.rs` 四个模块，公共 API 不变
- `add_template` 同名静默替换语义写入文档
- 文档明确有限性防线范围：仅覆盖本库注册的过滤器，裸 `{{ x }}` 与内建操作不保护
- 新增 `extract_template_refs`：提取 `{% include %}`/`{% extends %}`/
  `{% import %}`/`{% from %}` 的静态（字符串字面量）模板引用名，供上层递归校验
  组合模板

---

## [nctool-core 0.2.1] - 2026-09-03

"阶段 A（需求与设计收口）落地 + 第三轮彻底代码审查修复"：golden 基线 15 组、
MachineConfig 键名 schema、API 冻结清单明确。

### Added（阶段 A）

- **golden 基线扩充到 15 组**（A2）：5 内置模板 × 3 机床预设，每组冻结渲染输出
  （`.nc`）与校验报告（`.report.txt`），取代原有 4 文件弱覆盖；`assert_golden` 支持
  `NCTOOL_UPDATE_GOLDEN=1` 人工刷新（防误改基线掩盖回归）；新增防漏项测试
  （矩阵必须覆盖全部内置模板）
- **MachineConfig 键名 schema**（A4）：`KNOWN_CONFIG_KEYS` 登记 20 个已知键
  （类型/默认值/描述）+ `validate_config_keys`；未知键 / 非整数的
  `program_digits` 类键值 / 非枚举的 `units` 类键值给出结构化告警。
  generic 预设与 schema 默认值一致性测试，防"模板用不到、改配置不报错"的静默漂移

### Fixed（第三轮审查）

- **内置模板 `program_header` 修复（P1）**：`G{{ machine.coordinate_system }}` 与
  配置值 `G54`/`G94` 叠加产出非法双前缀 `GG54`/`GG94`；改为直接输出配置值。
  原三处 `contains("G54")` 弱断言被 `"GG54"` 穿透，现全部升级为字节级 golden
- **内置模板 `tool_change` 修复（P1）**：刀具号裸输出 f64（`M6 T5.0`，T 字址标准
  只接受整数）；改为 `T{{ tool_num | nc_strip }}`，并补 tool_change/safe_move 的
  字节级渲染测试（原零覆盖）
- **内置模板 `drill_cycle` 规格去重（A1 核对随手修复）**：`r_plane` 规格重复链
  调用 `with_min(0.0).with_unit("mm")`，收敛为单份
- **校验穿透 include/extends（P2）**：组合模板引用的已注册模板，其必选参数同样
  参与渲染前校验（环引用防护）；此前主模板 include 子模板时，子模板必选参数
  缺失只能在渲染阶段才暴露，违背"渲染前可发现错误"的设计承诺
- **`registry.render` 与 `validate` 口径对齐（P2）**：render 应用规格默认值兜底；
  新增 `render_with_machine`（注入机床系统变量 + 兜底）。消除文档推荐流程
  "validate 通过 → render 失败"的分歧
- **新增 `GCodeGenerator::generate_lenient`（P1，配合 CLI）**：宽松生成复用严格
  管线的规格默认值兜底、`machine` 注入与后处理，保证宽松输出是严格输出的超集
- **错误链完整化（P2）**：`PipelineError`/`RegistryError` 标记 `#[non_exhaustive]`
  并实现 `source()`；管线不再 `map_err(|_|…)` 吞掉注册表错误（新增
  `PipelineError::Registry` 变体）；`RegistryError::Compile` 结构化携带
  `(name, TplError)`，Display 不再三层重复模板名
- **去重**：`apply_spec_defaults`/`build_render_context`/`param_to_minijinja` 收敛
  到 model 模块单份实现（原先 core 内两份 + CLI 一份共三处拷贝）
- `GenerationOptions` 行号生成修复：`step=0` 视为 1（此前产出全 `N0000`）；加法改
  `checked_add` 防溢出
- 删除死公共 API：自由函数 `has_errors`、类型别名 `ValidationResult`（零调用）
- `ParamSpec` 文档修正：`default` 与 `required` 非互斥（与既有用法/测试一致）
- 校验错误消息携带模板名 + 行列定位（此前只报参数名）
- 参数名与系统注入变量（`machine` 等）同名时输出警告（此前被静默覆盖）
- **机床配置键接线**：`program_prefix`/`program_digits` 接入 program_header，
  `units` 替代硬编码 metric；`line_number_prefix`/`line_number_digits` 接入
  G-code 后处理行号（此前均为装饰性键）
- `registry.render`/`render_with_machine` 文档标注绕过校验层的 NaN 风险；
  `apply_spec_defaults` 文档写明优先级（用户值 > 规格默认 > 模板内联 default）
- 声明 `rust-version = "1.82"`（三个 crate）

---

## [nctool-cli 0.2.1] - 2026-09-03

"阶段 A 接线 + 第三轮彻底代码审查修复"。

### Added（阶段 A）

- `machine show` 输出配置告警（A4 接线）：未知键 / 非法值经
  `validate_config_keys` 检查后以 `⚠` 行展示（text）并附 `warnings` 数组（JSON），
  不阻断命令成功——自定义机床配置携带扩展键仍可正常使用

### Fixed（第三轮审查）

- **`render --lenient` 收编核心管线（P1）**：此前宽松路径绕过规格默认值兜底与
  全部后处理——旗舰模板 `drill_cycle` 省略 `r_plane` + `--lenient` 反而渲染失败
  （宽松比严格更易失败），`--line-numbers/--header/--ascii/--strip-blank` 在该分支
  静默失效。现改走 `GCodeGenerator::generate_lenient`，并删除 CLI 侧
  `build_context`/`render_lenient` 副本（上下文构建收归 core 单份实现）
- **`--out` 写入安全（P2）**：拒绝输出路径与源模板相同（防止渲染结果覆盖并销毁
  模板源码）；父目录缺失时自动创建（对齐 `templates new` 的目录策略）
- **配置解析不再 gate 全部命令（P2）**：`completion`/`ui`/`part` 不读配置文件，
  CWD 存在损坏的 `nctool.toml` 时补全生成不再一并失败
- **脚手架修复**：`templates new` 骨架的坐标系行删除多余 `G` 前缀（与
  program_header 同源的 `GG54` 问题）
- `--lenient` 帮助文案对齐实际语义（经过滤器引用的变量仍需具体值才能求值）

### Changed

- **退出码矩阵**：0 成功 / 1 校验失败 / 2 参数错误（与 clap 一致）/ 3 IO / 4 配置 /
  5 模板·机床未找到 / 6 渲染失败（此前一律 1）
- `validate --format json` 失败输出补齐 `error:{kind,message}`（此前仅 `data`）
- `--param` 类型强制后缀 `k:s=k:n=k:b=`；前导零纯数字（`007`）保持字符串；
  `--help` 写明推断规则
- `--params-file` 数值走 `is_finite` 防护（`1e999` → inf 拒绝），与 `--param` 对齐
- 全局配置路径遵循平台约定（Windows `%APPDATA%\nctool`、Unix `XDG_CONFIG_HOME`），
  兼容回退 `~/.config`；项目配置从 CWD **向上递归**查找
- `config show` 展示全局/项目配置来源路径；配置单次加载并缓存于 `Ctx`
  （`machine list`/`resolve_machine`/`config show` 不再重复读盘）
- `machine list` JSON 增加 `builtin` 标记（text 通道原有"自定义"标注对齐）
- `render` JSON 成功输出附 `warnings` 数组
- `templates show`/`inspect` 模板解析优先级与 `render`/`validate` 统一（注册表名 → 文件路径）
- stdout 断管道（`| head`）不再 panic；`templates new a.j2` 不再生成 `a.j2.j2`；
  `--dir`/`--param` 帮助文案对齐实际行为
- CI 增加 `windows-latest`（此前仅 ubuntu，平台特有路径/目录行为无覆盖）

### 测试

- workspace 总计 **279 项**（2026-09-03 实测，全绿）：nctool-tpl 104 单元 + 18 集成 + 1 文档、
  nctool-core 84 单元 + 10 集成、nctool-cli 23 单元 + 39 集成。
  相对 nctool-cli 0.2.0 基线 211 项 +68（阶段 A 新增：core +4 单元 +1 集成、
  cli +1 集成——合计 +6，余为第三轮审查补测）

---

## [nctool-cli 0.2.2] - 2026-09-10

> 本段原为第二处 `[未发布]` 标题，但其中全部内容（Web UI 响应式 D5、CLI E2E 契约
> E1.1、golden 换行 E2.4、发版准备 F、UI 体验修正、A3 冻结清单、A5 文档基线）
> 均已包含在 tag `nctool-cli-v0.2.2`（提交 `9e6917a`）中 —— 发布时漏改标题，
> 导致 [nctool-core 0.2.2] 段的「CLI 配套改动见 [nctool-cli 0.2.2]」指向不存在的
> 段落。2026-09-18 补齐标题与本节说明。

### Added（阶段 D5 — Web UI 响应式）

- **移动端断点（≤480px）**：`ui/index.html` 新增 `@media (max-width: 480px)`，
  覆盖输入框 16px 字号（规避 iOS Safari 聚焦自动放大）、触摸目标 ≥38px、顶栏压缩、
  侧栏限高 220px（保证预览区不被压没）、参数行换行、预览工具条换行、
  选项卡横向滚动、关于/帮助键值列表单列。亮/暗主题为既有能力，本次仅补响应式

### Added（阶段 E1.1 — CLI E2E 契约测试）

- 新增 `cli/tests/cli_e2e.rs`：44 用例覆盖全部 **10** 个顶层子命令
  （`templates` / `inspect` / `validate` / `render` / `generate` / `machine` /
  `config` / `ui` / `part` / `completion`）的正常与异常路径，逐条断言退出码 0–7。
  `ui` 为阻塞服务，仅覆盖启动前的回环守卫以免测试挂起。
  该文件是**契约测试**：退出码或错误分类的任何变更都必须在此同步
- 退出码矩阵以表形式固化在测试文件头注释中，与 `CliError::exit_code` 一一对应

### Changed（阶段 E1.1 — 退出码契约修正）

- **`templates new` 重名：退出码 3 → 6**。错误分类由 `io` 改为 `template_duplicate`。
  重名是业务冲突而非 IO 失败，且与 `RegistryError::Duplicate` 的分类保持一致
  （`template_duplicate` 此前在退出码矩阵中已定义却无使用点，属死分支）。
  ⚠️ 破坏性变更：脚本若依赖旧码 3，需改为 6
- **`completion` 新增 `powershell` / `pwsh` 别名**：clap 的 kebab-case 默认名为
  `power-shell`，不符合用户习惯；三种写法现等价（仅新增，不移除原值）

### Added（阶段 E2.4 / E4）

- **golden 换行符归一化（E2.4）**：`core/tests/integration.rs` 的 `assert_golden`
  在比较与 `NCTOOL_UPDATE_GOLDEN=1` 刷新两侧均过 `normalize_newlines`，
  golden 基线恒为 LF，断言不再受平台 / git 检出配置影响。
  新增 `golden_files_are_lf_only` 用例在落盘层把住关口（B4.2 基线保护）
- **万行级实测（E4.2）**：新增 `core/tests/large_program.rs`，覆盖
  行号上限截断、恶意位宽夹紧、`step=0` 兜底，以及两条 `#[ignore]` 的万行实测
  （`cargo test --release -- --ignored --nocapture`）。
  实测：10000 行带行号 **1.77 ms / 203 KB**；`line_number_digits=1e9`
  被夹到 32，输出 **231 KB / 1.81 ms**，无内存放大
- **后处理性能基线（E4.1）**：新增 `core/benches/pipeline.rs`，补齐原基准缺失的
  后处理项（`cargo bench -p nctool-core --bench pipeline`）

### Added（阶段 F 阶段发版准备）

- **F1.4 文档同步**：`README.md` 补 `generate` / `ui` 子命令示例 + **退出码矩阵表**
  （0–7 全档 + 典型触发）；补管线后处理性能基线与万行实测；
  `core/README.md` 补 ASCII 清洗、修正过时的测试计数 63+8 → 84+11+3
- **F2.1《机床配置指南》**：`docs/archive/legacy/MACHINE_CONFIG_GUIDE.md`——`MachineConfig` 模型、
  3 套内建预设（`generic` / `wfl_m65` / `index_ms40`）、`KNOWN_CONFIG_KEYS` 完整清单
  （6 组分类）、`nctool.toml` 自定义、加载顺序、关键约束（`line_number_digits`
  夹紧到 32 的内存安全理由、`Choice` 键合法性、未知键告警等）
- **F2.2《模板编写指南》**：`docs/archive/legacy/TEMPLATE_WRITING_GUIDE.md`——必选/可选启发式、
  NC/数学过滤器、机床配置引用、多模板 include/extends、validate/render 校验分层、
  调试技巧、反模式表（`(x/2) | default` 兜不住、`a.b | default` 同理、模板里手写
  `N0010` 双重编号等）、发布前 checklist
- **F3.1 Issues 模板**：`.github/ISSUE_TEMPLATE/` 三件套——`bug_report.yml` 七段
  （版本/组件/OS/复现命令/模板源码/期望/实际/logs）、`feature_request.yml` 五段
  （动机/提案/替代/影响面/兼容）、`config.yml` 关闭空 issue + 文档/讨论/工艺安全
  三组 contact_links（工艺问题导向 `PROCESS_CHECKLIST` 而非泛用 issue）
- **F3.2 迭代节奏约定**：`docs/archive/legacy/RELEASE.md`——版本号策略（0.x 可破坏 / 1.0+ 严格 semver）、
  发布节奏（按需，CI/audit 必须 0 告警）、提交流程（commit 自包含、message 含动机）、
  兼容性窗口（弃用保留 1 minor）、决策与争议（轻量共识 / 7 天讨论期）、
  Backlog 加权打分法（影响×3 + 投入产出×2 + 风险×2 + 依赖×1）
- **F4 Backlog 排序**：ROADMAP 按上述加权法对 5 个候选打分：
  内置模板库扩充 37 / 零件级批量生成 34 / 参数预设 34 / 浏览器内模板编辑 21 /
  i18n 20。明确为「初始基线」，外部反馈后重打分

### Changed（阶段 UI 体验修正）

- **ASCII 清洗复选框副标题歧义修复（用户报告）**：原副标题
  `非 ASCII → ?` 读起来像功能说明而非后果警告，用户勾上后看到
  中文被替换为 `?` 误以为显示 bug。改为 `开启后非 ASCII → ?`，
  并在预览工具栏加红字提示 `⚠ ASCII 模式：非 ASCII 已替换为 ?`，
  下次再触发时一眼能看出原因。详见 `ui/index.html` → `cli/ui/index.html`

### Changed（阶段 A3 — 1.0 API 冻结清单）

**自 `nctool-tpl 0.3.2` / `nctool-core 0.2.1` 起，以下公共 API 面在 1.0.0 前不再
发生破坏性变更**；新增能力走 `additive`：只加不删、不改签名、不改语义。确需
破坏性变更时须先拆出预发布版本并在此节登记。

- **nctool-tpl**：`parse` / `Ast` / `Variable` / `extract_variables` /
  `extract_undeclared` / `extract_template_refs` / `Renderer`
  （`new` / `with_lenient` / `with_strict` / `is_lenient` / `render` / `add_template` /
  `set_path_loader` / `render_template`）/ `TplError`（`#[non_exhaustive]`，变体集冻结）/
  `Value` 再导出 / NC 过滤器（`nc_fixed` / `nc_strip` / `nc_pad`）与数学过滤器
- **nctool-core**：`model`（`ParamValue` / `ParamKind` / `ParamSpec` / `ParameterSet` /
  `MachineConfig`）、`validate`（`spec` / `validate_template` / `validate_with_vars` /
  `ValidationReport` / `ValidationIssue` / `ValidationLevel` / `IssueKind`）、
  `registry`（`TemplateCategory` / `TemplateSource` / `TemplateEntry` /
  `TemplateRegistry` / `RegistryError`）、`machine`（`MachinePreset` / `MachineId` /
  `KNOWN_CONFIG_KEYS` / `validate_config_keys`）、`pipeline`（`GCodeGenerator` /
  `GenerationOptions` / `OutputFormat` / `PipelineError`）

**1.0 前候选破坏性变更（未决，不进 0.3.2/0.2.1）**：

- `safe_move` / `drill_cycle` 的参数规格上界可能按机床动态化（PROCESS_CHECKLIST F1）
- 删除 `AST` 内部结构字段的二次暴露（如有）

### Changed（阶段 A5 — 文档与基线）

- 新增 [docs/archive/legacy/PROCESS_CHECKLIST.md](docs/archive/legacy/PROCESS_CHECKLIST.md)：工艺核对清单
  （逐行核对结论 + F1–F5 发现项 + 外部评审待办）
- README 顶部新增定位与风险声明（未经工艺验证，投产前必须自行核对）
- `docs/archive/legacy/ROADMAP.md` / `docs/archive/legacy/DEV_PLAN_CLI_UI.md` 数据校准

---

## [nctool-cli 0.2.0] - 2026-09-01

"阶段 1 CLI 核心能力"：脚本化生成 G-code 全流程可用；同时承载阶段 0 的命令树骨架与工程基线。

### Added

- **完整命令树**：`templates list/show/new`、`inspect`、`validate`、`render/generate`、`machine list/show`、`config init/show`、`completion`（`ui`/`part` 为阶段 2/4 占位）
- **参数输入**：`--param k=v`（类型自动推断：数值/字符串/布尔）+ `--params-file`（JSON 对象，显式 `--param` 覆盖文件）
- **配置层叠**：全局 `~/.config/nctool/config.toml` + 项目 `./nctool.toml`，项目覆盖全局（模板目录/默认机床/自定义机床表）
- **统一错误输出**：`--format text|json` 双通道；JSON 输出结构化错误对象 `{ok, error:{kind, message}}`
- **宽松模式**：`render --lenient` 未定义变量渲染为空（缺失参数不阻断）
- **模板脚手架**：`templates new` 生成带参数规格注释的骨架
- **golden 测试**：CLI 渲染输出与 `nctool-core` 管线逐字节一致

### Changed

- 新增 `cli/` crate 并接入 workspace（`members = [".", "core", "cli"]`），binary 名 `nctool`
- `release.yml` 增加 `nctool-cli-v*` tag 发布通道（对齐 tpl/core 命名约定）

### 测试

- nctool-cli：19 单元 + 29 集成（含 golden / 退出码 / JSON / 脚手架 / 配置层叠），workspace 总计 211 项（本发布基线；后续版本见 [nctool-cli 0.2.1]）

---

## [nctool-cli 0.1.0] - 2026-09-01

"阶段 0 脚手架与命令框架"：clap 命令树骨架 + 全局选项 + 工程基线。

### Added

- 新增 `cli/` crate（package `nctool-cli`，binary `nctool`），依赖 `nctool-core` + `nctool-tpl`
- clap derive 命令树；全局选项 `--machine` / `--template-dir` / `--format` / `--verbose`
- 统一错误类型 `CliError`（text/JSON 双输出通道）
- 参数解析单元测试（类型推断 / params-file / 覆盖优先级）
- CI 五道门（fmt / clippy / test / doc / cargo audit）经 workspace 级命令自动覆盖新 crate

---

## [nctool-core 0.2.0] - 2026-08-31

"第二轮全面代码审查修复"：补齐错误定位与 NC 输出健壮性；模板作用域语义修复见 [nctool-tpl 0.3.1]。

### Added

- **`GenerationOptions::ascii_only`**：开启后 G-code 输出中的非 ASCII 字符替换为 `?`
  （含头部注释与模板名）；仅对 `OutputFormat::Gcode` 生效，`Text` 始终原样

### Fixed

- **machine 元信息注入**：`machine.id` / `vendor` / `model` 现可被模板直接引用
  （原先只注入 `config` 键值表）；config 同名键以元信息优先
- **校验错误类型**：`TemplateRegistry::validate` 错误从 `String` 改为 `RegistryError`
  （新增 `NotFound` 变体）；管线中校验失败不再误映射为 `PipelineError::Render`
- **头部注释 ASCII 化**：管线头部注释改为英文 ASCII 文本（许多 CNC 控制器对非 ASCII 敏感）
- **Memory 模板去重存储**：`TemplateSource::Memory` 不再复制一份源码（源码以
  `TemplateEntry::source_text` 为单一权威来源）

### Changed（破坏性，0.x 阶段）

- `TemplateSource::Memory` 从 `Memory(String)` 改为无载荷变体（源码统一读 `source_text`）
- `MachinePreset::to_config` 移除（与 `config()` 重复）
- `TemplateRegistry::validate` 返回 `Result<ValidationReport, RegistryError>`
- core 依赖 `minijinja` 去除多余的 `unstable_machinery` 等 feature 声明（由 nctool-tpl 启用并合并）
- 依赖升级：`nctool-tpl` 0.3.0 → 0.3.1

### 其他

- 补全发布元数据：`nctool-core` 的 `repository` 指向 GitHub 仓库

### 测试

- nctool-core 52 单元 + 8 集成，workspace 总计 163 项

---

## [nctool-tpl 0.3.1] - 2026-08-31

"第二轮全面代码审查修复"：修正变量提取的作用域语义，补齐错误定位与 NC 输出健壮性。

### Fixed

- **set/with 自引用漏报**：`{% set total = total + price %}` 中右侧引用原被误判为模板局部，
  导致必选参数校验漏报、严格渲染才报错。现 RHS 先在外层作用域求值，再绑定目标
- **作用域泄漏**：`for` / `with` / `macro` 现在创建独立作用域（与 Jinja2 语义一致），
  循环/块内 `set` 的名字不再泄漏到块外；`if` 仍不创建作用域
- **UndefinedVariable 恢复变量名**：debug feature 下错误携带字节范围，尽力从源码恢复缺失变量名
  （`{{ missing }}` → `"missing"`）；属性链场景无法判定缺失位置时留空（宁缺毋错）
- **nc_pad 拒绝负数**：负输入会拼出 `O-001` 这类非法 G-code，现报渲染错误

### 其他

- 新增 `.gitattributes`（统一 LF），消除 Windows 下 autocrlf 幻影改动
- `set_path_loader` 文档补充路径穿越安全性说明（模板视为可信输入）
- 补全发布元数据：`nctool-tpl` 的 `repository` 指向 GitHub 仓库

### 测试

- nctool-tpl 85 单元 + 17 集成 + 1 文档（workspace 总计 163 项，含 nctool-core）

---

## [0.1.0] nctool-core - 2026-08-31

"阶段 1 核心库"：workspace 新增子 crate `core/`（nctool-core v0.1.0），在 nctool-tpl 之上提供面向 G-code 生成的生产级能力，并通过阶段性代码审查。

### Added

- **workspace 化**：根 Cargo.toml 改为 workspace（`members = [".", "core"]`，resolver=2）
- **数据模型**（`model`）：`ParamValue`（Number/String/Bool，serde 带标签）、`ParamKind`、`ParamSpec`、`ParameterSet`（BTreeMap + fluent API）、`MachineConfig`、`Tool`、`Operation`、`Part`
- **参数校验引擎**（`validate`）：`validate_template` / `validate_with_vars` 渲染前校验（必选齐全 / 类型匹配 / 默认值兜底 / 冗余警告），`ValidationReport` 结构化错误，系统变量（默认 `machine`）校验豁免
- **模板注册表**（`registry`）：内存 / 文件 / 内置模板统一管理，内置 5 个 G-code 子程序（program_header / program_footer / tool_change / safe_move / drill_cycle）
- **机床配置**（`machine`）：`MachinePreset`（Generic / WflM65 / IndexMs40）内建配置，模板经 `{{ machine.xxx }}` 引用实现一套模板适配多机床
- **生成管线**（`pipeline`）：`GCodeGenerator.generate`（校验 → 规格默认值兜底 → 上下文合并 → 渲染 → 后处理），`PipelineError` 三变体
- **根导出补全**：`lib.rs` 增加 `validate_template` / `validate_with_vars` / `spec` 根路径导出

### Fixed（阶段性代码审查）

- **非有限数防护**：数值参数为 NaN/Inf 时校验阶段拒绝（原实现会经 JSON 中间层**静默转 0** 污染坐标）
- **上下文构建**：改为 minijinja 原生构造，移除 serde_json 中间层，杜绝非有限数被篡改
- **Text 格式契约**：Text 格式仅渲染、保留原始行（原实现会对所有行 trim，破坏空白）
- **行号逻辑**：`max_line_number` 概念清晰化（原实现将"行数上限"与"行号数值上限"混用）
- **校验去重**：`validate_template` / `validate_with_vars` 提取共享核心 `check_vars`
- **错误映射**：`RegistryError` 新增 `Compile` 变体（原将模板编译失败误映射为 `Io`）；内置模板注册失败不再静默吞错（`expect`）
- **占位测试清理**：移除纯为消告警的 `param_kind_reuse_in_tests`

### 测试

- nctool-core：49 → 55 项（47 单元 + 8 集成），workspace 总计 146 项
- 新增覆盖：NaN/Inf 校验拒绝（含 `validate_with_vars` 路径）、有限数通过、NaN 管线拦截、Text 格式保留空白、行号到上限后停止

---

## [0.3.0] - 2026-08-31

"NC 数值格式化"版本：新增 G-code 专用数值格式化过滤器与严格/宽松渲染模式切换。

### Added

- **NC 数值格式化过滤器**：`nc_fixed(N)`（固定小数位）、`nc_strip`（去尾零）、`nc_pad(N)`（前导零填充），用于 G-code 坐标值、程序号、行号的格式化输出
- **严格/宽松模式切换**：`Renderer::with_lenient()` / `with_strict()` / `is_lenient()`。默认严格（未定义变量报错），宽松模式渲染未定义变量为空字符串；`extract_undeclared` 的必选判定不受模式影响
- **非有限数防护**：所有 NC 过滤器对 NaN/Inf 输入报 [`TplError::Render`]，防止非法坐标写入 G-code
- **测试**：8 项 NC 过滤器测试 + 5 项模式切换测试，总测试 78 → 91 项

### 用法示例

```jinja
O{{ prog | nc_pad(4) }}
N{{ line | nc_pad(4) }} G1 X{{ x | nc_fixed(3) }} Y{{ y | nc_fixed(3) }} F{{ feed | nc_strip }}
```

```rust
let r = Renderer::new().with_lenient(); // 宽松模式：未定义变量渲染为空
```

### 测试

- 从 78 项增至 91 项（73 单元 + 17 集成 + 1 文档）
- 新增覆盖：nc_fixed / nc_strip / nc_pad 的常规与异常输入；严格/宽松模式切换、模式与参数提取的独立性

### 性能基线（release，~260 字节 G-code 模板）

| 操作 | 耗时（中位数） | 吞吐 |
| --- | --- | --- |
| `parse` | 2.61 µs | 98 MiB/s |
| `extract_undeclared` | 1.97 µs | — |

"基座打磨"版本：多模板能力、错误细分、API 稳定化、工程化全覆盖。

### Added

- **多模板渲染**：`Renderer::add_template`（内存注册）、`Renderer::set_path_loader`（目录加载）、`Renderer::render_template`（渲染已注册模板），支持 `{% include %}` / `{% extends %}` / `{% import %}`
- **错误类型细分**：`TplError` 新增 `TemplateNotFound` / `UndefinedVariable` / `UnknownFilter` / `UnknownTest` 变体，上层可精准处理
- **可选/必选参数区分**：`Variable.optional` 字段，`default`/`d` 过滤器和 `is defined`/`is undefined` 测试标记的变量为可选
- **列号定位**：`TplError::Parse.col` 从恒为 1 的占位值改为真实列号（基于 minijinja `debug` feature 的字节范围换算）
- **性能基准**：`criterion` benchmark（parse / extract_undeclared / render 三场景），`cargo bench` 可运行
- **CI 流水线**：GitHub Actions（fmt / clippy / test / doc / cargo audit），push 和 PR 触发
- **CHANGELOG**：本文件

### Changed

- **[破坏性] API 收窄**：`Ast` 的 `name` / `source` 从 pub 字段改为私有字段 + 访问方法（`name()` / `source()`），减少未来破坏面
- **[破坏性] 错误枚举扩展**：`TplError` 标注 `#[non_exhaustive]`，未来新增变体不破坏下游；match 请保留通配分支
- **minijinja 版本锁定**：从 `^2.24.0` 收窄为 `~2.24.0`（允许补丁，锁定 minor），因依赖 `unstable_machinery` AST API
- **release 配置**：新增 `codegen-units = 1`（配合已有 LTO + strip）
- **文档**：所有公共 API 补全 doc comment，`cargo doc --no-deps` 零警告；新增 `#![warn(missing_docs)]` lint

### Fixed

- 列号定位：`TplError::Parse.col` 不再恒为 1，现在指向解析器停止位置的最佳近似
- 可选参数误报：有 `default()` 兜底的变量不再被列为必选未声明变量

### 测试

- 从 11 项增至 56 项（38 单元 + 17 集成 + 1 文档）
- 新增覆盖：多模板 include/extends/import、错误细分、边界 case（空模板/纯文本/注释/保留名/循环变量/宏参数/嵌套 default/filter 链/复杂表达式）、列号定位、可选/必选区分

### 性能基线（release，~260 字节 G-code 模板）

| 操作 | 耗时（中位数） | 吞吐 |
| --- | --- | --- |
| `parse` | 2.61 µs | 98 MiB/s |
| `extract_undeclared` | 1.97 µs | — |
| `render` | 5.32 µs | 48 MiB/s |

---

## [0.1.0] - 2026-08-30

初始版本：NCtool 模板解析核心。

### Added

- 核心 API：`parse` / `extract_variables` / `extract_undeclared` / `Renderer`
- 数学过滤器集：sin / cos / tan / asin / acos / atan / sqrt / exp / ln / log10 / pow / floor / ceil（含 NaN/Inf 有限性校验）
- Strict 未定义变量策略：缺失变量直接渲染失败
- 11 项测试
- README、MIT 许可、demo 示例、G-code 模板
